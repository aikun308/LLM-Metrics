# -*- coding: utf-8 -*-
import os
import re
import math
import multiprocessing
import pickle
import random
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from collections import Counter, defaultdict
from matplotlib import rcParams
from matplotlib import font_manager as fm
from matplotlib.lines import Line2D
from sklearn.manifold import TSNE
from sklearn.cluster import KMeans

# ✅用于“内嵌簇图例（可控锚点 + 彩色圆点标题）”
from matplotlib.offsetbox import AnnotationBbox, TextArea, DrawingArea, HPacker, VPacker
from matplotlib.patches import Circle

# =========================
# 线程/并行限制（保持原样）
# =========================
os.environ.setdefault("OMP_NUM_THREADS", "1")
os.environ.setdefault("OPENBLAS_NUM_THREADS", "1")
os.environ.setdefault("MKL_NUM_THREADS", "1")
os.environ.setdefault("NUMEXPR_NUM_THREADS", "1")

try:
    cpu_count = multiprocessing.cpu_count()
except Exception:
    cpu_count = 1
os.environ.setdefault("LOKY_MAX_CPU_COUNT", str(cpu_count))

# -------------------- 可调配置区 --------------------
PKL_INPUT_DIR = "E:/Research_Group/TON_2025/code/12.1/output/output_pkl/all"  # 输入 pkl 目录
PDF_OUTPUT_DIR = "E:/Research_Group/TON_2025/code/12.1/output/fig_7and8/ip"  # 输出目录

SCENE_FREQ_RATIO = 0.20  # 高频指标阈值：当前统计范围（目标网络场景）样本数的 20%

EXCLUDE_METRICS = [
    'bit_error_rate', 'frame_error_rate', 'fault_recovery_delay', 'slice_isolation_degree',
    'transmission_delay', 'processing_delay', 'accuracy', 'false_positive_rate', 'f1_score', 'recall', 'precision'
]
METRIC_MAPPING = {}

CUSTOM_CORRELATIONS = {
    "end_to_end_delay-end_to_end_delay": 1,
    "packet_error_rate-packet_error_rate": 1,
    "symbol_error_rate-symbol_error_rate": 1,
}

# ============================================================
# ✅场景过滤开关：仅统计目标场景（默认启用）
# ============================================================
SCENE_FILTER_ENABLED = True
TARGET_SCENE_LABEL = "1.1 互联网与IP网络"

# ============================================================
# ✅布局缓存：保证你调 anchors 时点/簇位置完全不变
# ============================================================
USE_LAYOUT_CACHE = True
FORCE_REBUILD_CACHE = False
LAYOUT_CACHE_FILENAME = "layout_tsne_cache.pkl"  # 存放在 PDF_OUTPUT_DIR 下

# ============================================================
# ✅绘图前统一生效的“指标显示名映射表”（仅影响显示）
# ============================================================
DISPLAY_RENAME_MAP = {
    "end_to_end_delay": "End-to-end delay",
    "snr": "Signal-to-noise ratio",
    "round_trip_time": "Round-trip time",
    "age_of_information": "Age of Information",
    "rssi": "RSSI",
    "request_success_rate": "Request success rate",
    "congestion_window": "Congestion window",
    "attack_detection_rate": "Attack detection rate",
    "transmission_security": "Transmission security",
    "throughput": "Throughput",
    "bandwidth": "Bandwidth",
    "packet_delivery_ratio": "Packet delivery ratio",
    "spectral_efficiency": "Spectral efficiency",
    "transmission_rate": "Transmission rate",
    "link_capacity": "Link capacity",
    "bandwidth_utilization": "Bandwidth utilization",
    "memory_consumption": "Memory consumption",
    "energy_consumption": "Energy consumption",
    "transmit_power": "Transmit power",
    "traffic_volume": "Traffic volume",
    "node_egree": "Node degree",
    "cpu_utilization": "CPU utilization",
    "resource_utilization": "Resource utilization",
    "routing_overhead": "Routing overhead",
    "communication_overhead": "Communication overhead",
    "time_complexity": "Time complexity",
    "convergence_time": "Convergence time",
    "packet_loss_rate": "Packet loss rate",
    "hop_count": "Hop count",
    "flow_completion_time": "Flow completion time",
    "packet_error_rate": "Packet error rate",
    "queuing_length": "Queuing length",
    "jitter": "Jitter",
    "noise_power": "Noise power",
}

def _normalize_display_text(s: str) -> str:
    if s is None:
        return ""
    s = str(s).replace("_", " ")
    s = re.sub(r"\s+", " ", s).strip()
    return s

def metric_display_name(metric_id: str) -> str:
    if metric_id in DISPLAY_RENAME_MAP:
        return _normalize_display_text(DISPLAY_RENAME_MAP[metric_id])
    return _normalize_display_text(metric_id)

# （3）同簇尽可能紧凑：缩小该值（0~1，越小越紧凑）
CLUSTER_COMPACT_FACTOR = 0.30
CLUSTER_REPULSE_ITERS = 160
CLUSTER_REPULSE_MARGIN_SCALE = 0.95
CLUSTER_REPULSE_DAMPING = 0.80
CLUSTER_GLOBAL_SPREAD = 0.90

GLOBAL_CENTER_SHRINK = 0.90
MAX_CLUSTER_ASPECT_RATIO = 1.5

AXIS_TICK_COLOR = "black"
AXIS_SPINE_COLOR = "black"
AXIS_SPINE_WIDTH = 1.2
TICK_WIDTH = 1.0
GRID_COLOR = "black"
GRID_ALPHA = 0.15
GRID_LW = 0.6

RANDOM_SEED = 42
np.random.seed(RANDOM_SEED)
random.seed(RANDOM_SEED)

# ============================================================
# ✅IEEE LaTeX 友好的 PDF 字体嵌入设置（关键修改点）
# - 避免 Type3：pdf.fonttype/ps.fonttype 设为 42（TrueType）
# - serif 优先 Times 系，mathtext 用 STIX
# ============================================================
rcParams['pdf.fonttype'] = 42
rcParams['ps.fonttype'] = 42
rcParams['pdf.use14corefonts'] = False
rcParams['font.family'] = 'serif'
rcParams['font.serif'] = ['Times New Roman', 'Times', 'Nimbus Roman No9 L', 'DejaVu Serif']
rcParams['mathtext.fontset'] = 'stix'
rcParams['axes.unicode_minus'] = False
rcParams['figure.dpi'] = 330
rcParams['savefig.dpi'] = 330

try:
    sns.set_style('whitegrid')
except Exception:
    plt.style.use('default')

# ============================================================
# ✅字体大小：按要求放大
# ============================================================
# --- 指标聚类图（散点图）总图例字号 ---
CLUSTER_LEGEND_FONTSIZE = 11
CLUSTER_LEGEND_TITLE_FONTSIZE = 12
CLUSTER_LEGEND_MARKERSIZE = 8

# --- 指标聚类图（散点图）各子图例（Cluster A/B... panel）字号：本次新增放大 ---
CLUSTER_PANEL_BODY_FONTSIZE = 9          # 原 8
CLUSTER_PANEL_HEADER_FONTSIZE = 10        # 原 9(=8+1)
CLUSTER_PANEL_DOT_RADIUS = 3.6            # 原 3.0
CLUSTER_PANEL_DOT_BOX_PX = 12            # 原 10

# --- 聚类相关系数热力图字号 ---
HEATMAP_TICK_FONTSIZE = 26
HEATMAP_ANNOT_FONTSIZE = 20
HEATMAP_CLUSTER_LABEL_FONTSIZE = 24
HEATMAP_COLORBAR_TICK_FONTSIZE = 20

# -------------------- 字体函数（更稳定：定位到真实字体文件，确保可嵌入） --------------------
def _fontprop_from_family_candidates(families, size=10):
    for fam in families:
        try:
            fp = fm.FontProperties(family=fam)
            path = fm.findfont(fp, fallback_to_default=False)
            if path and os.path.isfile(path):
                return fm.FontProperties(fname=path, size=size)
        except Exception:
            continue
    return fm.FontProperties(size=size)

def get_tnr_font(size=10):
    return _fontprop_from_family_candidates(
        ['Times New Roman', 'Times', 'Nimbus Roman No9 L', 'DejaVu Serif'],
        size=size
    )

def get_chinese_font(size=10):
    chinese_fonts = [
        'SimSun', 'Microsoft YaHei', 'SimHei', 'STSong', 'FangSong', 'KaiTi',
        'Microsoft JhengHei', 'DengXian', 'Heiti TC', 'Songti SC', 'STHeiti',
        'Arial Unicode MS', 'WenQuanYi Zen Hei', 'WenQuanYi Micro Hei', 'Noto Sans CJK SC',
        'DejaVu Sans'
    ]
    return _fontprop_from_family_candidates(chinese_fonts, size=size)

chinese_font = get_chinese_font()
tnr_font = get_tnr_font()
print(f"当前使用的中文字体：{chinese_font.get_family()}")
print(f"当前使用的英文字体：{tnr_font.get_family()}")

os.makedirs(PDF_OUTPUT_DIR, exist_ok=True)
print(f"开始加载 {PKL_INPUT_DIR} 目录下的 pkl 文件...")

# =========================
# 工具：安全字符串
# =========================
def _safe_str(x):
    try:
        return "" if x is None else str(x)
    except Exception:
        return ""

# =========================
# 场景提取/匹配：字段提取 + 全树递归扫描兜底（保持“鲁棒”）
# =========================
def _normalize_scene_label(s: str) -> str:
    if s is None:
        return ""
    s = str(s).strip()
    s = re.sub(r"\s+", " ", s)
    return s

def _strip_prefix_number(s: str) -> str:
    s = _normalize_scene_label(s)
    s = re.sub(r"^\s*\d+(?:\.\d+)*\s*[\.\-—_:：、]?\s*", "", s)
    return s

def _canonical_scene(s: str) -> str:
    s = _strip_prefix_number(s)
    s = re.sub(r"\s+", "", s)
    return s

def extract_scene_labels_by_fields(data: dict):
    labels = []
    if not isinstance(data, dict):
        return labels

    candidates = [
        "network_scene_label", "scene_label", "network_scene", "fig_7and8", "scene_tag",
        "network_scene_name", "scene_name", "scene_id",
        "network_scene_labels", "scene_labels", "scenes",
        "场景", "场景标签", "网络场景", "网络场景标签"
    ]

    def _pull(obj):
        if isinstance(obj, str):
            s = _normalize_scene_label(obj)
            if s:
                labels.append(s)
        elif isinstance(obj, (list, tuple, set)):
            for it in obj:
                if isinstance(it, str):
                    s = _normalize_scene_label(it)
                    if s:
                        labels.append(s)

    for k in candidates:
        if k in data:
            _pull(data.get(k))

    for nk in ["meta", "metadata", "info", "paper_meta", "paper_info", "结果", "输出", "label_info"]:
        if nk in data and isinstance(data.get(nk), dict):
            meta = data.get(nk, {})
            for k in candidates:
                if k in meta:
                    _pull(meta.get(k))

    labels = list(dict.fromkeys([x for x in labels if x]))
    return labels

def deep_find_scene_hits(obj, target_norm: str, target_can: str, max_depth=8, max_hits=2):
    hits = []

    def _walk(x, path, depth):
        if len(hits) >= max_hits:
            return
        if depth > max_depth:
            return

        if isinstance(x, str):
            s_norm = _normalize_scene_label(x)
            if not s_norm:
                return
            s_can = _canonical_scene(s_norm)
            if s_norm == target_norm or s_can == target_can:
                hits.append(path)
            return

        if isinstance(x, dict):
            for k, v in x.items():
                if len(hits) >= max_hits:
                    break
                k_str = _safe_str(k)
                _walk(v, f"{path}.{k_str}" if path else k_str, depth + 1)
            return

        if isinstance(x, (list, tuple, set)):
            for i, it in enumerate(list(x)[:200]):
                if len(hits) >= max_hits:
                    break
                _walk(it, f"{path}[{i}]", depth + 1)
            return

    _walk(obj, "", 0)
    return hits

def is_target_scene(data: dict, target_label: str):
    target_norm = _normalize_scene_label(target_label)
    target_can = _canonical_scene(target_label)

    extracted = extract_scene_labels_by_fields(data)
    for s in extracted:
        if _normalize_scene_label(s) == target_norm:
            return True
        if _canonical_scene(s) == target_can:
            return True

    hits = deep_find_scene_hits(data, target_norm=target_norm, target_can=target_can, max_depth=8, max_hits=2)
    return (len(hits) > 0)

# -------------------- 统计容器 --------------------
metric_counter = Counter()
relation_accumulator = defaultdict(list)

# -------------------- 读取 pkl 并汇总 --------------------
pkl_files = [f for f in os.listdir(PKL_INPUT_DIR) if f.endswith("_metrics_relations.pkl")]
pkl_files = sorted(pkl_files)
actual_file_count = len(pkl_files)
print(f"成功找到 {actual_file_count} 个符合条件的 pkl 文件（后缀：_metrics_relations.pkl）")

selected_count = 0
loaded_count = 0

for idx, pkl_file in enumerate(pkl_files, 1):
    pkl_path = os.path.join(PKL_INPUT_DIR, pkl_file)
    try:
        with open(pkl_path, 'rb') as f:
            data = pickle.load(f)
    except Exception as e:
        print(f"加载文件 {pkl_file} 失败：{e}，跳过")
        continue

    loaded_count += 1

    if SCENE_FILTER_ENABLED:
        if not is_target_scene(data, TARGET_SCENE_LABEL):
            continue
        selected_count += 1

    file_metrics = data.get("metrics", {})
    processed_metrics = set()
    for raw_metric in file_metrics.keys():
        normalized_metric = _safe_str(raw_metric).lower().strip().replace(" ", "_").replace("-", "_")
        mapped_metric = METRIC_MAPPING.get(normalized_metric, normalized_metric)
        if mapped_metric in EXCLUDE_METRICS:
            continue
        if mapped_metric:
            processed_metrics.add(mapped_metric)

    metric_counter.update(sorted(processed_metrics))

    file_relations = data.get("relations", {})
    for pair_key, corr in file_relations.items():
        if "-" not in _safe_str(pair_key):
            continue
        m1_raw, m2_raw = _safe_str(pair_key).split("-", 1)

        m1 = METRIC_MAPPING.get(
            _safe_str(m1_raw).lower().replace(" ", "_").replace("-", "_"),
            _safe_str(m1_raw).lower().replace(" ", "_").replace("-", "_")
        )
        m2 = METRIC_MAPPING.get(
            _safe_str(m2_raw).lower().replace(" ", "_").replace("-", "_"),
            _safe_str(m2_raw).lower().replace(" ", "_").replace("-", "_")
        )

        if m1 in EXCLUDE_METRICS or m2 in EXCLUDE_METRICS:
            continue

        sorted_pair = sorted([m1, m2])
        mapped_pair_key = f"{sorted_pair[0]}-{sorted_pair[1]}"

        try:
            if isinstance(corr, (int, float)) and -1 <= corr <= 1 and corr != 0:
                relation_accumulator[mapped_pair_key].append(float(corr))
        except Exception:
            continue

    if idx % 50 == 0:
        print(f"已加载 {idx}/{actual_file_count} 个文件...")

print("数据加载与统计完成！")
print(f"共统计到 {len(metric_counter)} 个不同指标")
if SCENE_FILTER_ENABLED:
    print(f"\n[场景筛选已启用] 目标场景：{TARGET_SCENE_LABEL}")
    print(f"进入统计的样本文件数：{selected_count} / {actual_file_count}")
    if selected_count == 0:
        raise ValueError(f"未找到场景标签为“{TARGET_SCENE_LABEL}”的样本（请确认该场景标签是否写入 *_metrics_relations.pkl）")

# -------------------- 高频指标筛选（稳定排序） --------------------
# 阈值口径：只基于“实际进入当前统计范围”的样本数计算。
# - 启用场景过滤时：使用目标网络场景样本数 selected_count。
# - 未启用场景过滤时：使用成功加载并参与统计的样本数 loaded_count。
# 这样 20% 不会被全语料库 pkl 总数稀释或放大，而是对应当前所统计的网络场景。
stats_scope_file_count = selected_count if SCENE_FILTER_ENABLED else loaded_count
if stats_scope_file_count <= 0:
    raise ValueError("当前统计范围内没有可用于筛选高频指标的样本")

scene_freq_threshold = max(1, math.ceil(stats_scope_file_count * SCENE_FREQ_RATIO))
high_freq_metrics = [metric for metric, freq in metric_counter.items() if freq >= scene_freq_threshold]
if not high_freq_metrics:
    raise ValueError(
        f"无满足条件的高频指标（当前统计范围样本数={stats_scope_file_count}，"
        f"阈值比例={SCENE_FREQ_RATIO:.0%}，需出现≥{scene_freq_threshold}次）"
    )

high_freq_metrics = sorted(high_freq_metrics, key=lambda m: (-metric_counter[m], m))
print(
    f"高频指标阈值：当前统计范围样本数={stats_scope_file_count}，"
    f"阈值比例={SCENE_FREQ_RATIO:.0%}，需出现≥{scene_freq_threshold}次"
)
print(f"筛选出 {len(high_freq_metrics)} 个高频指标：{high_freq_metrics}")

# -------------------- 构建平均相关系数矩阵 --------------------
n = len(high_freq_metrics)
avg_corr_matrix = np.eye(n)
metric_index = {metric: i for i, metric in enumerate(high_freq_metrics)}

for pair_key, corr_list in relation_accumulator.items():
    try:
        metric1, metric2 = pair_key.split("-", 1)
    except Exception:
        continue
    if metric1 in metric_index and metric2 in metric_index and len(corr_list) > 0:
        i = metric_index[metric1]
        j = metric_index[metric2]
        avg_corr = float(np.mean(corr_list))
        avg_corr_matrix[i, j] = avg_corr_matrix[j, i] = avg_corr

# 应用自定义覆盖
norm_custom = {}
for k_, v in CUSTOM_CORRELATIONS.items():
    if "-" in k_:
        a, b = k_.split("-", 1)
        a_n = a.lower().replace(" ", "_").replace("-", "_")
        b_n = b.lower().replace(" ", "_").replace("-", "_")
        norm_key = f"{a_n}-{b_n}"
        norm_custom[norm_key] = float(v)

print("\n应用手动修改的相关系数：")
for custom_pair, custom_corr in norm_custom.items():
    try:
        m1, m2 = custom_pair.split("-", 1)
        if m1 in metric_index and m2 in metric_index:
            i = metric_index[m1]
            j = metric_index[m2]
            avg_corr_matrix[i, j] = avg_corr_matrix[j, i] = custom_corr
            print(f"✅ {custom_pair}: {custom_corr}（已更新）")
        else:
            print(f"❌ {custom_pair}: 指标不在高频列表中，跳过")
    except Exception as e:
        print(f"❌ 处理 {custom_pair} 失败：{e}")

# ============================================================
# 聚类 + t-SNE：缓存锁死
# ============================================================
cache_path = os.path.join(PDF_OUTPUT_DIR, LAYOUT_CACHE_FILENAME)

def _signature_dict():
    return {
        "SCENE_FILTER_ENABLED": SCENE_FILTER_ENABLED,
        "TARGET_SCENE_LABEL": TARGET_SCENE_LABEL,
        "SCENE_FREQ_RATIO": SCENE_FREQ_RATIO,
        "stats_scope_file_count": stats_scope_file_count,
        "scene_freq_threshold": scene_freq_threshold,
        "EXCLUDE_METRICS": list(EXCLUDE_METRICS),
        "METRIC_MAPPING": dict(METRIC_MAPPING),
        "CUSTOM_CORRELATIONS": dict(CUSTOM_CORRELATIONS),
        "RANDOM_SEED": RANDOM_SEED,
        "CLUSTER_COMPACT_FACTOR": CLUSTER_COMPACT_FACTOR,
        "CLUSTER_REPULSE_ITERS": CLUSTER_REPULSE_ITERS,
        "CLUSTER_REPULSE_MARGIN_SCALE": CLUSTER_REPULSE_MARGIN_SCALE,
        "CLUSTER_REPULSE_DAMPING": CLUSTER_REPULSE_DAMPING,
        "CLUSTER_GLOBAL_SPREAD": CLUSTER_GLOBAL_SPREAD,
        "GLOBAL_CENTER_SHRINK": GLOBAL_CENTER_SHRINK,
        "MAX_CLUSTER_ASPECT_RATIO": MAX_CLUSTER_ASPECT_RATIO,
        "high_freq_metrics": list(high_freq_metrics),
    }

def _load_cache(path):
    with open(path, "rb") as f:
        return pickle.load(f)

def _save_cache(path, obj):
    with open(path, "wb") as f:
        pickle.dump(obj, f)

def repel_clusters_2d(points_2d, labels, iters=200, margin_scale=1.15, damping=0.92, seed=42):
    rng = np.random.RandomState(seed)
    pts = points_2d.copy()
    uniq = sorted(list(set(labels.tolist() if isinstance(labels, np.ndarray) else list(labels))))
    if len(uniq) <= 1:
        return pts

    for _ in range(iters):
        centroids = {}
        radii = {}
        for c in uniq:
            idxs = np.where(labels == c)[0]
            if len(idxs) == 0:
                centroids[c] = np.zeros(2)
                radii[c] = 0.0
                continue
            c_pts = pts[idxs]
            cen = c_pts.mean(axis=0)
            centroids[c] = cen
            if len(idxs) == 1:
                radii[c] = 0.3
            else:
                radii[c] = float(np.max(np.linalg.norm(c_pts - cen, axis=1)) + 0.15)

        base_margin = np.median(list(radii.values())) * margin_scale + 1e-6

        shifts = {c: np.zeros(2) for c in uniq}
        for i in range(len(uniq)):
            for j in range(i + 1, len(uniq)):
                ci, cj = uniq[i], uniq[j]
                vi = centroids[ci]
                vj = centroids[cj]
                diff = vj - vi
                dist = float(np.linalg.norm(diff))
                if dist < 1e-10:
                    diff = rng.randn(2)
                    dist = float(np.linalg.norm(diff)) + 1e-9
                unit = diff / dist

                min_dist = radii[ci] + radii[cj] + base_margin
                overlap = min_dist - dist
                if overlap > 0:
                    push = 0.5 * overlap * unit
                    shifts[ci] -= push
                    shifts[cj] += push

        mean_shift = np.mean(np.vstack(list(shifts.values())), axis=0)
        for c in uniq:
            shifts[c] = (shifts[c] - mean_shift) * damping

        moved = False
        for c in uniq:
            idxs = np.where(labels == c)[0]
            if len(idxs) == 0:
                continue
            if np.linalg.norm(shifts[c]) > 1e-12:
                pts[idxs] = pts[idxs] + shifts[c]
                moved = True

        if not moved:
            break

    return pts

cache_used = False
signature = _signature_dict()

if USE_LAYOUT_CACHE and (not FORCE_REBUILD_CACHE) and os.path.exists(cache_path):
    try:
        cache_obj = _load_cache(cache_path)
        if isinstance(cache_obj, dict) and cache_obj.get("signature", None) == signature:
            layout_tsne = cache_obj["layout_tsne"]
            clusters = cache_obj["clusters"]
            k = int(cache_obj["k"])
            cluster_ranked_ids = cache_obj["cluster_ranked_ids"]
            cluster_rank = cache_obj["cluster_rank"]
            cluster_letter_map = cache_obj["cluster_letter_map"]
            cluster_centroids = cache_obj["cluster_centroids"]
            cluster_angles = cache_obj["cluster_angles"]
            global_center = cache_obj["global_center"]
            cluster_indices = {cid: [i for i, c in enumerate(clusters) if c == cid] for cid in range(k)}
            cache_used = True
            print(f"\n✅已读取布局缓存：{cache_path}")
        else:
            print(f"\n⚠️缓存存在但签名不一致（说明口径变了），将重算并覆盖：{cache_path}")
    except Exception as e:
        print(f"\n⚠️读取缓存失败，将重算：{e}")

if not cache_used:
    print("\n开始生成指标聚类图（KMeans in 原空间 + t-SNE 可视化）...")

    corr_sub = np.clip(avg_corr_matrix.copy(), -1.0, 1.0)
    dist_matrix = (1.0 - corr_sub) / 2.0

    if n < 2:
        raise ValueError("指标数量不足以进行聚类（需要至少2个）")

    perplexity_candidate = max(5, n // 4)
    perplexity = min(30, perplexity_candidate, n - 1)
    if perplexity < 1:
        perplexity = 1

    X_kmeans = dist_matrix
    k_guess = int(round(np.sqrt(max(2, n))))
    k = max(2, min(10, k_guess))
    kmeans = KMeans(n_clusters=k, random_state=RANDOM_SEED, n_init=10)
    clusters = kmeans.fit_predict(X_kmeans)

    cluster_indices = {cid: [i for i, c in enumerate(clusters) if c == cid] for cid in range(k)}

    tsne = TSNE(
        n_components=2,
        metric='precomputed',
        perplexity=perplexity,
        random_state=RANDOM_SEED,
        init='random'
    )
    tsne_results = tsne.fit_transform(dist_matrix)

    # 簇内紧凑化
    compact_tsne = tsne_results.copy()
    for cid in range(k):
        idxs = np.where(clusters == cid)[0]
        if len(idxs) == 0:
            continue
        raw_pts = tsne_results[idxs]
        centroid = raw_pts.mean(axis=0)
        compact_tsne[idxs] = centroid + CLUSTER_COMPACT_FACTOR * (raw_pts - centroid)

    # 形状矫正
    layout_tsne = compact_tsne.copy()
    for cid in range(k):
        idxs = np.where(clusters == cid)[0]
        if len(idxs) < 3:
            continue

        pts = layout_tsne[idxs]
        centroid = pts.mean(axis=0)
        centered = pts - centroid

        try:
            cov = np.cov(centered, rowvar=False)
            if cov.shape != (2, 2):
                continue
            eigvals, eigvecs = np.linalg.eigh(cov)
        except Exception:
            continue

        order = np.argsort(eigvals)[::-1]
        eigvals = eigvals[order]
        eigvecs = eigvecs[:, order]

        if eigvals[1] <= 1e-12:
            continue

        aspect_ratio = np.sqrt(eigvals[0] / eigvals[1])
        if aspect_ratio <= MAX_CLUSTER_ASPECT_RATIO:
            continue

        scale_major = MAX_CLUSTER_ASPECT_RATIO / aspect_ratio
        V = eigvecs
        coords_pca = centered @ V
        coords_pca[:, 0] *= scale_major
        centered_new = coords_pca @ V.T
        layout_tsne[idxs] = centroid + centered_new

    # 簇间排斥
    layout_tsne = repel_clusters_2d(
        layout_tsne, clusters,
        iters=CLUSTER_REPULSE_ITERS,
        margin_scale=CLUSTER_REPULSE_MARGIN_SCALE,
        damping=CLUSTER_REPULSE_DAMPING,
        seed=RANDOM_SEED
    )

    layout_tsne = layout_tsne * CLUSTER_GLOBAL_SPREAD

    if 0 < GLOBAL_CENTER_SHRINK < 1.0:
        global_center_tmp = layout_tsne.mean(axis=0)
        layout_tsne = global_center_tmp + GLOBAL_CENTER_SHRINK * (layout_tsne - global_center_tmp)

    # 极角命名
    global_center = layout_tsne.mean(axis=0)
    cluster_angles = {}
    cluster_centroids = {}
    for cid in range(k):
        idxs = np.where(clusters == cid)[0]
        if len(idxs) == 0:
            cluster_centroids[cid] = global_center.copy()
            cluster_angles[cid] = 1e18
            continue
        cen = layout_tsne[idxs].mean(axis=0)
        cluster_centroids[cid] = cen
        v = cen - global_center
        ang = float(np.arctan2(v[1], v[0]))
        ang = float((ang + 2.0 * np.pi) % (2.0 * np.pi))
        cluster_angles[cid] = ang

    cluster_ranked_ids = sorted(range(k), key=lambda cid: (cluster_angles.get(cid, 1e18), cid))
    cluster_rank = {cid: rank for rank, cid in enumerate(cluster_ranked_ids)}
    cluster_letter_map = {cid: chr(ord('A') + rank) for cid, rank in cluster_rank.items()}

    if USE_LAYOUT_CACHE:
        try:
            _save_cache(cache_path, {
                "signature": signature,
                "layout_tsne": layout_tsne,
                "clusters": clusters,
                "k": k,
                "cluster_ranked_ids": cluster_ranked_ids,
                "cluster_rank": cluster_rank,
                "cluster_letter_map": cluster_letter_map,
                "cluster_centroids": cluster_centroids,
                "cluster_angles": cluster_angles,
                "global_center": global_center,
            })
            print(f"\n✅已写入布局缓存：{cache_path}")
        except Exception as e:
            print(f"\n⚠️写缓存失败（不影响出图）：{e}")

def cluster_letter(cid: int) -> str:
    return cluster_letter_map.get(int(cid), "?")

print("\n[簇字母命名规则] 已启用：按簇中心极角升序映射为 A/B/C...（不改变 KMeans labels 本身）")
for cid in cluster_ranked_ids:
    ang_deg = float(cluster_angles.get(cid, 0.0)) * 180.0 / np.pi
    cen = cluster_centroids.get(cid, global_center)
    print(f"  Cluster {cluster_letter(cid)} <= kmeans_id={cid}  angle={ang_deg:.1f}°  centroid=({cen[0]:.3f}, {cen[1]:.3f})")

# ====================================================
# 聚类相关系数热力图（字号放大）
# ====================================================
cluster_corr_matrix = np.zeros((k, k))
cluster_indices = {cid: [i for i, c in enumerate(clusters) if c == cid] for cid in range(k)}

for i_c in range(k):
    for j_c in range(k):
        if len(cluster_indices[i_c]) == 0 or len(cluster_indices[j_c]) == 0:
            cluster_corr_matrix[i_c, j_c] = 0
            continue
        corr_vals = []
        for idx_i in cluster_indices[i_c]:
            for idx_j in cluster_indices[j_c]:
                corr_vals.append(avg_corr_matrix[idx_i, idx_j])
        cluster_corr_matrix[i_c, j_c] = np.mean(corr_vals)

def sort_clusters_by_similarity(cluster_corr):
    k_clusters = cluster_corr.shape[0]
    if k_clusters <= 1:
        return list(range(k_clusters))
    sorted_clusters = [0]
    remaining = set(range(1, k_clusters))
    while remaining:
        last_cluster = sorted_clusters[-1]
        max_corr = -np.inf
        next_cluster = None
        for c in remaining:
            current_corr = cluster_corr[last_cluster, c]
            if current_corr > max_corr:
                max_corr = current_corr
                next_cluster = c
        sorted_clusters.append(next_cluster)
        remaining.remove(next_cluster)
    return sorted_clusters

sorted_cluster_ids = sort_clusters_by_similarity(cluster_corr_matrix)
print(f"\n优化后的簇排序：{sorted_cluster_ids}（仅用于热力图矩阵重排）")

order_by_cluster = []
for cluster_id in sorted_cluster_ids:
    idxs = cluster_indices[cluster_id]
    idxs_sorted = sorted(
        idxs,
        key=lambda i: (-metric_counter[high_freq_metrics[i]], high_freq_metrics[i])
    )
    order_by_cluster.extend(idxs_sorted)

all_ordered = list(dict.fromkeys(order_by_cluster))
missing = [i for i in range(n) if i not in all_ordered]
if missing:
    all_ordered.extend(missing)

sorted_corr_matrix = avg_corr_matrix[np.ix_(all_ordered, all_ordered)]
sorted_axis_labels = [
    f"{metric_display_name(high_freq_metrics[i])}({metric_counter[high_freq_metrics[i]]})"
    for i in all_ordered
]

cluster_bounds = []
current_pos = 0
for cluster_id in sorted_cluster_ids:
    cluster_size = len(cluster_indices[cluster_id])
    if cluster_size == 0:
        continue
    start = current_pos
    end = current_pos + cluster_size - 1
    cluster_bounds.append((cluster_id, start, end))
    current_pos = end + 1

print("生成带簇分隔线的聚类相关系数热力图（fig_8(a).pdf）...")

fig = plt.figure(figsize=(16, 16))
gs = fig.add_gridspec(nrows=1, ncols=2, width_ratios=[30, 1], wspace=0.08)
ax = fig.add_subplot(gs[0, 0])
cax = fig.add_subplot(gs[0, 1])

sns.heatmap(
    sorted_corr_matrix,
    annot=True,
    fmt=".2f",
    cmap="vlag",
    center=0,
    vmin=-1,
    vmax=1,
    xticklabels=sorted_axis_labels,
    yticklabels=sorted_axis_labels,
    ax=ax,
    cbar=True,
    cbar_ax=cax,
    linewidths=0.5,
    square=True,
    annot_kws={"size": HEATMAP_ANNOT_FONTSIZE, "fontproperties": get_tnr_font(HEATMAP_ANNOT_FONTSIZE)}
)

for (_, _, end) in cluster_bounds[:-1]:
    ax.axvline(x=end + 1, color='black', linewidth=2, linestyle='-')
    ax.axhline(y=end + 1, color='black', linewidth=2, linestyle='-')

for (cid, start, end) in cluster_bounds:
    mid = (start + end) / 2.0 + 0.5
    label = f"Cluster {cluster_letter(cid)}"
    ax.text(
        mid, 1.01, label,
        transform=ax.get_xaxis_transform(),
        ha="center", va="bottom",
        fontproperties=get_tnr_font(HEATMAP_CLUSTER_LABEL_FONTSIZE),
        fontsize=HEATMAP_CLUSTER_LABEL_FONTSIZE,
        color="black",
        clip_on=False
    )

plt.setp(ax.get_xticklabels(), rotation=45, ha="right",
         fontproperties=get_tnr_font(HEATMAP_TICK_FONTSIZE), fontsize=HEATMAP_TICK_FONTSIZE)
plt.setp(ax.get_yticklabels(), rotation=0,
         fontproperties=get_tnr_font(HEATMAP_TICK_FONTSIZE), fontsize=HEATMAP_TICK_FONTSIZE)

cax.tick_params(labelsize=HEATMAP_COLORBAR_TICK_FONTSIZE)
for label in cax.get_yticklabels():
    label.set_fontproperties(get_tnr_font(HEATMAP_COLORBAR_TICK_FONTSIZE))

ax.grid(True, linestyle='--', linewidth=0.5, color='gray', alpha=0.3)

fig.tight_layout(rect=[0, 0, 1, 0.98])

cluster_heatmap2_path = os.path.join(PDF_OUTPUT_DIR, "fig_8(a).pdf")
plt.savefig(cluster_heatmap2_path, format="pdf", bbox_inches="tight", dpi=330)
plt.close()
print(f"带簇分隔线的聚类相关系数热力图已保存：{cluster_heatmap2_path}")

# =========================
# 指标聚类散点图：内嵌簇 panel（anchors 可调，但点不变）
# =========================
cmap = plt.get_cmap('tab10')
cluster_colors = [cmap(i % 10) for i in range(k)]

fig, ax = plt.subplots(figsize=(5, 5))
scatter_sizes = 100
POINT_LABEL_FONTSIZE = 8

_SUBSCRIPT_MAP = str.maketrans({
    "0": "₀", "1": "₁", "2": "₂", "3": "₃", "4": "₄",
    "5": "₅", "6": "₆", "7": "₇", "8": "₈", "9": "₉"
})
def to_subscript(num: int) -> str:
    return str(num).translate(_SUBSCRIPT_MAP)

# 给同簇编号
tag_in_cluster = {}
cluster_sorted_member_indices = {}
for cluster_id in range(k):
    idxs = cluster_indices.get(cluster_id, [])
    idxs_sorted_for_number = sorted(
        idxs,
        key=lambda i: (-metric_counter[high_freq_metrics[i]], high_freq_metrics[i])
    )
    cluster_sorted_member_indices[cluster_id] = idxs_sorted_for_number
    prefix = cluster_letter(cluster_id)
    for rank_i, i_idx in enumerate(idxs_sorted_for_number, start=1):
        tag_in_cluster[i_idx] = f"{prefix}{to_subscript(rank_i)}"

# 绘制散点
for cluster_id in cluster_ranked_ids:
    idxs = np.where(clusters == cluster_id)[0]
    if len(idxs) == 0:
        continue
    pts = layout_tsne[idxs]
    base_color = cluster_colors[cluster_id]
    ax.scatter(
        pts[:, 0], pts[:, 1],
        s=scatter_sizes,
        color=base_color,
        edgecolors='k',
        linewidths=0.4,
        zorder=3
    )

# 点内标号（双层文字模拟描边，避免 Type3 风险）
for i_idx, _metric in enumerate(high_freq_metrics):
    x_coord, y_coord = layout_tsne[i_idx]
    tag = tag_in_cluster.get(i_idx, None)
    if tag is None:
        continue

    ax.text(
        x_coord, y_coord,
        f"{tag}",
        ha="center", va="center",
        fontsize=POINT_LABEL_FONTSIZE + 1,
        fontproperties=get_tnr_font(POINT_LABEL_FONTSIZE + 1),
        color="black",
        zorder=3.8
    )
    ax.text(
        x_coord, y_coord,
        f"{tag}",
        ha="center", va="center",
        fontsize=POINT_LABEL_FONTSIZE,
        fontproperties=get_tnr_font(POINT_LABEL_FONTSIZE),
        color="white",
        zorder=4
    )

# 正方形/等比例
ax.set_aspect('equal', adjustable='box')
if hasattr(ax, "set_box_aspect"):
    ax.set_box_aspect(1)

# ✅锁定视窗，避免 bbox/tight 影响视觉位置
x_min, x_max = float(layout_tsne[:, 0].min()), float(layout_tsne[:, 0].max())
y_min, y_max = float(layout_tsne[:, 1].min()), float(layout_tsne[:, 1].max())
x_pad = (x_max - x_min) * 0.06 + 1e-9
y_pad = (y_max - y_min) * 0.06 + 1e-9
ax.set_xlim(x_min - x_pad, x_max + x_pad)
ax.set_ylim(y_min - y_pad, y_max + y_pad)
ax.autoscale(False)

ax.tick_params(axis='both', which='both', colors=AXIS_TICK_COLOR, width=TICK_WIDTH, labelsize=11)
for tick_label in ax.get_xticklabels() + ax.get_yticklabels():
    tick_label.set_fontproperties(get_tnr_font(11))
    tick_label.set_color(AXIS_TICK_COLOR)

for spine in ax.spines.values():
    spine.set_color(AXIS_SPINE_COLOR)
    spine.set_linewidth(AXIS_SPINE_WIDTH)

ax.grid(True, linestyle='--', linewidth=GRID_LW, color=GRID_COLOR, alpha=GRID_ALPHA)

# =========================
# 总图例（Clusters）——已放大
# =========================
cluster_handles = []
cluster_labels = []
for cluster_id in cluster_ranked_ids:
    cluster_handles.append(
        Line2D([0], [0], marker='o', linestyle='',
               markersize=CLUSTER_LEGEND_MARKERSIZE,
               markerfacecolor=cluster_colors[cluster_id],
               markeredgecolor='k', markeredgewidth=0.4)
    )
    cluster_labels.append(f"Cluster {cluster_letter(cluster_id)}")

cluster_legend = ax.legend(
    handles=cluster_handles,
    labels=cluster_labels,
    loc="upper right",
    bbox_to_anchor=(0.27, 0.99),
    borderaxespad=0.0,
    frameon=True,
    fontsize=CLUSTER_LEGEND_FONTSIZE,
    title="Clusters"
)
cluster_legend.get_title().set_fontproperties(get_tnr_font(CLUSTER_LEGEND_TITLE_FONTSIZE))
cluster_legend.get_title().set_fontsize(CLUSTER_LEGEND_TITLE_FONTSIZE)
cluster_legend.get_title().set_weight("bold")
for txt in cluster_legend.get_texts():
    txt.set_fontproperties(get_tnr_font(CLUSTER_LEGEND_FONTSIZE))
    txt.set_fontsize(CLUSTER_LEGEND_FONTSIZE)
ax.add_artist(cluster_legend)

try:
    cluster_legend.set_in_layout(False)
except Exception:
    pass

# ==========================================================
# 各子图例 panel（Cluster A/B...）：本次按要求放大字号
# ==========================================================
CLUSTER_LEGEND_ANCHORS = {
    "A": (0.98, 0.765),
    "B": (0.37, 0.84),
    "C": (0.02, 0.17),
    "D": (0.39, 0.16),
    # "E": (0.39, 0.19),
    # "F": (0.99, 0.11),
}

CLUSTER_PANEL_ALPHA = 0.96
CLUSTER_PANEL_EDGE_LW = 0.9
MAX_LINES_PER_COLUMN = 20   # 字号变大后略减，避免单 panel 过高

# 放大后更容易碰撞：加大搜索范围与步长
ANCHOR_NUDGE_STEP = 0.022
ANCHOR_NUDGE_LEVELS = 10
PANEL_POINT_PAD_PX = 12
PANEL_PANEL_PAD_PX = 8

def _auto_fallback_anchor(letter: str, cid: int):
    cen = cluster_centroids.get(cid, global_center)
    cen_axes = ax.transAxes.inverted().transform(ax.transData.transform(np.array(cen)))
    x, y = float(cen_axes[0]), float(cen_axes[1])
    ax_x = 0.97 if x < 0.5 else 0.03
    ax_y = 0.03 if y > 0.5 else 0.97
    return (ax_x, ax_y)

def _panel_alignment_from_anchor(xy):
    x, y = xy
    ha = "right" if x > 0.5 else "left"
    va = "bottom" if y < 0.5 else "top"
    box_alignment = (1.0 if ha == "right" else 0.0, 0.0 if va == "bottom" else 1.0)
    return ha, va, box_alignment

def _make_cluster_panel(letter: str, cid: int, color_rgba, idxs_sorted):
    dot_da = DrawingArea(CLUSTER_PANEL_DOT_BOX_PX, CLUSTER_PANEL_DOT_BOX_PX, 0, 0)
    dot = Circle(
        (CLUSTER_PANEL_DOT_BOX_PX/2.0, CLUSTER_PANEL_DOT_BOX_PX/2.0),
        radius=CLUSTER_PANEL_DOT_RADIUS,
        facecolor=color_rgba,
        edgecolor="black",
        linewidth=0.4
    )
    dot_da.add_artist(dot)

    header_text = TextArea(
        f"Cluster {letter}",
        textprops=dict(
            fontproperties=get_tnr_font(CLUSTER_PANEL_HEADER_FONTSIZE),
            fontsize=CLUSTER_PANEL_HEADER_FONTSIZE,
            color="black",
            weight="bold"
        )
    )
    header = HPacker(children=[dot_da, header_text], align="center", pad=0, sep=5)

    lines = []
    for i_idx in idxs_sorted:
        tag = tag_in_cluster.get(i_idx, "")
        name = metric_display_name(high_freq_metrics[i_idx])
        lines.append(f"{tag}: {name}")
    if not lines:
        lines = ["(empty)"]

    if len(lines) <= MAX_LINES_PER_COLUMN:
        body = TextArea(
            "\n".join(lines),
            textprops=dict(
                fontproperties=get_tnr_font(CLUSTER_PANEL_BODY_FONTSIZE),
                fontsize=CLUSTER_PANEL_BODY_FONTSIZE,
                color="black"
            )
        )
        return VPacker(children=[header, body], align="left", pad=0, sep=5)

    ncol = int(np.ceil(len(lines) / MAX_LINES_PER_COLUMN))
    ncol = max(2, min(3, ncol))
    cols = []
    chunk = int(np.ceil(len(lines) / ncol))
    for c in range(ncol):
        part = lines[c*chunk:(c+1)*chunk]
        if not part:
            continue
        cols.append(
            TextArea(
                "\n".join(part),
                textprops=dict(
                    fontproperties=get_tnr_font(CLUSTER_PANEL_BODY_FONTSIZE),
                    fontsize=CLUSTER_PANEL_BODY_FONTSIZE,
                    color="black"
                )
            )
        )
    body = HPacker(children=cols, align="top", pad=0, sep=14)
    return VPacker(children=[header, body], align="left", pad=0, sep=5)

def _bbox_overlaps_points(bbox_disp, points_disp, pad_px=0):
    if bbox_disp is None:
        return False
    x0, y0, x1, y1 = bbox_disp.x0 - pad_px, bbox_disp.y0 - pad_px, bbox_disp.x1 + pad_px, bbox_disp.y1 + pad_px
    xs = points_disp[:, 0]
    ys = points_disp[:, 1]
    inside = (xs >= x0) & (xs <= x1) & (ys >= y0) & (ys <= y1)
    return bool(np.any(inside))

def _bbox_overlaps_bbox(b1, b2, pad_px=0):
    if b1 is None or b2 is None:
        return False
    x0 = max(b1.x0 - pad_px, b2.x0 - pad_px)
    y0 = max(b1.y0 - pad_px, b2.y0 - pad_px)
    x1 = min(b1.x1 + pad_px, b2.x1 + pad_px)
    y1 = min(b1.y1 + pad_px, b2.y1 + pad_px)
    return (x1 > x0) and (y1 > y0)

def _spiral_offsets(step, levels):
    offsets = [(0.0, 0.0)]
    for lv in range(1, levels + 1):
        d = step * lv
        offsets.extend([
            ( d, 0), (-d, 0), (0,  d), (0, -d),
            ( d,  d), ( d, -d), (-d,  d), (-d, -d),
            (2*d, 0), (-2*d, 0), (0, 2*d), (0, -2*d),
        ])
    return offsets

points_disp = ax.transData.transform(layout_tsne)
approx_r_pt = float(np.sqrt(max(1.0, scatter_sizes))) * 0.60
approx_r_px = approx_r_pt * float(fig.dpi) / 72.0
point_pad_px = int(PANEL_POINT_PAD_PX + approx_r_px)

cluster_panels = []
for cid in cluster_ranked_ids:
    letter = cluster_letter(cid)
    color = cluster_colors[cid]
    idxs_sorted = cluster_sorted_member_indices.get(cid, [])

    anchor = CLUSTER_LEGEND_ANCHORS.get(letter, None)
    if anchor is None:
        anchor = _auto_fallback_anchor(letter, cid)

    _, _, box_alignment = _panel_alignment_from_anchor(anchor)
    panel_box = _make_cluster_panel(letter, cid, color, idxs_sorted)

    ab = AnnotationBbox(
        panel_box,
        xy=anchor,
        xycoords="axes fraction",
        box_alignment=box_alignment,
        frameon=True,
        bboxprops=dict(
            boxstyle="round,pad=0.28",
            facecolor="white",
            edgecolor="black",
            linewidth=CLUSTER_PANEL_EDGE_LW,
            alpha=CLUSTER_PANEL_ALPHA
        ),
        zorder=7,
        pad=0.25
    )

    try:
        ab.set_in_layout(False)
    except Exception:
        pass

    ax.add_artist(ab)
    cluster_panels.append((letter, cid, ab))

# panel 微调（只动 panel，不动点）
fig.canvas.draw()
renderer = fig.canvas.get_renderer()
offsets = _spiral_offsets(ANCHOR_NUDGE_STEP, ANCHOR_NUDGE_LEVELS)

cluster_panels_sorted = sorted(cluster_panels, key=lambda x: x[0])
placed_bboxes = []
for letter, cid, ab in cluster_panels_sorted:
    base_anchor = ab.xy
    best_anchor = base_anchor
    best_bbox = None

    for dx, dy in offsets:
        cand = (float(base_anchor[0] + dx), float(base_anchor[1] + dy))
        cand = (min(max(cand[0], 0.01), 0.99), min(max(cand[1], 0.01), 0.99))

        ab.xy = cand
        fig.canvas.draw()
        bbox = ab.get_window_extent(renderer=renderer)

        if _bbox_overlaps_points(bbox, points_disp, pad_px=point_pad_px):
            continue

        conflict = False
        for pb in placed_bboxes:
            if _bbox_overlaps_bbox(bbox, pb, pad_px=PANEL_PANEL_PAD_PX):
                conflict = True
                break
        if conflict:
            continue

        best_anchor = cand
        best_bbox = bbox
        break

    ab.xy = best_anchor
    fig.canvas.draw()
    placed_bboxes.append(best_bbox if best_bbox is not None else ab.get_window_extent(renderer=renderer))

plt.tight_layout()

cluster_plot_path = os.path.join(PDF_OUTPUT_DIR, "fig_7(a).pdf")
plt.savefig(cluster_plot_path, format="pdf", bbox_inches="tight", dpi=330)
plt.close()
print(f"指标聚类图已保存：{cluster_plot_path}")

print("\n生成完成！输出目录：", PDF_OUTPUT_DIR)
print("生成文件清单：")
print(f"1. fig_7(a).pdf -> {cluster_plot_path}")
print(f"2. fig_8(a).pdf -> {cluster_heatmap2_path}")
print(f"3. 布局缓存文件 -> {cache_path}")