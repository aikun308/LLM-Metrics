# -*- coding: utf-8 -*-
"""
Redraw correlation heatmap from a single *_metrics_relations.pkl file.

新增功能：
- 手动相关系数覆盖 MANUAL_CORR_OVERRIDES：
  允许指定任意两个指标（包括同一个指标与自身，即对角线）的相关系数，
  并体现在最终热力图（含 annot 数值）中。

指标写法支持：
  1) pkl 原始键名（如 "end_to_end_delay"）
  2) 下划线替换空格后的形式（如 "end to end delay"）
  3) 显示名（重命名后的标签，如 "End-to-end delay"）
均支持大小写不敏感与去空白规范化匹配。
"""

import os
import pickle
import argparse
from collections import Counter

import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from matplotlib import rcParams
from matplotlib.font_manager import FontProperties, FontManager, findfont


# ===================== 手动可编辑：输入/输出路径 =====================
# 5(a). 2022_paper_94_metrics_relations.pkl
# 5(b). 2022_paper_104_metrics_relations.pkl
# 5(c). 2024_paper_145_metrics_relations.pkl
# 5(d). 2022_paper4_metrics_relations.pkl
INPUT_PKL_PATH = r"E:\Research_Group\TON_2025\code\12.1\output\fig_5\input\2022_paper104_metrics_relations.pkl"
OUTPUT_DIR = r"E:\Research_Group\TON_2025\code\12.1\output\fig_5"
APPEND_UNIT_TO_LABEL = False  # 默认仅显示指标名（不追加单位）

# ===================== 指标排除列表（手动编辑） =====================
METRIC_EXCLUDE_LIST = [
    "goodput",
    "peak_age_of_information",
    "average_age_of_information",
    "packet_error_rate",
    "frame_error_rate",
]

# ===================== ✅手动相关系数覆盖（手动编辑） =====================
# 写法：("指标A", "指标B", 相关系数)
# - 指标A/B 支持：原始键名 / 空格写法 / 显示名（重命名后的标签）
# - 相关系数会被 clip 到 [-1, 1]
# - 若 A != B：会同步写入 (i,j) 与 (j,i)
# - 若 A == B：写入对角线 (i,i)
MANUAL_CORR_OVERRIDES = [
    ("End-to-end delay", "End-to-end delay", 1.00),  # ✅你要求的对角线强制为 1.00
    # 你也可以继续添加非对角线覆盖，例如：
    # ("Throughput", "End-to-end delay", -0.75),
]

# （可选）命令行也支持：--set_corr "m1,m2,val" 可重复多次
# 例如：python script.py --set_corr "Throughput,End-to-end delay,-0.75"


# ===================== 全局图像与字体配置（IEEE LaTeX 可嵌入） =====================
plt.rcParams["axes.unicode_minus"] = False

rcParams["figure.dpi"] = 330
rcParams["savefig.dpi"] = 330

# 关键：避免 Type 3 字体
rcParams["pdf.fonttype"] = 42   # TrueType
rcParams["ps.fonttype"] = 42    # TrueType

# 推荐：统一 serif（优先 Times New Roman，其次 Times/Nimbus，再到 DejaVu Serif）
rcParams["font.family"] = "serif"
rcParams["font.serif"] = [
    "Times New Roman", "Times", "Nimbus Roman", "Nimbus Roman No9 L",
    "TeX Gyre Termes", "DejaVu Serif"
]

rcParams["mathtext.fontset"] = "stix"
rcParams["axes.unicode_minus"] = False


def get_tnr_font(size=12):
    """
    Times 系列字体（英文/数字）。
    若系统无 Times New Roman，则自动回退到 DejaVu Serif（matplotlib 自带，稳定可嵌入）。
    """
    candidates = ["Times New Roman", "Times", "Nimbus Roman", "TeX Gyre Termes", "DejaVu Serif"]
    for fam in candidates:
        try:
            path = findfont(FontProperties(family=fam), fallback_to_default=False)
            if os.path.isfile(path):
                return FontProperties(family=fam, size=size)
        except Exception:
            continue
    return FontProperties(family="DejaVu Serif", size=size)


def get_chinese_font(size=12):
    """获取中文字体（跨平台尝试），若失败则使用 DejaVu Sans（仅兜底）。"""
    chinese_fonts = [
        # Windows
        "SimSun", "Microsoft YaHei", "SimHei", "STSong", "FangSong", "KaiTi",
        "Microsoft JhengHei", "DengXian",
        # macOS
        "Heiti TC", "Songti SC", "STHeiti", "Arial Unicode MS",
        # Linux
        "WenQuanYi Zen Hei", "WenQuanYi Micro Hei", "Noto Sans CJK SC",
    ]

    fm = FontManager()
    available = set(f.name for f in fm.ttflist)

    for font in chinese_fonts:
        if font in available:
            try:
                return FontProperties(family=font, size=size)
            except Exception:
                continue

    return FontProperties(family="DejaVu Sans", size=size)


def has_cjk(text: str) -> bool:
    """简单判断字符串是否包含中日韩统一表意文字，用于选择中文字体。"""
    if not isinstance(text, str):
        return False
    for ch in text:
        code = ord(ch)
        if (0x4E00 <= code <= 0x9FFF) or (0x3400 <= code <= 0x4DBF) or (0x3000 <= code <= 0x303F):
            return True
    return False


def norm_key(s: str) -> str:
    """用于匹配的统一规范化：小写 + 去首尾空白 + 合并多空格"""
    if s is None:
        return ""
    s = str(s).strip().lower()
    s = " ".join(s.split())
    return s


# 预加载字体（便于调试）
chinese_font = get_chinese_font()
tnr_font_12 = get_tnr_font(12)
print(f"当前使用的中文字体：{chinese_font.get_family()}")
print(f"当前使用的英文字体（serif）：{tnr_font_12.get_family()}")


# ===================== 指标重命名映射表（可手动编辑，优先级最高） =====================
METRIC_RENAME_MAP = {
    "end_to_end_delay": "End-to-end delay",
    "snr": "Signal-to-noise ratio",
    "jains_fairness_index": "Jain's fairness index",
    "age of information": "Age of information",
    "average age of information": "Average age of information",
    "bandwidth": "Bandwidth",
    "packet error rate": "Packet error rate",
    "peak age of information": "Peak age of information",
    "running time": "Running time",
    "throughput": "Throughput",
    "packet loss rate": "Packet loss rate",
    "queuing length": "Queuing length",
    "transmission rate": "Transmission rate",
    "bandwidth utilization": "Bandwidth utilization",
    "concurrent flows": "Concurrent flows",
    "congestion window": "Congestion window",
    "flow completion time": "Flow completion time",
    "flow size": "Flow size",
    "frame error rate": "Frame error rate",
    "number of queues": "Number of queues",
    "packet processing rate": "Packet processing rate",
    "round trip time": "Round-trip time",
    "block generation rate": "Block generation rate",
    "block production time": "Block production time",
    "propagation delay": "Propagation delay",
    "queuing delay": "Queuing delay",
    "social welfare": "Social welfare",
    "transaction generation rate": "Transaction generation rate",
}


def display_metric_name(raw_metric: str, unit: str = "", append_unit: bool = False) -> str:
    """
    指标名显示规则：
      1) METRIC_RENAME_MAP 中命中的条目优先
      2) 否则：将 "_" 统一替换为 " "
      3) 可选：追加单位 "(unit)"
    """
    if not isinstance(raw_metric, str):
        raw_metric = str(raw_metric)

    key_raw = raw_metric
    key_spaced = raw_metric.replace("_", " ")

    if key_raw in METRIC_RENAME_MAP:
        name = METRIC_RENAME_MAP[key_raw]
    elif key_spaced in METRIC_RENAME_MAP:
        name = METRIC_RENAME_MAP[key_spaced]
    else:
        name = key_spaced

    name = name.strip()

    if append_unit and unit and isinstance(unit, str) and unit.strip():
        name = f"{name} ({unit.strip()})"

    return name


def make_unique_labels(labels, originals):
    """重命名后若发生重复标签，自动消歧（追加原始名后缀）"""
    cnt = Counter(labels)
    if all(v == 1 for v in cnt.values()):
        return labels

    new_labels = []
    used = set()
    for lab, orig in zip(labels, originals):
        if cnt[lab] == 1 and lab not in used:
            new_labels.append(lab)
            used.add(lab)
            continue

        candidate = f"{lab} [{orig}]"
        k = 2
        while candidate in used:
            candidate = f"{lab} [{orig}]#{k}"
            k += 1
        new_labels.append(candidate)
        used.add(candidate)

    print("Warning: Duplicate metric labels after renaming; auto-disambiguated with suffixes.")
    return new_labels


def should_exclude_metric(metric_key: str, unit: str, append_unit: bool, exclude_norm_set: set) -> bool:
    """
    判断某个指标是否需要被排除。
    支持匹配：
      - 原始键名 metric_key
      - metric_key 的空格形式（_ -> space）
      - 显示名（经过重命名/单位拼接后的 label）
    """
    if not exclude_norm_set:
        return False

    raw = norm_key(metric_key)
    spaced = norm_key(metric_key.replace("_", " "))
    label = norm_key(display_metric_name(metric_key, unit=unit, append_unit=append_unit))

    return (raw in exclude_norm_set) or (spaced in exclude_norm_set) or (label in exclude_norm_set)


def build_correlation_matrix(relations: dict, ordered_metric_keys: list) -> np.ndarray:
    """
    构造 n*n 相关系数矩阵：
    - 对角线=1
    - 非对角由 relations 填充（key 形如 "m1-m2"）
    """
    n = len(ordered_metric_keys)
    mat = np.zeros((n, n), dtype=float)
    np.fill_diagonal(mat, 1.0)

    index = {m: i for i, m in enumerate(ordered_metric_keys)}

    if isinstance(relations, dict):
        for pair, corr in relations.items():
            if not isinstance(pair, str) or "-" not in pair:
                continue
            parts = pair.split("-")
            if len(parts) != 2:
                continue
            m1, m2 = parts[0], parts[1]
            if m1 not in index or m2 not in index:
                continue
            i, j = index[m1], index[m2]
            try:
                v = float(corr)
                v = max(min(v, 1.0), -1.0)
            except Exception:
                v = 0.0
            mat[i, j] = v
            mat[j, i] = v

    return mat


def build_metric_alias_map(ordered_metric_keys: list, metrics_units: dict, append_unit: bool) -> dict:
    """
    构建 alias -> raw_key 的映射，便于手动覆盖时用多种写法定位指标。
    会加入：
      - raw_key
      - raw_key 空格形式（_ -> space）
      - 显示名（display label）
    都做 norm_key 规范化。
    """
    alias = {}
    for k in ordered_metric_keys:
        unit = metrics_units.get(k, "")
        raw = norm_key(k)
        spaced = norm_key(k.replace("_", " "))
        label = norm_key(display_metric_name(k, unit=unit, append_unit=append_unit))

        alias[raw] = k
        alias[spaced] = k
        alias[label] = k

    return alias


def apply_manual_corr_overrides(corr_mat: np.ndarray,
                               ordered_metric_keys: list,
                               alias_map: dict,
                               overrides: list):
    """
    将 overrides 中指定的 pair 强制写入 corr_mat。
    overrides: list of (m1, m2, v)
    """
    if not overrides:
        return

    index = {m: i for i, m in enumerate(ordered_metric_keys)}

    for item in overrides:
        if not (isinstance(item, (list, tuple)) and len(item) == 3):
            print(f"Warning: invalid override entry (skip): {item}")
            continue

        m1_in, m2_in, v_in = item[0], item[1], item[2]

        m1 = alias_map.get(norm_key(m1_in), None)
        m2 = alias_map.get(norm_key(m2_in), None)

        if m1 is None or m2 is None:
            print(f"Warning: override pair not found after filtering (skip): ({m1_in}, {m2_in})")
            continue

        try:
            v = float(v_in)
        except Exception:
            print(f"Warning: override value not float (skip): ({m1_in}, {m2_in}, {v_in})")
            continue

        v = max(min(v, 1.0), -1.0)

        if m1 == m2:
            # ✅允许覆盖对角线
            i = index[m1]
            corr_mat[i, i] = v
            print(f"Applied manual override (diagonal): ({m1}) = {v:+.4f}")
        else:
            i, j = index[m1], index[m2]
            corr_mat[i, j] = v
            corr_mat[j, i] = v
            print(f"Applied manual override: ({m1} , {m2}) = {v:+.4f}")


def parse_set_corr_args(arg_list):
    """
    解析命令行 --set_corr "m1,m2,val"
    返回 list of (m1, m2, val)
    """
    out = []
    for s in (arg_list or []):
        if not isinstance(s, str):
            continue
        parts = [p.strip() for p in s.split(",")]
        if len(parts) != 3:
            print(f"Warning: --set_corr format must be 'm1,m2,val' (skip): {s}")
            continue
        m1, m2, v = parts[0], parts[1], parts[2]
        out.append((m1, m2, v))
    return out


def redraw_heatmap_from_pkl(pkl_path: str,
                           outdir: str = None,
                           append_unit: bool = False,
                           manual_overrides: list = None) -> str:
    if not os.path.isfile(pkl_path):
        raise FileNotFoundError(f"PKL not found: {pkl_path}")

    with open(pkl_path, "rb") as f:
        data = pickle.load(f)

    if not isinstance(data, dict):
        raise ValueError("Invalid pkl: root object is not a dict.")

    metrics = data.get("metrics", {})
    relations = data.get("relations", {})

    if not isinstance(metrics, dict) or not metrics:
        raise ValueError("Invalid pkl: 'metrics' is missing or empty.")
    if not isinstance(relations, dict) or not relations:
        print("Warning: 'relations' is missing/empty; heatmap will contain only diagonal ones (unless overrides set).")

    # ============ 先做排除过滤，再排序 ============
    exclude_norm_set = set(norm_key(x) for x in METRIC_EXCLUDE_LIST if str(x).strip())

    all_metric_keys = list(metrics.keys())
    kept_metric_keys = []
    for k in all_metric_keys:
        unit = metrics.get(k, "")
        if should_exclude_metric(k, unit=unit, append_unit=append_unit, exclude_norm_set=exclude_norm_set):
            continue
        kept_metric_keys.append(k)

    if len(kept_metric_keys) == 0:
        raise ValueError("All metrics are excluded by METRIC_EXCLUDE_LIST; nothing to draw.")

    ordered_metric_keys = sorted(kept_metric_keys)

    # 标签（过滤后）
    raw_units = {k: metrics.get(k, "") for k in ordered_metric_keys}
    labels = [display_metric_name(k, raw_units.get(k, ""), append_unit=append_unit) for k in ordered_metric_keys]
    labels = make_unique_labels(labels, ordered_metric_keys)

    # 相关矩阵
    corr_mat = build_correlation_matrix(relations, ordered_metric_keys)

    # ============ 应用手动相关系数覆盖（含对角线） ============
    alias_map = build_metric_alias_map(ordered_metric_keys, raw_units, append_unit=append_unit)
    apply_manual_corr_overrides(
        corr_mat=corr_mat,
        ordered_metric_keys=ordered_metric_keys,
        alias_map=alias_map,
        overrides=manual_overrides or []
    )

    # 输出路径
    if outdir is None or not str(outdir).strip():
        outdir = os.path.dirname(os.path.abspath(pkl_path))
    os.makedirs(outdir, exist_ok=True)

    base = os.path.splitext(os.path.basename(pkl_path))[0]
    base = base.replace("_metrics_relations", "")
    out_pdf = os.path.join(outdir, f"{base}_heatmap.pdf")

    # 字体对象（统一控制，降低回退概率）
    tnr_32 = get_tnr_font(32)

    # ===================== GridSpec 固定颜色条高度与热力图对齐 =====================
    fig = plt.figure(figsize=(16, 16))
    gs = fig.add_gridspec(nrows=1, ncols=2, width_ratios=[24, 1], wspace=0.05)
    ax = fig.add_subplot(gs[0, 0])
    cax = fig.add_subplot(gs[0, 1])

    sns.heatmap(
        corr_mat,
        annot=True,
        fmt=".2f",
        cmap="vlag",
        center=0,
        vmin=-1,
        vmax=1,
        xticklabels=labels,
        yticklabels=labels,
        ax=ax,
        cbar_ax=cax,
        linewidths=0.5,
        annot_kws={"fontsize": 34, "fontproperties": tnr_32},
        square=True,
        cbar_kws={"shrink": 1.0},
    )

    ax.set_aspect("equal", adjustable="box")

    # 坐标轴刻度字体
    for t in ax.get_xticklabels():
        fp = chinese_font if has_cjk(t.get_text()) else tnr_32
        t.set_fontproperties(fp)
        t.set_rotation(45)
        t.set_ha("right")

    for t in ax.get_yticklabels():
        fp = chinese_font if has_cjk(t.get_text()) else tnr_32
        t.set_fontproperties(fp)
        t.set_rotation(0)

    # 颜色条刻度字体
    cax.tick_params(labelsize=32)
    for t in cax.get_yticklabels():
        t.set_fontproperties(tnr_32)

    ax.grid(True, linestyle="--", linewidth=0.5, color="gray", alpha=0.3)

    fig.subplots_adjust(left=0.08, right=0.95, bottom=0.10, top=0.98, wspace=0.05)
    fig.savefig(out_pdf, format="pdf", bbox_inches="tight", dpi=330)
    plt.close(fig)

    print(f"Heatmap saved: {out_pdf}")
    return out_pdf


def main():
    parser = argparse.ArgumentParser(description="Redraw correlation heatmap from *_metrics_relations.pkl")
    parser.add_argument("--pkl", default=None, help="Path to a single *_metrics_relations.pkl")
    parser.add_argument("--outdir", default=None, help="Output directory (default: same as pkl)")
    parser.add_argument(
        "--append_unit",
        action="store_true",
        help="Append unit to labels, e.g., 'Throughput (bps)'. Default: off."
    )
    parser.add_argument(
        "--set_corr",
        action="append",
        default=[],
        help="Manual override correlation as 'm1,m2,val'. Can be repeated."
    )
    args = parser.parse_args()

    pkl_path = args.pkl if args.pkl else INPUT_PKL_PATH
    outdir = args.outdir if args.outdir else OUTPUT_DIR
    append_unit = args.append_unit if args.append_unit else APPEND_UNIT_TO_LABEL

    if not pkl_path or not str(pkl_path).strip():
        raise ValueError("Please set INPUT_PKL_PATH at the top, or pass --pkl.")

    cli_overrides = parse_set_corr_args(args.set_corr)
    merged_overrides = list(MANUAL_CORR_OVERRIDES) + cli_overrides

    redraw_heatmap_from_pkl(
        pkl_path,
        outdir=outdir,
        append_unit=append_unit,
        manual_overrides=merged_overrides
    )


if __name__ == "__main__":
    main()
