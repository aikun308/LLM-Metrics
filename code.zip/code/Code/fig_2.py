import os
import pickle
import time
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from collections import Counter, defaultdict
from matplotlib import rcParams
from matplotlib.font_manager import FontProperties, FontManager
from matplotlib.patches import Patch

# ===================== 核心配置区（手动调整参数在此处） =====================
PKL_INPUT_DIR = "E:/Research_Group/TON_2025/code/12.1/output/output_pkl/all"  # 输入pkl目录
PDF_OUTPUT_DIR = "E:/Research_Group/TON_2025/code/12.1/output/fig_2"        # 输出目录

MIN_METRIC_FREQ = 20

EXCLUDE_METRICS = ['bit_error_rate', 'frame_error_rate']
METRIC_MAPPING = {}

# ===================== Matplotlib 输出到 IEEE/LaTeX 兼容的 PDF 字体嵌入设置 =====================
# 关键：避免 Type 3 字体，使用 TrueType(42) 嵌入，通常可被 IEEE LaTeX 模板顺利处理
rcParams['pdf.fonttype'] = 42
rcParams['ps.fonttype'] = 42
rcParams['pdf.use14corefonts'] = False  # 显式关闭“只用14种核心字体”（否则可能不嵌入）
rcParams['figure.dpi'] = 330
rcParams['savefig.dpi'] = 330
rcParams['axes.unicode_minus'] = False

# 默认字体族尽量贴近论文排版（即使某些文本未显式指定 FontProperties 也更稳）
rcParams['font.family'] = 'serif'
rcParams['font.serif'] = [
    'Times New Roman', 'Times', 'Nimbus Roman', 'Liberation Serif', 'DejaVu Serif'
]
# 备用 sans-serif（仅兜底，不强依赖；你的图例/文本主要是英文）
rcParams['font.sans-serif'] = [
    'DejaVu Sans', 'Arial', 'Liberation Sans',
    'SimSun', 'Microsoft YaHei', 'SimHei', 'STSong'
]

SCENE_NAME_MAPPING = {
    "1.1 互联网与IP网络": "Internet & IP networks",
    "1.2 软件定义网络": "Software-defined networking",
    "1.3 NFV/虚拟化网络": "Network functions virtualization",
    "1.4 确定性网络": "Deterministic networking",
    "1.5 可重构网络试验设施": "Reconfigurable network testbed infrastructure",
    "2.1 网络切片与多租户管理": "Network slicing & multi-tenant management",
    "2.2 多模态/集成网络架构": "Multi-modal/integrated network architectures",
    "3.1 蜂窝移动通信网络": "Cellular mobile communication networks",
    "3.2 移动自组织网络": "Mobile ad hoc networks",
    "3.3 车联网": "Vehicular networks",
    "3.4 无人机网络": "UAV networks",
    "3.5 空天地一体化网络": "Space–air–ground integrated networks",
    "3.6 水下通信网络": "Underwater communication networks",
    "4.1 无线传感器网络": "Wireless sensor networks",
    "4.2 物联网平台与应用": "IoT platforms & applications",
    "4.3 工业物联网/工业控制网络": "Industrial IoT/control networks",
    "4.4 信息物理系统": "Cyber-physical systems",
    "5.1 数据中心网络": "Data center networks",
    "5.2 云计算网络": "Cloud computing networks",
    "5.3 边缘计算/雾计算网络": "Edge/fog computing networks",
    "5.4 算力网络": "Computing power networks",
    "6.1 卫星通信网络": "Satellite communication networks",
    "6.2 内容分发与点对点网络": "Content delivery & P2P networks",
    "6.3 区块链分布式网络": "Blockchain distributed networks",
    "6.4 绿色与能源感知网络": "Green & energy-aware networking",
    "6.5 容迟容断网络": "Delay tolerant networks",
    "6.6 光传输与承载网络": "Optical transport & bearer networks",

    "网络架构与使能技术": "Network architecture & enabling technologies",
    "网络虚拟化与切片架构": "Network virtualization & slicing architecture",
    "移动与无线网络": "Mobile & wireless networks",
    "物联与控制系统": "IoT & control systems",
    "计算与数据中心网络": "Computing & data center networks",
    "其他专用网络": "Other specialized networks"
}

# ===================== 字体工具函数 =====================
def get_tnr_font(size=10):
    # 统一走 serif 体系，配合 pdf.fonttype=42，确保 PDF 中可嵌入且避免 Type3
    try:
        return FontProperties(family='Times New Roman', size=size)
    except Exception:
        return FontProperties(family='DejaVu Serif', size=size)


def get_chinese_font(size=10):
    # 若图中确实出现中文（理论上你的扇形图已做英文映射），此处兜底
    chinese_fonts = [
        'SimSun', 'Microsoft YaHei', 'SimHei', 'STSong', 'FangSong', 'KaiTi',
        'Microsoft JhengHei', 'DengXian',
        'Heiti TC', 'Songti SC', 'STHeiti', 'Arial Unicode MS',
        'WenQuanYi Zen Hei', 'WenQuanYi Micro Hei', 'Noto Sans CJK SC',
        'DejaVu Sans'
    ]
    font_manager = FontManager()
    available_fonts = set(f.name for f in font_manager.ttflist)
    for font in chinese_fonts:
        if font in available_fonts:
            try:
                return FontProperties(family=font, size=size)
            except Exception:
                continue
    print("警告：未找到可用中文字体，使用默认字体（可能无法正常显示中文）")
    return FontProperties(size=size)


def contains_chinese(text: str) -> bool:
    return any('\u4e00' <= ch <= '\u9fff' for ch in text)


chinese_font = get_chinese_font()
tnr_font = get_tnr_font()
print(f"当前使用的中文字体：{chinese_font.get_family()}")
print(f"当前使用的英文字体：{tnr_font.get_family()}")

os.makedirs(PDF_OUTPUT_DIR, exist_ok=True)
print(f"开始加载{PKL_INPUT_DIR}目录下的pkl文件...")

# ===================== 数据加载与统计 =====================
metric_counter = Counter()
scene_counter = Counter()
metric_explanations_accumulator = defaultdict(set)
metric_originals_accumulator = defaultdict(set)
metric_units_accumulator = defaultdict(set)

# 分场景指标频次统计：与全局口径一致，按“论文是否出现该指标”计数
scene_metric_counter = defaultdict(Counter)

pkl_files = [f for f in os.listdir(PKL_INPUT_DIR) if f.endswith("_metrics_relations.pkl")]
actual_file_count = len(pkl_files)
print(f"成功找到{actual_file_count}个符合条件的pkl文件（后缀：_metrics_relations.pkl）")

for idx, pkl_file in enumerate(pkl_files, 1):
    pkl_path = os.path.join(PKL_INPUT_DIR, pkl_file)
    try:
        with open(pkl_path, 'rb') as f:
            data = pickle.load(f)

        # 1) 指标处理：映射→剔除→统计
        file_metrics = data.get("metrics", {})
        processed_metrics = {}
        for raw_metric, unit in file_metrics.items():
            normalized_metric = raw_metric.lower().replace(" ", "_").replace("-", "_")
            mapped_metric = METRIC_MAPPING.get(normalized_metric, normalized_metric)
            if mapped_metric in EXCLUDE_METRICS:
                continue
            processed_metrics[mapped_metric] = unit
            metric_originals_accumulator[mapped_metric].add(raw_metric)
            if unit and isinstance(unit, str):
                metric_units_accumulator[mapped_metric].add(unit.strip())

        # 全局指标出现频次：按“论文是否出现该指标”计数
        metric_counter.update(set(processed_metrics.keys()))

        # 2) 场景统计
        scene = data.get("network_type", "未知")
        scene_counter[scene] += 1

        # 3) 分场景指标出现频次：按“论文是否出现该指标”计数
        scene_metric_counter[scene].update(set(processed_metrics.keys()))

        # 4) 指标解释
        file_explanations = data.get("metric_explanations", {})
        for metric, explanation in file_explanations.items():
            if isinstance(explanation, str) and explanation.strip():
                normalized_metric = metric.lower().replace(" ", "_").replace("-", "_")
                mapped_metric = METRIC_MAPPING.get(normalized_metric, normalized_metric)
                if mapped_metric in EXCLUDE_METRICS:
                    continue
                metric_explanations_accumulator[mapped_metric].add(explanation.strip())

        if idx % 50 == 0:
            print(f"已加载{idx}/{actual_file_count}个文件...")
    except Exception as e:
        print(f"加载文件{pkl_file}失败：{str(e)}")

print("数据加载与统计完成！")
print(f"共统计到{len(metric_counter)}个不同指标，{len(scene_counter)}个不同网络场景")

# ===================== 高频指标筛选 =====================
high_freq_metrics = [m for m, f in metric_counter.most_common() if f >= MIN_METRIC_FREQ]
if not high_freq_metrics:
    raise ValueError(f"无满足条件的高频指标（需出现≥{MIN_METRIC_FREQ}次）")

# ===================== 保存统计信息到文本文件 =====================
stats_txt_path = os.path.join(PDF_OUTPUT_DIR, "Integrated_Statistics.txt")
all_networks = scene_counter.most_common()

# 全局Top-20高频指标集合（不分场景，按出现论文数降序）
global_top20_metrics = [m for m, _ in metric_counter.most_common(20)]
global_top20_set = set(global_top20_metrics)

core_metrics_detail = []
for metric in high_freq_metrics:
    freq = metric_counter[metric]
    coverage = (freq / actual_file_count) * 100 if actual_file_count > 0 else 0.0
    original_names = metric_originals_accumulator.get(metric, set())
    original_names_str = ", ".join(sorted(original_names)) if original_names else "无原始名称记录"
    units = metric_units_accumulator.get(metric, set())
    units_str = ", ".join(sorted(units)) if units else "无单位记录"
    explanations = metric_explanations_accumulator.get(metric, set())
    explanation_str = "；".join(sorted(explanations)) if explanations else "未收集到相关解释"
    core_metrics_detail.append({
        "rank": len(core_metrics_detail) + 1,
        "metric": metric,
        "freq": freq,
        "coverage": coverage,
        "original_names": original_names_str,
        "units": units_str,
        "explanation": explanation_str
    })


def _topk_with_ties(counter: Counter, k: int = 7, restrict_set=None):
    """
    返回按出现频次降序排列的 (metric, freq) 列表：
    - 取前k名；若第k名处存在并列，则将并列项一并返回；
    - restrict_set 不为 None 时，仅在该集合内筛选。
    """
    items = []
    for m, f in counter.items():
        if f <= 0:
            continue
        if restrict_set is not None and m not in restrict_set:
            continue
        items.append((m, f))
    if not items:
        return []
    items_sorted = sorted(items, key=lambda x: (-x[1], x[0]))  # 频次降序，名称升序（保证可复现）
    if len(items_sorted) <= k:
        return items_sorted
    kth_freq = items_sorted[k - 1][1]
    return [it for it in items_sorted if it[1] >= kth_freq]


with open(stats_txt_path, 'w', encoding='utf-8') as f:
    f.write("=" * 100 + "\n")
    f.write("                      网络通信论文指标统计核心信息汇总\n")
    f.write("=" * 100 + "\n\n")
    f.write("【基础统计信息】\n")
    f.write("-" * 50 + "\n")
    f.write(f"统计时间：{time.strftime('%Y-%m-%d %H:%M:%S', time.localtime())}\n")
    f.write(f"数据来源目录：{PKL_INPUT_DIR}\n")
    f.write(f"加载的pkl文件总数：{actual_file_count}个（筛选条件：后缀为_metrics_relations.pkl）\n")
    f.write(f"核心指标筛选阈值：出现频次≥{MIN_METRIC_FREQ}次\n")
    f.write(f"手动剔除的无关指标：{EXCLUDE_METRICS}\n")
    f.write(f"手动指标映射规则：{METRIC_MAPPING}\n")
    f.write(f"筛选后核心指标数量：{len(high_freq_metrics)}个\n")
    f.write(f"统计到的网络场景总数：{len(scene_counter)}个\n\n")

    f.write("=" * 100 + "\n")
    f.write("【一、涉及的所有网络类型及统计信息】\n")
    f.write("=" * 100 + "\n\n")
    for idx, (network, freq) in enumerate(all_networks, 1):
        percentage = (freq / actual_file_count) * 100 if actual_file_count > 0 else 0.0
        f.write(f"{idx:2d}. 网络类型：{network}\n")
        f.write(f"    出现频次：{freq:2d}次\n")
        f.write(f"    占比：{percentage:.1f}%\n\n")

    f.write("=" * 100 + "\n")
    f.write("【二、符合条件的核心指标统计（出现频次≥{}次）】\n".format(MIN_METRIC_FREQ))
    f.write("=" * 100 + "\n\n")
    for item in core_metrics_detail:
        f.write(f"{item['rank']:2d}. 指标名称：{item['metric']}\n")
        f.write(f"    出现频次：{item['freq']:2d}次\n")
        f.write(f"    覆盖率：{item['coverage']:.1f}%（{item['freq']}/{actual_file_count}篇论文）\n")
        f.write(f"    原始名称变体：{item['original_names']}\n")
        f.write(f"    单位：{item['units']}\n")
        f.write(f"    指标解释：{item['explanation']}\n\n")

    f.write("=" * 100 + "\n")
    f.write("统计说明：\n")
    f.write("1. 指标覆盖率=该指标出现的论文数/总加载论文数×100%\n")
    f.write("2. 原始名称变体已按映射规则统一为标准名称，手动剔除无关指标\n")
    f.write("3. 分场景指标频次按“某篇论文是否出现该指标”计数，同一论文内重复出现不重复计数\n")
    f.write("=" * 100 + "\n")

    # ===================== 分场景Top-7指标统计 =====================
    f.write("\n")
    f.write("=" * 100 + "\n")
    f.write("【三、各网络场景内出现频次排名前7的指标列表（若第7名并列则扩展列出）】\n")
    f.write("=" * 100 + "\n\n")
    for idx, (network, freq) in enumerate(all_networks, 1):
        f.write(f"{idx:2d}. 网络类型：{network}\n")
        f.write(f"    样本数：{freq:2d}篇\n")
        c = scene_metric_counter.get(network, Counter())
        top_list = _topk_with_ties(c, k=7, restrict_set=None)
        if not top_list:
            f.write("    Top指标：无可用指标记录\n\n")
            continue
        f.write("    Top指标（指标名 — 出现频次）：\n")
        for r, (m, ff) in enumerate(top_list, 1):
            f.write(f"      {r:2d}) {m} — {ff}次\n")
        f.write("\n")

    f.write("=" * 100 + "\n")
    f.write("【四、各网络场景内出现频次排名前7且属于“全局Top-20高频指标集合”的指标列表】\n")
    f.write("=" * 100 + "\n\n")
    f.write("全局Top-20高频指标集合（不分场景，按出现论文数降序）：\n")
    f.write("  " + ", ".join(global_top20_metrics) + "\n\n")
    for idx, (network, freq) in enumerate(all_networks, 1):
        f.write(f"{idx:2d}. 网络类型：{network}\n")
        f.write(f"    样本数：{freq:2d}篇\n")
        c = scene_metric_counter.get(network, Counter())
        top_list_in_global20 = _topk_with_ties(c, k=7, restrict_set=global_top20_set)
        if not top_list_in_global20:
            f.write("    Top指标（∩全局Top-20）：不足7个（本场景与全局Top-20无交集或无可用指标）\n\n")
            continue
        f.write("    Top指标（∩全局Top-20，指标名 — 出现频次）：\n")
        for r, (m, ff) in enumerate(top_list_in_global20, 1):
            f.write(f"      {r:2d}) {m} — {ff}次\n")
        if len(top_list_in_global20) < 7:
            f.write(f"    说明：本场景满足条件的指标不足7个，已据实列出（共{len(top_list_in_global20)}个）。\n")
        f.write("\n")

print(f"统计文本已保存至：{stats_txt_path}")

# ===================== 网络场景统计扇形图（6类聚合） =====================
print("开始生成网络场景统计扇形图（6类聚合，保持原 muted 配色）...")

EXCLUDE_SCENE_FROM_PIE = "未分类"

CATEGORY_ORDER = [
    "网络架构与使能技术",
    "网络虚拟化与切片架构",
    "移动与无线网络",
    "物联与控制系统",
    "计算与数据中心网络",
    "其他专用网络",
]

CATEGORY_SCENES = {
    "网络架构与使能技术": [
        "1.1 互联网与IP网络", "1.2 软件定义网络", "1.3 NFV/虚拟化网络", "1.4 确定性网络", "1.5 可重构网络试验设施"
    ],
    "网络虚拟化与切片架构": [
        "2.1 网络切片与多租户管理", "2.2 多模态/集成网络架构"
    ],
    "移动与无线网络": [
        "3.1 蜂窝移动通信网络", "3.2 移动自组织网络", "3.3 车联网", "3.4 无人机网络",
        "3.5 空天地一体化网络", "3.6 水下通信网络"
    ],
    "物联与控制系统": [
        "4.1 无线传感器网络", "4.2 物联网平台与应用", "4.3 工业物联网/工业控制网络", "4.4 信息物理系统"
    ],
    "计算与数据中心网络": [
        "5.1 数据中心网络", "5.2 云计算网络", "5.3 边缘计算/雾计算网络", "5.4 算力网络"
    ],
    "其他专用网络": [
        "6.1 卫星通信网络", "6.2 内容分发与点对点网络", "6.3 区块链分布式网络",
        "6.4 绿色与能源感知网络", "6.5 容迟容断网络", "6.6 光传输与承载网络"
    ],
}

# 反向索引：scene -> category
scene_to_category = {}
for cat, scenes in CATEGORY_SCENES.items():
    for s in scenes:
        scene_to_category[s] = cat

scene_freq_excluded = {s: f for s, f in scene_counter.items() if s != EXCLUDE_SCENE_FROM_PIE}
total_pie = sum(scene_freq_excluded.values())

pie_path_stat = os.path.join(PDF_OUTPUT_DIR, "fig_2.pdf")

if total_pie <= 0:
    print("警告：剔除“未分类”后无可用于扇形图的场景数据，跳过生成fig_2.pdf")
else:
    category_freq = {cat: 0 for cat in CATEGORY_ORDER}
    for scene, freq in scene_freq_excluded.items():
        cat = scene_to_category.get(scene, "其他专用网络")
        category_freq[cat] += freq

    cat_values = [category_freq[c] for c in CATEGORY_ORDER]
    cat_pcts = [(v / total_pie) * 100 if total_pie > 0 else 0.0 for v in cat_values]

    # 保持原脚本配色不变
    category_colors = sns.color_palette("muted", n_colors=len(CATEGORY_ORDER))

    SMALL_PCT_THRESHOLD = 2.0
    TARGET_SMALL_CAT = "网络虚拟化与切片架构"  # Network Virtualization & Slicing Architecture

    explode = []
    for cat, pct in zip(CATEGORY_ORDER, cat_pcts):
        if (pct < SMALL_PCT_THRESHOLD) or (cat == TARGET_SMALL_CAT):
            explode.append(0.06)
        else:
            explode.append(0.0)

    def autopct_fmt(pct):
        return f"{pct:.1f}%" if pct >= SMALL_PCT_THRESHOLD else ""

    fig, ax = plt.subplots(figsize=(7, 7), dpi=330)
    fig.set_dpi(330)
    ax.set_aspect('equal')

    wedges, texts, autotexts = ax.pie(
        cat_values,
        labels=None,
        startangle=90,
        counterclock=False,
        colors=category_colors,
        autopct=autopct_fmt,
        pctdistance=0.62,
        explode=explode,
        wedgeprops=dict(edgecolor='white', linewidth=1.2)
    )

    for t in autotexts:
        t.set_fontproperties(get_tnr_font(12))
        t.set_color("black")

    # 外部标注：对小扇形统一外置；目标小类单独使用直线标注
    for wedge, pct, cat in zip(wedges, cat_pcts, CATEGORY_ORDER):
        need_outside = (pct < SMALL_PCT_THRESHOLD) or (cat == TARGET_SMALL_CAT)
        if not need_outside:
            continue

        theta = (wedge.theta1 + wedge.theta2) / 2.0
        theta_rad = np.deg2rad(theta)

        # 引导线起点：扇形外缘
        r_arrow = 1.0
        x_arrow = r_arrow * np.cos(theta_rad)
        y_arrow = r_arrow * np.sin(theta_rad)

        if cat == TARGET_SMALL_CAT:
            x_text, y_text = 1.05, -0.45
            ha = "right"
            arrowprops = dict(
                arrowstyle="-",
                lw=0.9,
                color="black",
                shrinkA=0,
                shrinkB=0
            )
        else:
            r_text = 1.18
            x_text = r_text * np.cos(theta_rad)
            y_text = r_text * np.sin(theta_rad)
            ha = "left" if x_text >= 0 else "right"
            arrowprops = dict(
                arrowstyle="-",
                lw=0.9,
                color="black",
                shrinkA=0,
                shrinkB=0,
                connectionstyle="arc3,rad=0.15"
            )

        ax.annotate(
            f"{pct:.1f}%",
            xy=(x_arrow, y_arrow),
            xytext=(x_text, y_text),
            ha=ha,
            va="center",
            fontsize=12,
            fontproperties=get_tnr_font(12),
            arrowprops=arrowprops
        )

    # ===================== 右侧图例（大类按占比降序；子场景逐行+占比；子场景在类内降序） =====================
    category_info = []

    # 子场景行首黑色实点
    LEGEND_SUBITEM_PREFIX = "• "

    for cat, value, pct, color in zip(CATEGORY_ORDER, cat_values, cat_pcts, category_colors):
        cat_eng = SCENE_NAME_MAPPING.get(cat, cat)

        sub_scenes = CATEGORY_SCENES.get(cat, [])
        sub_items = [(s, scene_freq_excluded.get(s, 0)) for s in sub_scenes]
        sub_items_sorted = sorted(sub_items, key=lambda x: (x[1], x[0]), reverse=True)
        if any(f > 0 for _, f in sub_items_sorted):
            sub_items_sorted = [(s, f) for s, f in sub_items_sorted if f > 0]

        sub_lines = []
        for s, f in sub_items_sorted:
            s_eng = SCENE_NAME_MAPPING.get(s, s)
            s_pct = (f / total_pie) * 100 if total_pie > 0 else 0.0
            sub_lines.append(f"{LEGEND_SUBITEM_PREFIX}{s_eng} ({s_pct:.1f}%)")

        label = f"{cat_eng} ({pct:.1f}%)"
        if len(sub_lines) > 0:
            label = label + "\n" + "\n".join(sub_lines)

        category_info.append({
            "cat": cat,
            "value": value,
            "pct": pct,
            "color": color,
            "label": label
        })

    category_info_sorted = sorted(category_info, key=lambda d: d["value"], reverse=True)

    legend_handles = [Patch(facecolor=d["color"], edgecolor='white', linewidth=1.0) for d in category_info_sorted]
    legend_labels = [d["label"] for d in category_info_sorted]

    plt.subplots_adjust(right=0.84)
    leg = ax.legend(
        legend_handles,
        legend_labels,
        loc='center left',
        bbox_to_anchor=(0.965, 0.5),
        frameon=True,
        fontsize=11,
        ncol=1,
        borderaxespad=0.0,
        handlelength=1.2,
        handletextpad=0.6,
        labelspacing=0.9
    )

    # 图例外框：黑色
    leg_frame = leg.get_frame()
    leg_frame.set_edgecolor('black')
    leg_frame.set_linewidth(1.0)

    for txt, label_str in zip(leg.get_texts(), legend_labels):
        txt.set_fontproperties(get_chinese_font(11) if contains_chinese(label_str) else get_tnr_font(11))

    ax.set_axis_off()

    plt.savefig(pie_path_stat, format="pdf", bbox_inches="tight", dpi=330, facecolor='white')
    plt.close()
    print(f"网络场景统计扇形图已保存至：{pie_path_stat}")

print("\n输出文件生成完成！输出目录：", PDF_OUTPUT_DIR)
print(f"1. Integrated_Statistics.txt -> {stats_txt_path}")
print(f"2. fig_2.pdf -> {pie_path_stat}")