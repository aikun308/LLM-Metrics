# -*- coding: utf-8 -*-
"""
Sankey（桑基图）生成脚本（PDF 导出）

✅ 目标：输出 IEEE LaTeX 友好 PDF（尽量确保字体嵌入/子集化）
实现方式：
1) plotly+kaleido 导出 raw PDF
2) Ghostscript pdfwrite 后处理：EmbedAllFonts/SubSetFonts

重要提示：
- 如果图中仍含中文字符，可能引入 CJK 字体/Type3 等问题；建议尽量通过 NAME_MAP 全部英文化。
- 当前版本不再使用手工维护的 RAW_ROWS，而是从统计中间数据 .pkl 自动生成桑基图输入数据。
"""

import os
import re
import pickle
import glob
import shutil
import subprocess
from collections import defaultdict

import plotly.graph_objects as go


# ===================== 0) 强制要求“字体嵌入后处理” =====================
# True：找不到 Ghostscript 就直接报错退出（避免你误以为已嵌入）
# False：找不到 Ghostscript 就回退使用 raw PDF
REQUIRE_FONT_EMBEDDING = True

# 可选：手动指定 Ghostscript 可执行文件路径（优先级最高）
# 例如：r"C:\Program Files\gs\gs10.06.0\bin\gswin64c.exe"
GS_EXE = ""  # 也可用环境变量 GS_EXE 覆盖


# ======================================================================
# ✅ 1) 名称映射字典（请在这里手动编辑）
# ======================================================================
NAME_MAP = {
    "互联网与IP网络": "Internet & IP networks",
    "软件定义网络": "Software-defined networking",
    "NFV/虚拟化网络": "Network functions virtualization",
    "确定性网络": "Deterministic networking",
    "可重构网络试验设施": "Reconfigurable network testbed infrastructure",
    "网络切片与多租户管理": "Network slicing & multi-tenant management",
    "多模态/集成网络架构": "Multi-modal/integrated network architectures",
    "蜂窝移动通信网络": "Cellular mobile communication networks",
    "移动自组织网络": "Mobile ad hoc networks",
    "车联网": "Vehicular networks",
    "无人机网络": "UAV networks",
    "空天地一体化网络": "Space–air–ground integrated networks",
    "水下通信网络": "Underwater communication networks",
    "无线传感器网络": "Wireless sensor networks",
    "物联网平台与应用": "IoT platforms & applications",
    "工业物联网/工业控制网络": "Industrial IoT/control networks",
    "信息物理系统": "Cyber-physical systems",
    "数据中心网络": "Data center networks",
    "云计算网络": "Cloud computing networks",
    "边缘计算/雾计算网络": "Edge/fog computing networks",
    "算力网络": "Computing power networks",
    "卫星通信网络": "Satellite communication networks",
    "内容分发与点对点网络": "Content delivery & P2P networks",
    "区块链分布式网络": "Blockchain distributed networks",
    "绿色与能源感知网络": "Green & energy-aware networking",
    "容迟容断网络": "Delay tolerant network",
    "光传输与承载网络": "Optical transport & bearer networks",

    "网络架构与使能技术": "Network architecture & enabling technologies",
    "网络虚拟化与切片架构": "Network virtualization & slicing architecture",
    "移动与无线网络": "Mobile & wireless networks",
    "物联与控制系统": "IoT & control systems",
    "计算与数据中心网络": "Computing & data center networks",
    "其他专用网络": "Other specialized networks",
}


# ===================== 2) 输入/输出路径 =====================
INPUT_STATS_PKL = r"E:\Research_Group\TON_2025\code\12.1\output\Detail\场景_指标统计中间数据.pkl"
OUTPUT_PDF = r"E:\Research_Group\TON_2025\code\12.1\output\fig_4\fig_4.pdf"


# ===================== 3) 从统计中间数据构造 rows =====================
SPECIAL_METRIC_NAMES = {
    # 缩写/特殊术语：保持论文图中常用的规范写法
    "snr": "Signal-to-noise ratio",
    "signal to noise ratio": "Signal-to-noise ratio",
    "signal-to-noise ratio": "Signal-to-noise ratio",
    "sinr": "Signal-to-interference-plus-noise ratio",
    "signal to interference plus noise ratio": "Signal-to-interference-plus-noise ratio",
    "signal-to-interference-plus-noise ratio": "Signal-to-interference-plus-noise ratio",
    "rssi": "RSSI",
    "aoi": "Age of information",
    "age of information": "Age of information",
    "fct": "Flow completion time",
    "flow completion time": "Flow completion time",

    # 常见需要固定连字符写法的指标
    "end to end delay": "End-to-end delay",
    "end-to-end delay": "End-to-end delay",
}


def scene_to_domain(scene_label: str) -> str:
    if not isinstance(scene_label, str) or "." not in scene_label:
        return "其他专用网络"
    major = scene_label.split(".", 1)[0]
    return {
        "1": "网络架构与使能技术",
        "2": "网络虚拟化与切片架构",
        "3": "移动与无线网络",
        "4": "物联与控制系统",
        "5": "计算与数据中心网络",
        "6": "其他专用网络",
    }.get(major, "其他专用网络")


def _normalize_metric_key(metric: str) -> str:
    """统一指标名的大小写、空白、下划线和连字符，便于做特殊映射。"""
    s = str(metric).strip().lower()
    s = s.replace("–", "-").replace("—", "-")
    s = s.replace("_", " ")
    s = re.sub(r"\s+", " ", s)
    s = re.sub(r"\s*-\s*", "-", s)
    return s.strip()


def _sentence_case_metric_name(metric: str) -> str:
    """
    将普通指标转为句首大写形式，而不是每个单词首字母大写。

    示例：
    - packet_loss_rate / Packet Loss Rate -> Packet loss rate
    - transmission_security / Transmission Security -> Transmission security
    """
    normalized = _normalize_metric_key(metric)
    if not normalized:
        return ""
    return normalized[:1].upper() + normalized[1:]


def metric_display_name(metric: str) -> str:
    """
    将统计中间数据中的指标名转成论文图中显示的规范形式。

    规则：
    1) SNR/SINR/RSSI/AoI/FCT 等使用 SPECIAL_METRIC_NAMES 中的固定写法；
    2) end_to_end_delay / End To End Delay / End-to-End Delay 统一为 End-to-end delay；
    3) 其他普通指标使用 sentence case，例如 packet_loss_rate -> Packet loss rate，
       transmission_security -> Transmission security。
    """
    key = _normalize_metric_key(metric)
    if key in SPECIAL_METRIC_NAMES:
        return SPECIAL_METRIC_NAMES[key]
    return _sentence_case_metric_name(metric)


def _most_common_items(counter_like, n=None):
    """兼容 Counter/defaultdict/dict，返回按频次降序排列的 items。"""
    if hasattr(counter_like, "most_common"):
        return counter_like.most_common(n)

    items = list(getattr(counter_like, "items", lambda: [])())
    items = sorted(items, key=lambda x: x[1], reverse=True)
    return items if n is None else items[:n]


def build_rows_from_stats(stats_pkl_path, top_scenes=10, top_metrics=5):
    """
    从统计中间数据 .pkl 中生成 build_sankey() 所需 rows。

    返回 rows 的每一项格式：
    (domain_name, scene_name, scene_rank, metric_display_name, metric_rank)
    """
    if not os.path.isfile(stats_pkl_path):
        raise FileNotFoundError(f"统计中间数据文件不存在：{stats_pkl_path}")

    with open(stats_pkl_path, "rb") as rf:
        payload = pickle.load(rf)

    required_keys = {"scene_counter", "scene_aggregated_counts_post"}
    missing_keys = required_keys - set(payload.keys())
    if missing_keys:
        raise KeyError(f"统计中间数据缺少必要字段：{sorted(missing_keys)}")

    scene_counter = payload["scene_counter"]
    scene_metric_counter = payload["scene_aggregated_counts_post"]

    ranked_scenes = [
        (scene, freq)
        for scene, freq in _most_common_items(scene_counter)
        if scene not in {"未分类", "未知"}
    ][:top_scenes]

    rows = []
    for scene_rank, (scene_label, _) in enumerate(ranked_scenes, start=1):
        scene_name = (
            scene_label.split(" ", 1)[1]
            if isinstance(scene_label, str) and " " in scene_label
            else scene_label
        )
        domain_name = scene_to_domain(scene_label)
        metric_items = _most_common_items(scene_metric_counter.get(scene_label, {}), top_metrics)

        for metric_rank, (metric, _) in enumerate(metric_items, start=1):
            rows.append((
                domain_name,
                scene_name,
                scene_rank,
                metric_display_name(metric),
                metric_rank,
            ))

    return rows


# ===================== 4) 粗细映射（value）参数 =====================
def linear_rank_values(rank: int, n: int, vmax: float, vmin: float) -> float:
    """rank: 1..n（1 最粗）"""
    if n <= 1:
        return float(vmax)
    t = (rank - 1) / (n - 1)  # 0..1
    return float(vmax + (vmin - vmax) * t)


LM_VMAX, LM_VMIN = 12.0, 4.0
MR_VMAX, MR_VMIN = 10.0, 2.0


# ===================== 5) 名称映射函数 =====================
def apply_name_map(s: str, name_map: dict) -> str:
    return name_map.get(s, s)


# ===================== 6) 组装节点与连线 =====================
def build_sankey(rows, name_map):
    scene_rank = {}
    scene_domain = {}
    scene_metrics = defaultdict(list)

    domain_set, scene_set, metric_set = set(), set(), set()

    for d, s, s_rank, m, m_rank in rows:
        d2 = apply_name_map(d, name_map)
        s2 = apply_name_map(s, name_map)
        m2 = apply_name_map(m, name_map)

        domain_set.add(d2)
        scene_set.add(s2)
        metric_set.add(m2)

        scene_rank[s2] = s_rank
        scene_domain[s2] = d2
        scene_metrics[s2].append((m2, m_rank))

    preferred_domains = [apply_name_map(x, name_map) for x in [
        "网络架构与使能技术",
        "网络虚拟化与切片架构",
        "移动与无线网络",
        "物联与控制系统",
        "计算与数据中心网络",
        "其他专用网络",
    ]]

    # 只保留实际出现过的领域，避免生成无连接的空节点；额外领域按字母顺序追加。
    domains = [d for d in preferred_domains if d in domain_set]
    domains += sorted([d for d in domain_set if d not in set(domains)], key=lambda x: x.lower())

    scenes = sorted(list(scene_set), key=lambda x: scene_rank.get(x, 10**9))
    metrics = sorted(list(metric_set), key=lambda x: x.lower())

    node_labels = domains + scenes + metrics
    node_index = {lab: i for i, lab in enumerate(node_labels)}

    domain_colors = {
        apply_name_map("网络架构与使能技术", name_map): "rgba(31,119,180,0.45)",
        apply_name_map("网络虚拟化与切片架构", name_map): "rgba(140,86,75,0.45)",
        apply_name_map("移动与无线网络", name_map): "rgba(44,160,44,0.45)",
        apply_name_map("物联与控制系统", name_map): "rgba(214,39,40,0.45)",
        apply_name_map("计算与数据中心网络", name_map): "rgba(255,127,14,0.45)",
        apply_name_map("其他专用网络", name_map): "rgba(148,103,189,0.45)",
    }

    domain_to_scenes = defaultdict(list)
    for sc in scenes:
        domain_to_scenes[scene_domain[sc]].append(sc)

    sources, targets, values, colors = [], [], [], []

    for d in domains:
        scs = sorted(domain_to_scenes.get(d, []), key=lambda x: scene_rank.get(x, 10**9))
        n = len(scs)
        for i, sc in enumerate(scs, start=1):
            v = linear_rank_values(rank=i, n=n, vmax=LM_VMAX, vmin=LM_VMIN)
            sources.append(node_index[d])
            targets.append(node_index[sc])
            values.append(v)
            colors.append(domain_colors.get(d, "rgba(120,120,120,0.35)"))

    for sc in scenes:
        d = scene_domain[sc]
        top5 = sorted(scene_metrics[sc], key=lambda x: x[1])[:5]
        for m, mrk in top5:
            v = linear_rank_values(rank=mrk, n=5, vmax=MR_VMAX, vmin=MR_VMIN)
            sources.append(node_index[sc])
            targets.append(node_index[m])
            values.append(v)
            colors.append(domain_colors.get(d, "rgba(120,120,120,0.30)"))

    return node_labels, sources, targets, values, colors


# ===================== 7) 中文残留检查 =====================
_CJK_RE = re.compile(r"[\u4e00-\u9fff]")


def warn_if_cjk_exists(labels):
    bad = [x for x in labels if _CJK_RE.search(x or "")]
    if bad:
        print("[WARN] 检测到仍有中文/汉字未映射（可能引入 CJK/Type3 字体问题）：")
        for x in bad[:50]:
            print("   -", x)
        if len(bad) > 50:
            print(f"   ...（共 {len(bad)} 项，仅显示前 50 项）")
        print("       建议：补全 NAME_MAP，尽量使图中不出现中文字符。")


# ===================== 8) Ghostscript 查找（PATH/目录/注册表） =====================
def _run(cmd):
    return subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)


def _exists_file(p):
    return bool(p) and os.path.isfile(p)


def _find_ghostscript_from_registry():
    # 仅 Windows 有用：尝试从注册表定位安装目录
    try:
        import winreg
    except Exception:
        return None

    roots = [
        (winreg.HKEY_LOCAL_MACHINE, r"SOFTWARE\Artifex Ghostscript"),
        (winreg.HKEY_LOCAL_MACHINE, r"SOFTWARE\GPL Ghostscript"),
        (winreg.HKEY_LOCAL_MACHINE, r"SOFTWARE\WOW6432Node\Artifex Ghostscript"),
        (winreg.HKEY_LOCAL_MACHINE, r"SOFTWARE\WOW6432Node\GPL Ghostscript"),
    ]

    for root, basekey in roots:
        try:
            with winreg.OpenKey(root, basekey) as k:
                i = 0
                versions = []
                while True:
                    try:
                        ver = winreg.EnumKey(k, i)
                        versions.append(ver)
                        i += 1
                    except OSError:
                        break
                versions.sort(reverse=True)
                for ver in versions:
                    try:
                        with winreg.OpenKey(k, ver) as vk:
                            try:
                                gs_dll, _ = winreg.QueryValueEx(vk, "GS_DLL")
                                bin_dir = os.path.dirname(gs_dll)
                            except Exception:
                                gs_lib, _ = winreg.QueryValueEx(vk, "GS_LIB")
                                root_dir = os.path.dirname(os.path.dirname(gs_lib))
                                bin_dir = os.path.join(root_dir, "bin")

                            cand1 = os.path.join(bin_dir, "gswin64c.exe")
                            cand2 = os.path.join(bin_dir, "gswin32c.exe")
                            if _exists_file(cand1):
                                return cand1
                            if _exists_file(cand2):
                                return cand2
                    except Exception:
                        continue
        except Exception:
            continue
    return None


def _find_ghostscript():
    env_gs = os.environ.get("GS_EXE", "").strip()
    if _exists_file(env_gs):
        return env_gs
    if _exists_file(GS_EXE):
        return GS_EXE

    for exe in ("gswin64c", "gswin32c", "gs"):
        p = shutil.which(exe)
        if p:
            return p

    candidates = []
    candidates += glob.glob(r"C:\Program Files\gs\gs*\bin\gswin64c.exe")
    candidates += glob.glob(r"C:\Program Files\gs\gs*\bin\gswin32c.exe")
    candidates += glob.glob(r"C:\Program Files (x86)\gs\gs*\bin\gswin64c.exe")
    candidates += glob.glob(r"C:\Program Files (x86)\gs\gs*\bin\gswin32c.exe")
    candidates = sorted(candidates, reverse=True)
    if candidates:
        return candidates[0]

    reg = _find_ghostscript_from_registry()
    if reg:
        return reg

    return None


# ===================== 9) Ghostscript 后处理：嵌入/子集化字体 =====================
def embed_fonts_with_ghostscript(in_pdf: str, out_pdf: str) -> bool:
    gs = _find_ghostscript()
    if not gs:
        return False

    font_paths = []
    win_fonts = r"C:\Windows\Fonts"
    if os.path.isdir(win_fonts):
        font_paths.append(win_fonts)

    extra_font_path = os.environ.get("GS_FONTPATH", "").strip()
    if extra_font_path:
        for p in extra_font_path.split(";"):
            p = p.strip()
            if p and os.path.isdir(p):
                font_paths.append(p)

    fontpath_arg = None
    if font_paths:
        fontpath_arg = "-sFONTPATH=" + ";".join(font_paths)

    cmd = [
        gs,
        "-q",
        "-dNOPAUSE", "-dBATCH",
        "-sDEVICE=pdfwrite",
        "-dCompatibilityLevel=1.4",
        "-dPDFSETTINGS=/prepress",
        "-dEmbedAllFonts=true",
        "-dSubsetFonts=true",
        "-dCompressFonts=true",
        "-dDetectDuplicateImages=true",
        "-dAutoRotatePages=/None",
        f"-sOutputFile={out_pdf}",
    ]
    if fontpath_arg:
        cmd.append(fontpath_arg)
    cmd.append(in_pdf)

    r = _run(cmd)
    if r.returncode != 0:
        print("[WARN] Ghostscript 后处理失败。stderr（截断）：")
        print((r.stderr or "").strip()[:1500])
        return False
    return True


# ===================== 10) 主程序：绘图与导出 =====================
def main():
    out_dir = os.path.dirname(os.path.abspath(OUTPUT_PDF))
    if out_dir and (not os.path.exists(out_dir)):
        os.makedirs(out_dir, exist_ok=True)

    rows = build_rows_from_stats(INPUT_STATS_PKL, top_scenes=10, top_metrics=5)
    node_labels, sources, targets, values, link_colors = build_sankey(rows, NAME_MAP)
    warn_if_cjk_exists(node_labels)

    # ✅ 字体策略：尽量使用 Times New Roman（英文化后一般不需要 CJK 字体）
    PREFERRED_FONT = "Times New Roman, Times, serif"

    # ====== 你要“适当增大字体”的核心参数 ======
    SANKEY_TEXT_SIZE = 22   # 桑基图内部节点标签字号（原来大概 18，这里适当增大）
    GLOBAL_FONT_SIZE = 22   # 全局字号（标题/hover 等）
    HOVER_FONT_SIZE = 18    # hover 字号（可选）
    # =========================================

    fig = go.Figure(
        data=[
            go.Sankey(
                arrangement="snap",
                # ✅ 关键：控制桑基图内部文字（节点 label）
                textfont=dict(
                    family=PREFERRED_FONT,
                    size=SANKEY_TEXT_SIZE,
                    color="black",
                ),
                node=dict(
                    pad=18,
                    thickness=18,
                    line=dict(color="rgba(80,80,80,0.6)", width=0.6),
                    label=node_labels,
                    color="rgba(200,200,200,0.55)",
                ),
                link=dict(
                    source=sources,
                    target=targets,
                    value=values,
                    color=link_colors,
                ),
            )
        ]
    )

    fig.update_layout(
        font=dict(family=PREFERRED_FONT, size=GLOBAL_FONT_SIZE),
        hoverlabel=dict(font_size=HOVER_FONT_SIZE, font_family=PREFERRED_FONT),
        margin=dict(l=20, r=20, t=70, b=20),
        width=1152,
        height=720,
        paper_bgcolor="white",
        plot_bgcolor="white",
    )

    base, _ = os.path.splitext(OUTPUT_PDF)
    raw_pdf = base + "__raw.pdf"

    # 1) 先导出 raw PDF（依赖 kaleido）
    try:
        fig.write_image(raw_pdf, format="pdf")
        print(f"[OK] Raw PDF saved to: {raw_pdf}")
    except Exception as e:
        html_path = base + ".html"
        fig.write_html(html_path)
        print("[ERROR] PDF 导出失败（通常是未安装 kaleido）。")
        print("        已导出 HTML 预览：", html_path)
        print("        解决：pip install -U kaleido")
        print("        原始错误：", repr(e))
        return

    # 2) Ghostscript 后处理：嵌入/子集化字体
    ok = embed_fonts_with_ghostscript(raw_pdf, OUTPUT_PDF)
    if ok:
        try:
            os.remove(raw_pdf)
        except Exception:
            pass
        print(f"[OK] IEEE-friendly PDF saved to: {OUTPUT_PDF}")
        return

    # 3) 找不到/无法使用 Ghostscript：按策略处理
    msg = (
        "[ERROR] 未找到或无法调用 Ghostscript，因此无法执行“字体嵌入/子集化”后处理。\n"
        "解决办法（二选一）：\n"
        "  A) 在当前 conda 环境安装：conda install -c conda-forge ghostscript\n"
        "  B) 系统安装 Ghostscript，并确保 gswin64c.exe 在 PATH；或在脚本顶部设置 GS_EXE=完整路径\n"
        "提示：安装完成后，重新运行本脚本。\n"
    )
    if REQUIRE_FONT_EMBEDDING:
        print(msg)
        raise SystemExit(1)

    shutil.copyfile(raw_pdf, OUTPUT_PDF)
    print("[WARN] 未做后处理，已回退为 raw 版本：", OUTPUT_PDF)


if __name__ == "__main__":
    main()