# -*- coding: utf-8 -*-
"""
目的：读取前述流程生成的“场景_指标统计中间数据.pkl”，在与原 semi-log 幂律拟合图
完全一致的数据口径、拟合/标注方式、版式与字体参数下，仅将坐标改为 log–log，
并以新文件名输出 PDF。

你只需要改两个地方：
1) INPUT_PKL_PATH：指向“场景_指标统计中间数据.pkl”
2) OUTPUT_DIR（可选）：输出目录（默认与 pkl 同目录）

本版本额外做了“IEEE LaTeX 可嵌入字体”的关键设置：
- pdf.fonttype = 42（TrueType，避免 Type 3 字体）
- ps.fonttype  = 42

并使用 Matplotlib mathtext（$...$）实现：
- 图例中的 R^2 以“上角标平方”形式渲染（$R^{2}$）；
- 乘法不使用点乘或星号，而是采用数学排版中的“系数与项之间留一小段间距”的写法（如 a\\,x）；
- 坐标轴中 r 与 f(r) 以数学公式形式渲染（$r$, $f(r)$），与图例一致。
"""

import os
import pickle
import numpy as np
import matplotlib.pyplot as plt
from matplotlib import rcParams
from matplotlib.font_manager import FontProperties, FontManager
from matplotlib.lines import Line2D
from matplotlib.legend_handler import HandlerBase


# ===================== 手动配置区 =====================
INPUT_PKL_PATH = r"E:/Research_Group/TON_2025/code/12.1/output/Detail/场景_指标统计中间数据.pkl"
OUTPUT_DIR = "E:/Research_Group/TON_2025/code/12.1/output/fig_3"  # 留空则输出到 pkl 同目录
OUTPUT_PDF_NAME = "fig_3.pdf"

# 分段幂律拟合设置：第 1 段拟合前 18 个指标点；第 2 段从第 19 个指标点开始。
# 第 2 段仍沿用原脚本“最多取前 200 个高频指标做拟合”的数据口径，避免长尾 f(r)=1 平台主导拟合。
FRONT_FIT_END_RANK = 18
MAX_TOP_K_FIT = 200
# =====================================================


# ===================== matplotlib 全局参数（与原脚本保持一致 + IEEE 字体嵌入关键项） =====================
plt.rcParams['axes.unicode_minus'] = False

# 分辨率
rcParams['figure.dpi'] = 330
rcParams['savefig.dpi'] = 330

# 字体回退（保留你的中文字体列表，但主体仍由 FontProperties 显式指定）
plt.rcParams['font.sans-serif'] = ['SimSun', 'Microsoft YaHei', 'SimHei', 'STSong', 'DejaVu Sans']
plt.rcParams['axes.unicode_minus'] = False

# === 关键：让 PDF 中字体以 TrueType(42) 方式写入，避免 Type 3，便于 IEEE LaTeX 嵌入 ===
rcParams['pdf.fonttype'] = 42
rcParams['ps.fonttype'] = 42

# （可选）提高压缩率，不影响字体嵌入
rcParams['pdf.compression'] = 9

# === 关键：让 mathtext（$...$）也尽量使用 Times New Roman（更统一、且可嵌入） ===
rcParams['mathtext.fontset'] = 'custom'
rcParams['mathtext.rm'] = 'Times New Roman'
rcParams['mathtext.it'] = 'Times New Roman:italic'
rcParams['mathtext.bf'] = 'Times New Roman:bold'
# =====================================================


# ===================== 字体工具（与原脚本保持一致） =====================
def get_tnr_font(size=10):
    """
    优先 Times New Roman；找不到时回退到 DejaVu Serif/Sans。
    注意：是否“可嵌入”也取决于本机字体许可，但 Times New Roman 通常可正常嵌入。
    """
    try:
        return FontProperties(family='Times New Roman', size=size)
    except Exception:
        try:
            return FontProperties(family='DejaVu Serif', size=size)
        except Exception:
            return FontProperties(family='DejaVu Sans', size=size)


def get_chinese_font(size=10):
    chinese_fonts = [
        'SimSun', 'Microsoft YaHei', 'SimHei', 'STSong', 'FangSong', 'KaiTi',
        'Microsoft JhengHei', 'DengXian',
        'Heiti TC', 'Songti SC', 'STHeiti', 'Arial Unicode MS',
        'WenQuanYi Zen Hei', 'WenQuanYi Micro Hei', 'Noto Sans CJK SC',
        'DejaVu Sans'
    ]
    fm = FontManager()
    available = set(f.name for f in fm.ttflist)
    for f in chinese_fonts:
        if f in available:
            try:
                return FontProperties(family=f, size=size)
            except Exception:
                continue
    print("警告：未找到可用中文字体，使用默认字体。")
    return FontProperties(size=size)


# ===================== 自定义图例句柄：用于在一行图例中同时显示红色虚线和黑色虚线 =====================
class TwoDashedLinesHandle:
    """用于 ': Fitted curves' 图例项的占位句柄。"""

    def __init__(self, colors, linewidth=2, linestyle="--"):
        self.colors = colors
        self.linewidth = linewidth
        self.linestyle = linestyle


class HandlerTwoDashedLines(HandlerBase):
    """在一个图例 handle 区域内绘制两条上下排列的虚线。"""

    def create_artists(
        self,
        legend,
        orig_handle,
        xdescent,
        ydescent,
        width,
        height,
        fontsize,
        trans
    ):
        artists = []

        # 上方红色虚线，下方黑色虚线，对应“红色虚线和黑色虚线”。
        y_positions = [
            ydescent + 0.55 * height,
            ydescent + 0.15 * height
        ]

        for color, y in zip(orig_handle.colors, y_positions):
            line = Line2D(
                [xdescent, xdescent + width],
                [y, y],
                color=color,
                linestyle=orig_handle.linestyle,
                linewidth=orig_handle.linewidth
            )
            line.set_transform(trans)
            artists.append(line)

        return artists


# ===================== 幂律拟合辅助函数 =====================
def fit_power_law_loglog(ranks_seg, counts_seg):
    """
    在 log-log 坐标下进行幂律拟合：
        log10 f(r) = slope * log10 r + intercept

    等价于原尺度：
        f(r) = C * r^slope,  C = 10^intercept
    """
    ranks_seg = np.asarray(ranks_seg, dtype=float)
    counts_seg = np.asarray(counts_seg, dtype=float)

    valid_mask = counts_seg > 0
    ranks_seg = ranks_seg[valid_mask]
    counts_seg = counts_seg[valid_mask]

    if len(ranks_seg) < 2:
        raise ValueError("用于幂律拟合的有效数据点不足，至少需要 2 个点。")

    log_r = np.log10(ranks_seg)
    log_f = np.log10(counts_seg)

    slope, intercept = np.polyfit(log_r, log_f, 1)
    log_f_pred = slope * log_r + intercept

    ss_res = np.sum((log_f - log_f_pred) ** 2)
    ss_tot = np.sum((log_f - np.mean(log_f)) ** 2)
    r2 = 1 - ss_res / ss_tot if ss_tot > 0 else np.nan

    return {
        "slope": float(slope),
        "intercept": float(intercept),
        "C": float(10 ** intercept),
        "r2": float(r2) if not np.isnan(r2) else np.nan,
        "n": int(len(ranks_seg)),
        "rank_min": float(np.min(ranks_seg)),
        "rank_max": float(np.max(ranks_seg)),
    }


def make_power_law_curve(rank_min, rank_max, fit_result, num=200):
    """根据拟合参数生成用于绘图的平滑幂律曲线。"""
    if rank_max <= rank_min:
        x_line = np.array([rank_min], dtype=float)
    else:
        x_line = np.logspace(np.log10(rank_min), np.log10(rank_max), num=num)

    y_line = fit_result["C"] * (x_line ** fit_result["slope"])
    return x_line, y_line


def format_linear_equation(fit_result):
    """
    生成图例中的 log-log 线性拟合公式。

    注意：
    此处不添加类似“1 <= r <= 18:”或“19 <= r <= 200:”的区间前缀标签，
    图例中仅显示拟合公式和 R^2。
    """
    slope_str = f"{fit_result['slope']:.3f}"
    intercept = fit_result["intercept"]
    intercept_sign = "+" if intercept >= 0 else "-"
    intercept_abs_str = f"{abs(intercept):.3f}"
    r2_str = f"{fit_result['r2']:.3f}" if not np.isnan(fit_result["r2"]) else "nan"

    return (
        f"$\\log\\, f(r) = {slope_str}\\,\\log\\, r {intercept_sign} "
        f"{intercept_abs_str};\\ \\ R^{{2}} = {r2_str}$"
    )


# ===================== 主逻辑：读取 pkl + 生成 log-log 幂律拟合图 =====================
def main():
    if not os.path.isfile(INPUT_PKL_PATH):
        raise FileNotFoundError(f"未找到输入 pkl 文件：{INPUT_PKL_PATH}")

    out_dir = OUTPUT_DIR.strip() if isinstance(OUTPUT_DIR, str) else ""
    if not out_dir:
        out_dir = os.path.dirname(os.path.abspath(INPUT_PKL_PATH))

    os.makedirs(out_dir, exist_ok=True)

    # 读取中间数据
    with open(INPUT_PKL_PATH, "rb") as rf:
        payload = pickle.load(rf)

    # 与原 semi-log 图一致的数据口径：使用去重后按文件计数的 aggregated_counts_post
    aggregated_counts = payload.get("aggregated_counts_post", None)
    if not aggregated_counts:
        raise KeyError("pkl 中未找到 aggregated_counts_post，无法生成幂律拟合图。")

    # 与原图一致：按频次降序排列，rank 从 1..N
    sorted_post_metrics = aggregated_counts.most_common()
    post_metrics = [item[0] for item in sorted_post_metrics]
    post_freqs = [int(item[1]) for item in sorted_post_metrics]

    if len(post_metrics) == 0:
        print("⚠ 去重后未统计到任何指标，跳过输出。")
        return

    n_metrics_post = len(post_metrics)
    ranks = np.arange(1, n_metrics_post + 1, dtype=float)
    counts = np.array(post_freqs, dtype=float)

    # 与原图一致：只用前 top_k_fit（最多 200）做拟合。
    # 本版本在该口径内进一步拆分为两段：1..18 与 19..top_k_fit。
    top_k_fit = min(MAX_TOP_K_FIT, n_metrics_post)
    split_rank = int(FRONT_FIT_END_RANK)

    if top_k_fit <= split_rank:
        print(f"⚠ 指标数量不足：需要至少 {split_rank + 1} 个点才能进行两段拟合，跳过输出。")
        return

    ranks_fit_all = ranks[:top_k_fit]
    counts_fit_all = counts[:top_k_fit]

    # 第一段：拟合前段约 18 个指标点。
    front_fit_mask = (ranks_fit_all <= split_rank) & (counts_fit_all > 0)
    ranks_fit_front = ranks_fit_all[front_fit_mask]
    counts_fit_front = counts_fit_all[front_fit_mask]

    # 第二段：拟合明显骤降后的指标点，即从第 19 个指标点开始，到原 top_k_fit 截止。
    back_fit_mask = (ranks_fit_all > split_rank) & (counts_fit_all > 0)
    ranks_fit_back = ranks_fit_all[back_fit_mask]
    counts_fit_back = counts_fit_all[back_fit_mask]

    if len(ranks_fit_front) < 2 or len(ranks_fit_back) < 2:
        print("⚠ 用于两段幂律拟合的有效数据点不足，跳过输出。")
        return

    # 两段分别在 log-log 坐标下重新计算幂律拟合参数。
    front_fit = fit_power_law_loglog(ranks_fit_front, counts_fit_front)
    back_fit = fit_power_law_loglog(ranks_fit_back, counts_fit_back)

    print(f"第一段幂律拟合结果（基于去重后第 1 至第 {split_rank} 个高频指标）：")
    print(f"  log f(r) = {front_fit['slope']:.4f} * log r + {front_fit['intercept']:.4f}")
    print(f"  对应幂律形式：f(r) ∝ r^{front_fit['slope']:.4f}")
    print(f"  拟合优度 R^2 = {front_fit['r2']:.4f}，有效拟合点数 = {front_fit['n']}")

    print(f"第二段幂律拟合结果（基于去重后第 {split_rank + 1} 至第 {top_k_fit} 个高频指标）：")
    print(f"  log f(r) = {back_fit['slope']:.4f} * log r + {back_fit['intercept']:.4f}")
    print(f"  对应幂律形式：f(r) ∝ r^{back_fit['slope']:.4f}")
    print(f"  拟合优度 R^2 = {back_fit['r2']:.4f}，有效拟合点数 = {back_fit['n']}")

    mask_all = counts > 0
    ranks_all = ranks[mask_all]
    counts_all = counts[mask_all]

    # 第一段拟合线只画在第 1 至第 18 个指标点范围内。
    front_plot_ranks = ranks_all[ranks_all <= split_rank]
    front_line_x, front_line_y = make_power_law_curve(
        rank_min=np.min(front_plot_ranks),
        rank_max=np.max(front_plot_ranks),
        fit_result=front_fit,
        num=120
    )

    # 第二段拟合线从第 19 个指标点开始绘制；拟合参数来自 19..top_k_fit。
    # 这里沿用原脚本的视觉习惯，将幂律曲线向后延展到所有有效 rank，以保持整体图面范围一致。
    back_plot_ranks = ranks_all[ranks_all > split_rank]
    back_line_x, back_line_y = make_power_law_curve(
        rank_min=np.min(back_plot_ranks),
        rank_max=np.max(back_plot_ranks),
        fit_result=back_fit,
        num=300
    )

    # ========== 绘图（版式/字体/图例/样式与原 semi-log 图一致，仅坐标改为 log–log） ==========
    fig_pw, ax_pw = plt.subplots(figsize=(7, 6))

    # 与原图一致的数据点颜色；两段拟合线用黑色/红色区分。
    scatter_color = "#1f77b4"
    front_fitline_color = "black"
    back_fitline_color = "#dc143c"

    ax_pw.scatter(
        ranks_all,
        counts_all,
        s=30,
        alpha=0.8,
        edgecolor="none",
        linewidth=0,
        color=scatter_color
    )

    # 两条虚线：前段拟合线为黑色，后段拟合线为红色。
    ax_pw.plot(
        front_line_x,
        front_line_y,
        color=front_fitline_color,
        linestyle="--",
        linewidth=2
    )
    ax_pw.plot(
        back_line_x,
        back_line_y,
        color=back_fitline_color,
        linestyle="--",
        linewidth=2
    )

    # log-log 坐标
    ax_pw.set_xscale("log")
    ax_pw.set_yscale("log")

    # 轴标签：将 r 与 f(r) 改为 mathtext，与图例一致
    ax_pw.set_xlabel(r"Metric ranking:  $r$", fontproperties=get_tnr_font(14))
    ax_pw.set_ylabel(r"Metric frequency:  $f(r)$", fontproperties=get_tnr_font(14))

    for tick in ax_pw.get_xticklabels():
        tick.set_fontproperties(get_tnr_font(12))
    for tick in ax_pw.get_yticklabels():
        tick.set_fontproperties(get_tnr_font(12))

    # 图例公式：删除区间标签，仅显示两段拟合公式与 R^2。
    equation_label_front = format_linear_equation(front_fit)
    equation_label_back = format_linear_equation(back_fit)

    # 图例句柄
    legend_scatter_handle = Line2D(
        [], [],
        linestyle="none",
        marker="o",
        markersize=6,
        markerfacecolor=scatter_color,
        markeredgecolor="black",
        markeredgewidth=0.6
    )

    # 第二行 ': Fitted curves' 前同时显示红色虚线和黑色虚线。
    legend_fitted_curves_handle = TwoDashedLinesHandle(
        colors=(back_fitline_color, front_fitline_color),
        linewidth=2,
        linestyle="--"
    )

    # 第三行公式前的黑色虚线，对应第一段拟合。
    legend_front_formula_handle = Line2D(
        [], [],
        color=front_fitline_color,
        linewidth=2,
        linestyle="--"
    )

    # 第四行公式前的红色虚线，对应第二段拟合。
    legend_back_formula_handle = Line2D(
        [], [],
        color=back_fitline_color,
        linewidth=2,
        linestyle="--"
    )

    legend_handles = [
        legend_scatter_handle,
        legend_fitted_curves_handle,
        legend_front_formula_handle,
        legend_back_formula_handle,
    ]

    legend_labels = [
        ": Empirical data",
        ": Fitted curves",
        ": " + equation_label_front,
        ": " + equation_label_back,
    ]

    legend = ax_pw.legend(
        legend_handles,
        legend_labels,
        loc="upper right",
        frameon=True,
        framealpha=0.9,
        borderpad=0.8,
        handlelength=1.8,
        handletextpad=0.6,
        labelspacing=0.5,
        handler_map={
            TwoDashedLinesHandle: HandlerTwoDashedLines()
        }
    )

    for text in legend.get_texts():
        text.set_fontproperties(get_tnr_font(11))
        text.set_ha("left")

    try:
        legend._legend_box.align = "left"
    except Exception:
        pass

    ax_pw.grid(True, which="both", linestyle="--", linewidth=0.4, alpha=0.4)

    plt.tight_layout()

    out_path = os.path.join(out_dir, OUTPUT_PDF_NAME)
    plt.savefig(
        out_path,
        format="pdf",
        bbox_inches="tight",
        dpi=330,
        facecolor="white"
    )
    plt.close(fig_pw)

    print("log–log 两段幂律拟合图已保存：", out_path)
    print("提示：可用 pdffonts 或 Acrobat Preflight 检查字体是否已嵌入（Embedded=Yes，且非 Type 3）。")


if __name__ == "__main__":
    main()