import os
import re
import pickle
import time
import json
import ast
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
import difflib
from collections import Counter, defaultdict
from matplotlib import rcParams
from matplotlib.font_manager import FontProperties, FontManager
from matplotlib.lines import Line2D  # ✅新增：用于构造幂律拟合图的自定义图例句柄（不影响既有输出）

try:
    from langchain_core.prompts import ChatPromptTemplate
    from langchain_core.output_parsers import StrOutputParser
    from langchain_openai import ChatOpenAI
except Exception:
    ChatPromptTemplate = None
    StrOutputParser = None
    ChatOpenAI = None

# ===================== 配置 =====================
PKL_INPUT_DIR = "E:/Research_Group/TON_2025/code/12.1/output/output_pkl/all"
PDF_OUTPUT_DIR = "E:/Research_Group/TON_2025/code/12.1/output/Detail/3"

MIN_METRIC_FREQ = 50
TOP_SCENES = 30
EXCLUDE_METRICS = []
METRIC_MAPPING = {
    # "e2e_delay": "end_to_end_delay",
    # "e2e_latency": "end_to_end_delay",
}
CUSTOM_CORRELATIONS = {
    # 请使用规范化（下划线风格）metric对，例如 "end_to_end_delay-end_to_end_delay": 1
    "end_to_end_delay-end_to_end_delay": 1,
    "packet_error_rate-packet_error_rate": 1,
}

# ========== 你要给定的“标准化指标列表”（脚本会强制这些指标不能作为别的指标的变体） ==========
PREDEFINED_CANONICALS = [
    "end_to_end_delay",
    "throughput",
    "packet_error_rate",
    "bandwidth_utilization",
    "symbol_error_rate",
    "packet_delivery_ratio",
    "packet_loss_rate",
    "hop_count",
    "bandwidth",
    "frame_error_rate",
    "transmission_delay",
    "processing_delay",
    "queuing_delay",
    "queuing_length",
    "snr",
    "sinr",
    "energy_efficiency",
    "energy_consumption",
    "flow_completion_time",
    "cpu_utilization",
]

# ===================== DeepSeek API =====================
def get_api_key_from_env():
    api_key = os.getenv("DEEPSEEK_API_KEY")
    if not api_key:
        raise EnvironmentError("未检测到环境变量 DEEPSEEK_API_KEY，请先配置后再运行。")
    return api_key


DEEPSEEK_BASE_URL = "https://api.deepseek.com/v1"
LLM_CONFIG = {
    "model": "deepseek-chat",
    "temperature": 0.1,
    "top_p": 0.8,
    "max_tokens": 4096,
    "streaming": False,
}

# matplotlib
plt.rcParams['axes.unicode_minus'] = False
rcParams['figure.dpi'] = 330
rcParams['savefig.dpi'] = 330
plt.rcParams['font.sans-serif'] = ['SimSun', 'Microsoft YaHei', 'SimHei', 'STSong', 'DejaVu Sans']
plt.rcParams['axes.unicode_minus'] = False


# ===================== 字体工具 =====================
def get_tnr_font(size=10):
    try:
        return FontProperties(family='Times New Roman', size=size)
    except:
        return FontProperties(family='DejaVu Sans', size=size)


def get_chinese_font(size=10):
    chinese_fonts = [
        'SimSun', 'Microsoft YaHei', 'SimHei', 'STSong', 'FangSong', 'KaiTi',
        'Microsoft JhengHei', 'DengXian',
        'Heiti TC', 'Songti SC', 'STHeiti', 'Arial Unicode MS',
        'WenQuanYi Zen Hei', 'WenQuanYi Micro Hei', 'Noto Sans CJK SC',
        'DejaVu Sans'
    ]
    fm = FontManager()
    available = set(f.name for f in fm.ttflist)
    for f in chinese_fonts:
        if f in available:
            try:
                return FontProperties(family=f, size=size)
            except:
                continue
    print("警告：未找到可用中文字体，使用默认字体。")
    return FontProperties(size=size)


chinese_font = get_chinese_font()
tnr_font = get_tnr_font()
os.makedirs(PDF_OUTPUT_DIR, exist_ok=True)


# ===================== 辅助函数 =====================
def normalize_name(name: str) -> str:
    if not isinstance(name, str):
        return name
    return name.lower().strip().replace(" ", "_").replace("-", "_")


# 规格化 PREDEFINED_CANONICALS、METRIC_MAPPING、CUSTOM_CORRELATIONS
PREDEFINED_CANONICALS = [normalize_name(x) for x in PREDEFINED_CANONICALS if isinstance(x, str) and x.strip()]
PREDEFINED_CANONICALS_SET = set(PREDEFINED_CANONICALS)

# Normalize METRIC_MAPPING keys/values
METRIC_MAPPING = {normalize_name(k): normalize_name(v) for k, v in (METRIC_MAPPING or {}).items()}

# Normalize custom correlations keys
CUSTOM_CORRELATIONS_NORMALIZED = {}
for pair, val in (CUSTOM_CORRELATIONS or {}).items():
    try:
        p1, p2 = pair.split("-")
        p1n = normalize_name(p1)
        p2n = normalize_name(p2)
        CUSTOM_CORRELATIONS_NORMALIZED[f"{p1n}-{p2n}"] = float(val)
    except:
        continue
CUSTOM_CORRELATIONS = CUSTOM_CORRELATIONS_NORMALIZED


# ===================== 鲁棒 JSON 解析（应对 LLM 返回不规范 JSON 的常见情况） =====================
def find_json_candidates(text):
    """
    在文本中寻找可能的 JSON 子串（匹配平衡的 {} 或 []）。
    返回候选子串列表（按出现顺序）。
    """
    candidates = []
    for open_ch, close_ch in [("{", "}"), ("[", "]")]:
        stack = []
        start = None
        for i, ch in enumerate(text):
            if ch == open_ch:
                if not stack:
                    start = i
                stack.append(ch)
            elif ch == close_ch and stack:
                stack.pop()
                if not stack and start is not None:
                    cand = text[start:i + 1]
                    candidates.append(cand)
                    start = None
    return candidates


def clean_json_like(s):
    """
    对接近 JSON 的字符串做保守修复：
      - 替换智能引号 -> 普通引号
      - 删除尾随逗号
      - 将 Python True/False/None -> json true/false/null
      - 尝试将键或值的单引号替换为双引号（保守）
      - 去掉 // 行注释 与 /* */ 块注释
    """
    if not isinstance(s, str):
        return s
    s2 = s
    s2 = s2.replace("“", '"').replace("”", '"').replace("‘", "'").replace("’", "'")
    s2 = re.sub(r"//.*?$", "", s2, flags=re.MULTILINE)
    s2 = re.sub(r"/\*.*?\*/", "", s2, flags=re.DOTALL)
    s2 = re.sub(r",\s*([\]\}])", r"\1", s2)
    s2 = re.sub(r"\bNone\b", "null", s2)
    s2 = re.sub(r"\bTrue\b", "true", s2)
    s2 = re.sub(r"\bFalse\b", "false", s2)
    # 键的单引号 'key': -> "key":
    s2 = re.sub(r"(?P<prefix>[\{\s,])'(?P<key>[^']+)'\s*:", r'\g<prefix>"\g<key>":', s2)
    # 值的单引号 : 'value' -> : "value"
    s2 = re.sub(r":\s*'([^']*)'", r': "\1"', s2)
    return s2


def parse_json_from_response(text):
    """
    尽可能鲁棒地从 LLM 文本中提取并解析 JSON，返回 (parsed_obj, used_substring) 或 (None, None)
    策略（依次）：
      1) 直接对全文 json.loads
      2) 找到平衡的 {} 或 [] 子串，按长度降序尝试 json.loads，再尝试 clean_json_like 后 json.loads
      3) 对候选子串尝试 ast.literal_eval（可接受单引号），再转为 JSON 兼容
      4) 最后对全文 clean_json_like 再 json.loads
    失败则返回 (None, None) 并打印前 1000 字以便排查。
    """
    if not text or not isinstance(text, str):
        return None, None
    # 去除 ``` ``` 包裹
    t = re.sub(r"```(?:json)?\s*", "", text)
    t = re.sub(r"```", "", t)
    t = t.replace("`", "").strip()
    # 1) 直接尝试
    try:
        parsed = json.loads(t)
        return parsed, t
    except Exception:
        pass
    # 2) 候选子串
    candidates = find_json_candidates(t)
    uniq = []
    seen = set()
    for c in sorted(candidates, key=len, reverse=True):
        if c not in seen:
            uniq.append(c)
            seen.add(c)
    for cand in uniq:
        try:
            parsed = json.loads(cand)
            return parsed, cand
        except Exception:
            try:
                cand_clean = clean_json_like(cand)
                parsed = json.loads(cand_clean)
                return parsed, cand_clean
            except Exception:
                continue
    # 3) ast.literal_eval 尝试
    for cand in uniq:
        try:
            parsed_py = ast.literal_eval(cand)
            parsed_json_compatible = json.loads(json.dumps(parsed_py))
            return parsed_json_compatible, cand
        except Exception:
            try:
                cand_clean = clean_json_like(cand)
                parsed_py = ast.literal_eval(cand_clean)
                parsed_json_compatible = json.loads(json.dumps(parsed_py))
                return parsed_json_compatible, cand_clean
            except Exception:
                continue
    # 4) 整体清理再尝试
    try:
        t_clean = clean_json_like(t)
        parsed = json.loads(t_clean)
        return parsed, t_clean
    except Exception:
        pass
    print("警告：无法从 LLM 响应中提取有效 JSON。原始响应前1000字符：")
    print(text[:1000])
    return None, None


# ===================== 新增：统计工具函数（不影响原有流程/输出逻辑） =====================
def freq_bucket_1_to_5(counter_obj: Counter):
    """
    统计 counter 的 value==1/2/3/4/5 的 key 数量分布。
    返回 dict: {1: n1, 2: n2, 3: n3, 4: n4, 5: n5}
    """
    dist = {i: 0 for i in range(1, 6)}
    for _, v in (counter_obj or {}).items():
        try:
            iv = int(v)
        except Exception:
            continue
        if 1 <= iv <= 5:
            dist[iv] += 1
    return dist


def summarize_counter_basic(counter_obj: Counter):
    """
    返回（唯一指标数, 频次总和）
    """
    if not counter_obj:
        return 0, 0
    return len(counter_obj), int(sum(counter_obj.values()))


# ===================== 读取并汇总所有 pkl =====================
metric_counter = Counter()  # “去重前（alias/初步规范化后）按文件计数”
scene_counter = Counter()
relation_accumulator = defaultdict(list)  # 仅存储原始指标对的非零相关系数
metric_explanations_accumulator = defaultdict(list)
metric_originals_accumulator = defaultdict(set)
metric_units_accumulator = defaultdict(set)

# ===================== 新增：分场景“去重前（alias）按文件计数” =====================
scene_metric_counter = defaultdict(Counter)  # fig_7and8 -> Counter(alias_metric -> per-file frequency)

pkl_files = [f for f in os.listdir(PKL_INPUT_DIR) if f.endswith("_metrics_relations.pkl")]
actual_file_count = len(pkl_files)
print(f"找到 {actual_file_count} 个 pkl 文件。")

for idx, pkl_file in enumerate(pkl_files, 1):
    path = os.path.join(PKL_INPUT_DIR, pkl_file)
    try:
        with open(path, 'rb') as rf:
            data = pickle.load(rf)
    except Exception as e:
        print(f"无法读取 {pkl_file}: {e}")
        continue

    file_metrics = data.get("metrics", {}) or {}
    normalized_raws = {normalize_name(raw) for raw in file_metrics.keys() if isinstance(raw, str)}

    direct_canonicals_in_file = set()
    for nm in normalized_raws:
        if nm in PREDEFINED_CANONICALS_SET:
            direct_canonicals_in_file.add(nm)
        else:
            mapped_temp = METRIC_MAPPING.get(nm, nm)
            if mapped_temp in PREDEFINED_CANONICALS_SET and mapped_temp in normalized_raws:
                direct_canonicals_in_file.add(mapped_temp)

    per_file_normalized_to_mapped = {}
    for raw, unit in file_metrics.items():
        if not isinstance(raw, str):
            continue
        nm = normalize_name(raw)
        if nm in PREDEFINED_CANONICALS_SET:
            mapped = nm
        else:
            mapped = METRIC_MAPPING.get(nm, nm)
        per_file_normalized_to_mapped[nm] = mapped
        if mapped and mapped not in EXCLUDE_METRICS:
            metric_originals_accumulator[mapped].add(raw)
            if unit and isinstance(unit, str):
                metric_units_accumulator[mapped].add(unit.strip())

    counted_in_this_file = set()
    for c in direct_canonicals_in_file:
        counted_in_this_file.add(c)
    for nm, mapped in per_file_normalized_to_mapped.items():
        if mapped in EXCLUDE_METRICS:
            continue
        if mapped in PREDEFINED_CANONICALS_SET:
            if mapped not in counted_in_this_file:
                if mapped in direct_canonicals_in_file:
                    pass
                else:
                    counted_in_this_file.add(mapped)
        else:
            if mapped not in counted_in_this_file:
                counted_in_this_file.add(mapped)

    # 全量（去重前 alias）按文件计数
    metric_counter.update(counted_in_this_file)

    # 场景计数
    scene = data.get("network_type", "未知")
    scene_counter[scene] += 1

    # ===================== 新增：分场景（去重前 alias）按文件计数 =====================
    # 注意：不改变原始统计口径，仅在此处“旁路”累计
    scene_metric_counter[scene].update(counted_in_this_file)

    # ========== 修改点1：累加阶段过滤0值（参考第一段代码） ==========
    file_rel = data.get("relations", {}) or {}
    for pair_key, corr in file_rel.items():
        if "-" not in pair_key:
            continue
        try:
            # 过滤0值，仅保留非零且在[-1,1]范围内的相关系数
            if isinstance(corr, (int, float)) and -1 <= corr <= 1 and corr != 0:
                relation_accumulator[pair_key].append(float(corr))
            elif isinstance(corr, (list, tuple)):
                for v in corr:
                    if isinstance(v, (int, float)) and -1 <= v <= 1 and v != 0:
                        relation_accumulator[pair_key].append(float(v))
        except:
            continue

    file_expls = data.get("metric_explanations", {}) or {}
    for metric, expl in file_expls.items():
        if isinstance(expl, str) and expl.strip():
            nm = normalize_name(metric)
            mp = nm if nm in PREDEFINED_CANONICALS_SET else METRIC_MAPPING.get(nm, nm)
            if mp in EXCLUDE_METRICS:
                continue
            metric_explanations_accumulator[mp].append(expl.strip())

    if idx % 50 == 0:
        print(f"已处理 {idx}/{actual_file_count} 个文件...")

print(f"共统计 {len(metric_counter)} 个指标（去重前alias按文件计数），{len(scene_counter)} 个网络场景。")

# ===================== 构造 LLM 去重候选文本 =====================
candidates = []
for metric, freq in metric_counter.items():
    expl_list = metric_explanations_accumulator.get(metric, [])
    chosen_ex = ""
    if expl_list:
        try:
            chosen_ex = Counter(expl_list).most_common(1)[0][0]
        except:
            chosen_ex = expl_list[0]
    candidates.append({"metric": metric, "count": int(freq), "example_explanation": chosen_ex})

if not candidates:
    raise RuntimeError("未找到候选指标用于去重。请检查输入 pkl 文件。")

lines = []
for c in sorted(candidates, key=lambda x: (-x["count"], x["metric"])):
    expl = c["example_explanation"].replace("\n", " ").strip() if c["example_explanation"] else ""
    lines.append(f"- {c['metric']} ({c['count']}): {expl}")
candidates_text = "\n".join(lines)


# ===================== 预分组：基于字符串相似性把相近 alias 放在一起 =====================
def cluster_aliases_by_string_similarity(lines, threshold=0.78):
    """
    将 lines (格式 '- metric (count): explanation') 按 metric 名聚类，基于 difflib.SequenceMatcher 相似度。
    返回按 cluster 顺序排列的 lines（cluster 内保持原顺序）。
    threshold: 相似度阈值（0-1），越高越严格（仅非常接近才归一组）。
    """
    parsed = []
    for line in lines:
        try:
            first = line.split(":", 1)[0]
            metric_part = first.strip().lstrip("-").strip()
            metric_name = metric_part.split("(", 1)[0].strip()
            parsed.append((metric_name, line))
        except:
            parsed.append((line, line))

    clusters = []  # list of lists of tuples (metric_name, line)
    for metric_name, line in parsed:
        placed = False
        for cl in clusters:
            rep = cl[0][0]
            sim = difflib.SequenceMatcher(None, metric_name, rep).ratio()
            if sim >= threshold:
                cl.append((metric_name, line))
                placed = True
                break
        if not placed:
            clusters.append([(metric_name, line)])
    ordered_lines = []
    for cl in clusters:
        for _, l in cl:
            ordered_lines.append(l)
    return ordered_lines


# ===================== 构造prompt指令 =====================
dedup_system_raw = (
    "你是网络通信领域专家，精通术语归一化。"
    "请根据给定的指标清单（含出现频次与一句话解释），把语义等价的指标分组并为每组选择一个规范名称（下划线风格）。"
    "返回严格 JSON，格式如下（解释性说明）：\n"
    "{\n"
    '  "groups": [\n'
    '    {"canonical": "end_to_end_delay", "aliases": ["e2e_delay","end_to_end_delay"], "member_counts": {"e2e_delay":1,"end_to_end_delay":3}, "total_count": 4}\n'
    "  ],\n"
    '  "alias_to_canonical": {"e2e_delay":"end_to_end_delay"}\n'
    "}\n"
    "注意：仅返回 JSON，不要额外注释。canonical 应使用下划线命名。"
)
# escape braces for ChatPromptTemplate usage
dedup_system = dedup_system_raw.replace("{", "{{").replace("}", "}}")
dedup_human_template = "请对以下指标清单进行分组与归一化（格式必须返回 JSON）：\n\n{candidates}"

# ===================== 调用 DeepSeek/LLM（批次调用以避免单次响应过大） =====================
dedup_rules = None
use_llm = True
if ChatOpenAI is None or ChatPromptTemplate is None or StrOutputParser is None:
    print("langchain 或相关依赖不可用，使用本地回退去重逻辑。")
    use_llm = False

# batching params
BATCH_SIZE = 60  # 每次给 LLM 的候选数量，必要时可调小（例如 40 或 20）
SLEEP_BETWEEN_CALLS = 1.0  # 秒

if use_llm:
    try:
        llm = ChatOpenAI(
            model=LLM_CONFIG["model"],
            api_key=get_api_key_from_env(),
            base_url=DEEPSEEK_BASE_URL,
            temperature=LLM_CONFIG["temperature"],
            max_tokens=LLM_CONFIG["max_tokens"],
            streaming=LLM_CONFIG["streaming"],
            model_kwargs={"top_p": LLM_CONFIG["top_p"]},
        )

        dedup_prompt = ChatPromptTemplate.from_messages([
            ("system", dedup_system),
            ("human", dedup_human_template)
        ])
        dedup_chain = dedup_prompt | llm | StrOutputParser()

        print("调用 DeepSeek 分批进行语义去重（批量减少导致的 JSON 过大/被截断问题）...")

        # ===== 使用预分组后的 candidate_lines =====
        candidate_lines = cluster_aliases_by_string_similarity(lines, threshold=0.78)
        total_lines = len(candidate_lines)

        alias_to_canonical_global = {}
        groups_global = []

        # split candidates into batches
        for start in range(0, total_lines, BATCH_SIZE):
            end = min(start + BATCH_SIZE, total_lines)
            batch_lines = candidate_lines[start:end]
            batch_text = "\n".join(batch_lines)
            print(f"  正在处理第 {start + 1}-{end} 个候选（共 {total_lines}）...")
            try:
                raw_resp = dedup_chain.invoke({"candidates": batch_text})
                parsed, used = parse_json_from_response(raw_resp)
                if parsed and isinstance(parsed, dict):
                    # merge alias_to_canonical
                    batch_alias_map = parsed.get("alias_to_canonical", {}) or {}
                    # normalize mapping and enforce PREDEFINED_CANONICALS constraints
                    for a, c in batch_alias_map.items():
                        an = normalize_name(a)
                        cn = normalize_name(c)
                        if an in PREDEFINED_CANONICALS_SET:
                            alias_to_canonical_global[an] = an
                        elif cn in PREDEFINED_CANONICALS_SET:
                            alias_to_canonical_global[an] = cn
                        else:
                            alias_to_canonical_global[an] = cn
                    # merge groups (if any) - append as-is (we will rebuild canonical groups later)
                    batch_groups = parsed.get("groups", []) or []
                    for g in batch_groups:
                        groups_global.append(g)
                else:
                    # 解析失败：对本批使用本地回退映射，避免放弃整个流程
                    print(f"  批次 {start + 1}-{end}：LLM 返回无法解析 JSON，使用本地回退映射该批候选。")
                    for line in batch_lines:
                        # line format: "- metric (count): explanation"
                        try:
                            first = line.split(":", 1)[0]
                            metric_part = first.strip().lstrip("-").strip()
                            metric_name = metric_part.split("(", 1)[0].strip()
                            an = normalize_name(metric_name)
                            if an in PREDEFINED_CANONICALS_SET:
                                alias_to_canonical_global[an] = an
                            elif an in METRIC_MAPPING:
                                alias_to_canonical_global[an] = METRIC_MAPPING[an]
                            else:
                                alias_to_canonical_global[an] = an
                        except Exception:
                            continue
                time.sleep(SLEEP_BETWEEN_CALLS)
            except Exception as exc:
                print(f"  批次 {start + 1}-{end} 调用 LLM 出错：{exc}，使用本地回退映射该批候选。")
                for line in batch_lines:
                    try:
                        first = line.split(":", 1)[0]
                        metric_part = first.strip().lstrip("-").strip()
                        metric_name = metric_part.split("(", 1)[0].strip()
                        an = normalize_name(metric_name)
                        if an in PREDEFINED_CANONICALS_SET:
                            alias_to_canonical_global[an] = an
                        elif an in METRIC_MAPPING:
                            alias_to_canonical_global[an] = METRIC_MAPPING[an]
                        else:
                            alias_to_canonical_global[an] = an
                    except Exception:
                        continue

        # after batching, ensure every observed metric maps to something
        for m in list(metric_counter.keys()):
            if m not in alias_to_canonical_global:
                if m in PREDEFINED_CANONICALS_SET:
                    alias_to_canonical_global[m] = m
                elif m in METRIC_MAPPING:
                    alias_to_canonical_global[m] = METRIC_MAPPING[m]
                else:
                    alias_to_canonical_global[m] = m

        # rebuild groups_map from alias_to_canonical_global for consistency
        groups_map = defaultdict(lambda: {"aliases": [], "member_counts": {}})
        for alias, canonical in alias_to_canonical_global.items():
            groups_map[canonical]["aliases"].append(alias)
            groups_map[canonical]["member_counts"][alias] = metric_counter.get(alias, 0)
        groups_list = []
        for c, info in groups_map.items():
            total = sum(info["member_counts"].values())
            groups_list.append({
                "canonical": c,
                "aliases": sorted(info["aliases"]),
                "member_counts": info["member_counts"],
                "total_count": total
            })
        dedup_rules = {"groups": groups_list, "alias_to_canonical": alias_to_canonical_global}

    except EnvironmentError:
        raise
    except Exception as exc:
        print("调用 DeepSeek 主流程出错，回退至本地合并逻辑。错误：", exc)
        use_llm = False
        dedup_rules = None

# ===================== 本地回退合并（如果 LLM 不可用或部分批次失败） =====================
if not use_llm or not dedup_rules:
    print("使用本地回退去重逻辑（METRIC_MAPPING/简单规范化）...")
    alias_to_canonical = {}
    for m in metric_counter:
        if m in PREDEFINED_CANONICALS_SET:
            alias_to_canonical[m] = m
        elif m in METRIC_MAPPING:
            alias_to_canonical[m] = normalize_name(METRIC_MAPPING[m])
        else:
            alias_to_canonical[m] = m

    groups_map = defaultdict(lambda: {"aliases": [], "member_counts": {}})
    for alias, canonical in alias_to_canonical.items():
        groups_map[canonical]["aliases"].append(alias)
        groups_map[canonical]["member_counts"][alias] = metric_counter.get(alias, 0)
    groups_list = []
    for c, info in groups_map.items():
        total = sum(info["member_counts"].values())
        groups_list.append({
            "canonical": c,
            "aliases": sorted(info["aliases"]),
            "member_counts": info["member_counts"],
            "total_count": total
        })
    dedup_rules = {"groups": groups_list, "alias_to_canonical": alias_to_canonical}
else:
    # 若 LLM 提供 dedup_rules，确保 PREDEFINED_CANONICALS 的约束生效并 normalize
    try:
        raw_alias_to_can = dedup_rules.get("alias_to_canonical", {}) if isinstance(dedup_rules, dict) else {}
        alias_to_canonical = {}
        for a, c in raw_alias_to_can.items():
            an = normalize_name(a)
            cn = normalize_name(c)
            if an in PREDEFINED_CANONICALS_SET:
                alias_to_canonical[an] = an
            elif cn in PREDEFINED_CANONICALS_SET:
                alias_to_canonical[an] = cn
            else:
                alias_to_canonical[an] = cn
        # ensure every observed metric at least maps to itself
        for m in list(metric_counter.keys()):
            if m not in alias_to_canonical:
                alias_to_canonical[m] = m

        # rebuild groups list from alias_to_canonical to ensure consistency
        groups_map = defaultdict(lambda: {"aliases": [], "member_counts": {}})
        for alias, canonical in alias_to_canonical.items():
            groups_map[canonical]["aliases"].append(alias)
            groups_map[canonical]["member_counts"][alias] = metric_counter.get(alias, 0)
        groups_list = []
        for c, info in groups_map.items():
            total = sum(info["member_counts"].values())
            groups_list.append({
                "canonical": c,
                "aliases": sorted(info["aliases"]),
                "member_counts": info["member_counts"],
                "total_count": total
            })
        dedup_rules = {"groups": groups_list, "alias_to_canonical": alias_to_canonical}
    except Exception as ex:
        print("处理 LLM 返回时出错，回退本地合并。", ex)
        alias_to_canonical = {}
        for m in metric_counter:
            if m in PREDEFINED_CANONICALS_SET:
                alias_to_canonical[m] = m
            elif m in METRIC_MAPPING:
                alias_to_canonical[m] = normalize_name(METRIC_MAPPING[m])
            else:
                alias_to_canonical[m] = m
        groups_map = defaultdict(lambda: {"aliases": [], "member_counts": {}})
        for alias, canonical in alias_to_canonical.items():
            groups_map[canonical]["aliases"].append(alias)
            groups_map[canonical]["member_counts"][alias] = metric_counter.get(alias, 0)
        groups_list = []
        for c, info in groups_map.items():
            total = sum(info["member_counts"].values())
            groups_list.append({
                "canonical": c,
                "aliases": sorted(info["aliases"]),
                "member_counts": info["member_counts"],
                "total_count": total
            })
        dedup_rules = {"groups": groups_list, "alias_to_canonical": alias_to_canonical}

# 保存去重规则
dedup_rules_path = os.path.join(PDF_OUTPUT_DIR, "dedup_rules.json")
try:
    with open(dedup_rules_path, "w", encoding="utf-8") as wf:
        json.dump(dedup_rules, wf, ensure_ascii=False, indent=2)
    print("去重规则保存至：", dedup_rules_path)
except Exception as e:
    print("保存 dedup_rules 失败：", e)

# ===================== 根据去重规则进行合并统计（构造 alias_to_canonical 并 enforce PREDEFINED） =====================
alias_to_canonical_raw = dedup_rules.get("alias_to_canonical", {}) if isinstance(dedup_rules, dict) else {}
# normalize mapping keys/values
alias_to_canonical = {}
for a, c in alias_to_canonical_raw.items():
    an = normalize_name(a)
    cn = normalize_name(c)
    if an in PREDEFINED_CANONICALS_SET:
        alias_to_canonical[an] = an
    elif cn in PREDEFINED_CANONICALS_SET:
        alias_to_canonical[an] = cn
    else:
        alias_to_canonical[an] = cn

# ensure every metric maps to something
for m in list(metric_counter.keys()):
    if m not in alias_to_canonical:
        alias_to_canonical[m] = m

# aggregated_counts 已经在 metric_counter 中为“去重前alias按文件计数”
aggregated_counts = Counter()
aggregated_explanations = defaultdict(set)
aggregated_originals = defaultdict(set)
aggregated_units = defaultdict(set)

# ========== 修改点2：仅累加映射目标指标的频次，被映射指标的频次合并到目标指标 ==========
for alias, cnt in metric_counter.items():
    can = alias_to_canonical.get(alias, alias)
    aggregated_counts[can] += int(cnt)
    for ex in metric_explanations_accumulator.get(alias, []):
        if ex and isinstance(ex, str):
            aggregated_explanations[can].add(ex.strip())
    for orig in metric_originals_accumulator.get(alias, set()):
        aggregated_originals[can].add(orig)
    for u in metric_units_accumulator.get(alias, set()):
        aggregated_units[can].add(u)

for g in dedup_rules.get("groups", []):
    can = normalize_name(g.get("canonical", ""))
    mc = g.get("member_counts", {}) or {}
    try:
        total_from_llm = int(g.get("total_count", 0))
        if total_from_llm > aggregated_counts.get(can, 0):
            aggregated_counts[can] = total_from_llm
    except:
        pass
    for m_name, m_cnt in mc.items():
        mn = normalize_name(m_name)
        if alias_to_canonical.get(mn, mn) != can:
            alias_to_canonical[mn] = can
        for ex in metric_explanations_accumulator.get(mn, []):
            aggregated_explanations[can].add(ex.strip())
        for orig in metric_originals_accumulator.get(mn, set()):
            aggregated_originals[can].add(orig)
        for u in metric_units_accumulator.get(mn, set()):
            aggregated_units[can].add(u)

for k in list(aggregated_counts.keys()):
    if aggregated_counts[k] == 0:
        del aggregated_counts[k]
        aggregated_explanations.pop(k, None)
        aggregated_originals.pop(k, None)
        aggregated_units.pop(k, None)

# ===================== 新增：分场景的“去重后（canonical）按文件计数”与频次分布 =====================
scene_aggregated_counts = defaultdict(Counter)  # fig_7and8 -> Counter(canonical_metric -> per-file frequency)
for sc, pre_counter in scene_metric_counter.items():
    for alias, cnt in (pre_counter or {}).items():
        can = alias_to_canonical.get(alias, alias)
        if can in EXCLUDE_METRICS:
            continue
        scene_aggregated_counts[sc][can] += int(cnt)

# 生成全量 & 分场景的统计摘要（去重前/后 总数 + 频次1..5分布）
overall_pre_unique, overall_pre_sum = summarize_counter_basic(metric_counter)
overall_post_unique, overall_post_sum = summarize_counter_basic(aggregated_counts)
overall_post_dist_1to5 = freq_bucket_1_to_5(aggregated_counts)

scene_stats_summary = {}  # fig_7and8 -> dict
for sc in scene_counter.keys():
    pre_c = scene_metric_counter.get(sc, Counter())
    post_c = scene_aggregated_counts.get(sc, Counter())
    pre_u, pre_s = summarize_counter_basic(pre_c)
    post_u, post_s = summarize_counter_basic(post_c)
    scene_stats_summary[sc] = {
        "pre": {"unique": pre_u, "sum": pre_s},
        "post": {"unique": post_u, "sum": post_s, "dist_1to5": freq_bucket_1_to_5(post_c)}
    }

# 将新增统计结果与相关中间数据以 Pickle 格式落盘（命名/路径保持现有输出风格）
stats_pkl_path = os.path.join(PDF_OUTPUT_DIR, "场景_指标统计中间数据.pkl")
try:
    stats_payload = {
        "timestamp": time.strftime('%Y-%m-%d %H:%M:%S'),
        "pkl_input_dir": PKL_INPUT_DIR,
        "pdf_output_dir": PDF_OUTPUT_DIR,
        "actual_file_count": actual_file_count,
        # 全量（去重前 alias / 去重后 canonical）
        "metric_counter_pre": metric_counter,
        "aggregated_counts_post": aggregated_counts,
        "overall_pre": {"unique": overall_pre_unique, "sum": overall_pre_sum},
        "overall_post": {"unique": overall_post_unique, "sum": overall_post_sum, "dist_1to5": overall_post_dist_1to5},
        # 分场景（去重前 / 去重后）
        "scene_counter": scene_counter,
        "scene_metric_counter_pre": scene_metric_counter,
        "scene_aggregated_counts_post": scene_aggregated_counts,
        "scene_stats_summary": scene_stats_summary,
        # 便于复现的关键映射
        "alias_to_canonical": alias_to_canonical,
        "dedup_rules_path": dedup_rules_path,
    }
    with open(stats_pkl_path, "wb") as wf:
        pickle.dump(stats_payload, wf)
    print("新增统计与中间数据 Pickle 已保存：", stats_pkl_path)
except Exception as e:
    print("保存新增统计 Pickle 失败：", e)

# ===================== 重新合并关系（按 canonical） =====================
relation_accumulator_merged = defaultdict(list)
# ========== 修改点3：仅保留目标指标的原始相关系数，被映射指标的相关系数不参与合并 ==========
# 先获取所有目标指标（canonical）集合
canonical_metrics = set(aggregated_counts.keys())
for pair_key, corr_list in relation_accumulator.items():
    parts = pair_key.split("-")
    if len(parts) < 2:
        continue
    metric1_raw = parts[0]
    metric2_raw = "-".join(parts[1:])
    m1 = normalize_name(metric1_raw)
    m2 = normalize_name(metric2_raw)

    # 仅处理原始指标本身就是目标指标的情况，被映射的指标跳过
    if m1 not in canonical_metrics or m2 not in canonical_metrics:
        continue

    c1 = alias_to_canonical.get(m1, m1)
    c2 = alias_to_canonical.get(m2, m2)
    if c1 in EXCLUDE_METRICS or c2 in EXCLUDE_METRICS:
        continue
    sorted_pair = sorted([c1, c2])
    mapped_pair_key = f"{sorted_pair[0]}-{sorted_pair[1]}"
    # 再次过滤0值
    for v in corr_list:
        try:
            if isinstance(v, (int, float)) and -1 <= v <= 1 and v != 0:
                relation_accumulator_merged[mapped_pair_key].append(float(v))
        except:
            continue

# ===================== 生成高频指标（若无满足 MIN_METRIC_FREQ，则降级为 top-k） =====================
# 仅保留目标指标，被映射的指标不纳入
high_freq_metrics = [m for m, f in aggregated_counts.most_common() if f >= MIN_METRIC_FREQ]
if not high_freq_metrics:
    top_k = min(30, max(1, len(aggregated_counts)))
    print(f"警告：没有满足 MIN_METRIC_FREQ={MIN_METRIC_FREQ} 的指标。将使用去重后频次最高的前 {top_k} 个指标继续处理。")
    high_freq_metrics = [m for m, _ in aggregated_counts.most_common(top_k)]

print(f"高频指标数量（去重后用于绘图/矩阵）: {len(high_freq_metrics)}")

n = len(high_freq_metrics)
# ========== 修改点4：初始化对角线为1的矩阵，确保热力图对角线强制为1 ==========
avg_corr_matrix = np.eye(n)  # 对角线初始化为1，后续不覆盖
metric_index = {metric: i for i, metric in enumerate(high_freq_metrics)}

# 填充非对角线的相关系数（保持目标指标原始值）
for pair_key, corr_list in relation_accumulator_merged.items():
    parts = pair_key.split("-")
    if len(parts) != 2:
        continue
    a, b = parts
    if a in metric_index and b in metric_index and len(corr_list) > 0:
        i = metric_index[a]
        j = metric_index[b]
        # 跳过对角线（已强制为1）
        if i == j:
            continue
        avg_val = float(np.mean(corr_list))
        avg_val = max(min(avg_val, 1.0), -1.0)
        avg_corr_matrix[i, j] = avg_val
        avg_corr_matrix[j, i] = avg_val

# 强制确保对角线为1（双重保险）
np.fill_diagonal(avg_corr_matrix, 1.0)

# apply custom overrides (normalize keys)
for custom_pair, custom_corr in CUSTOM_CORRELATIONS.items():
    try:
        p1, p2 = custom_pair.split("-")
        p1n = normalize_name(p1)
        p2n = normalize_name(p2)
        if p1n in metric_index and p2n in metric_index:
            i = metric_index[p1n]
            j = metric_index[p2n]
            # 自定义相关系数也不覆盖对角线（对角线强制为1）
            if i != j:
                avg_corr_matrix[i, j] = float(custom_corr)
                avg_corr_matrix[j, i] = float(custom_corr)
    except:
        continue

# ===================== 输出文本报告 =====================
stats_txt_path = os.path.join(PDF_OUTPUT_DIR, "Integrated_Statistics.txt")
with open(stats_txt_path, "w", encoding="utf-8") as wf:
    wf.write("=" * 100 + "\n")
    wf.write("网络通信论文指标统计（去重后按文件计数）\n")
    wf.write("=" * 100 + "\n\n")
    wf.write(f"统计时间: {time.strftime('%Y-%m-%d %H:%M:%S')}\n")
    wf.write(f"加载 pkl 文件数: {actual_file_count}\n")
    wf.write(f"去重后指标总数: {len(aggregated_counts)}\n")
    wf.write(f"用于绘图/矩阵的高频指标数量: {len(high_freq_metrics)}\n\n")

    # ===================== 新增：全量去重前/后总数 + 频次分布 =====================
    wf.write("【新增统计A：全量网络指标去重前/后规模与低频分布（按文件计数口径）】\n")
    wf.write("-" * 60 + "\n")
    wf.write(f"去重前（alias/初步规范化后）指标种类数: {overall_pre_unique}\n")
    wf.write(f"去重前（alias）频次总和: {overall_pre_sum}\n")
    wf.write(f"去重后（canonical/语义归一后）指标种类数: {overall_post_unique}\n")
    wf.write(f"去重后（canonical）频次总和: {overall_post_sum}\n")
    wf.write("去重后频次为1/2/3/4/5的指标数量分布:\n")
    wf.write(f"  freq=1: {overall_post_dist_1to5.get(1, 0)}\n")
    wf.write(f"  freq=2: {overall_post_dist_1to5.get(2, 0)}\n")
    wf.write(f"  freq=3: {overall_post_dist_1to5.get(3, 0)}\n")
    wf.write(f"  freq=4: {overall_post_dist_1to5.get(4, 0)}\n")
    wf.write(f"  freq=5: {overall_post_dist_1to5.get(5, 0)}\n\n")

    # ===================== 新增：分网络场景去重前/后统计 =====================
    wf.write("【新增统计B：分网络场景的去重前/后规模与低频分布（按文件计数口径）】\n")
    wf.write("-" * 60 + "\n")
    for sc, sc_cnt in scene_counter.most_common():
        ss = scene_stats_summary.get(sc, {})
        pre_u = ss.get("pre", {}).get("unique", 0)
        pre_s = ss.get("pre", {}).get("sum", 0)
        post_u = ss.get("post", {}).get("unique", 0)
        post_s = ss.get("post", {}).get("sum", 0)
        dist = ss.get("post", {}).get("dist_1to5", {i: 0 for i in range(1, 6)})
        wf.write(f"[{sc}] 论文数: {sc_cnt}\n")
        wf.write(f"  去重前指标种类数: {pre_u}；频次总和: {pre_s}\n")
        wf.write(f"  去重后指标种类数: {post_u}；频次总和: {post_s}\n")
        wf.write("  去重后频次为1/2/3/4/5的指标数量分布: "
                 f"1:{dist.get(1, 0)}  2:{dist.get(2, 0)}  3:{dist.get(3, 0)}  4:{dist.get(4, 0)}  5:{dist.get(5, 0)}\n\n")

    wf.write("【预定义标准化指标（不会作为他物的原始变体）】\n")
    wf.write("-" * 60 + "\n")
    if PREDEFINED_CANONICALS:
        for c in sorted(PREDEFINED_CANONICALS):
            wf.write(f"{c}\n")
    else:
        wf.write("（未配置预定义标准化指标）\n")
    wf.write("\n【去重细则 alias -> canonical】\n")
    wf.write("-" * 60 + "\n")
    for alias, canonical in sorted(alias_to_canonical.items()):
        wf.write(f"{alias} -> {canonical}  (原始计数={metric_counter.get(alias, 0)})\n")
    wf.write("\n【去重分组（LLM 输出或本地回退）】\n")
    wf.write("-" * 60 + "\n")
    for g in dedup_rules.get("groups", []):
        wf.write(json.dumps(g, ensure_ascii=False) + "\n")
    wf.write("\n【核心指标（去重后）】\n")
    wf.write("-" * 60 + "\n")
    for i, metric in enumerate(high_freq_metrics, 1):
        freq = aggregated_counts.get(metric, 0)
        coverage = (freq / actual_file_count * 100) if actual_file_count else 0.0
        originals = ", ".join(sorted(aggregated_originals.get(metric, set()))) or "无记录"
        units = ", ".join(sorted(aggregated_units.get(metric, set()))) or "无单位"
        expls = "；".join(sorted(aggregated_explanations.get(metric, set()))) or "无解释"
        wf.write(f"{i:2d}. {metric}\n")
        wf.write(f"   出现频次（去重后按文件计数）: {freq} ({coverage:.1f}%)\n")
        wf.write(f"   原始变体: {originals}\n")
        wf.write(f"   单位: {units}\n")
        wf.write(f"   解释示例: {expls}\n\n")
print("统计报告已保存：", stats_txt_path)

# ===================== 绘图：相关系数热力图 =====================
# 按要求：无需再生成 "相关系数热力图.pdf"
print("按要求跳过生成：相关系数热力图.pdf")

# ===================== 绘图：网络场景频次 =====================
# 按要求：无需再生成 "网络场景统计图.pdf"
print("按要求跳过生成：网络场景统计图.pdf")

# ==========================================================================================
# ✅新增：网络指标频次幂律拟合图（基于“去重后网络指标频次” aggregated_counts）
# 说明：
# - 完全旁路新增，不修改既有统计/绘图对象与输出文件；
# - 参照示例代码：log-log 拟合，但以 semi-log（仅y轴取log）方式展示；
# - 输出文件名固定为 “网络指标频次幂律拟合图.pdf”，保存到同一输出目录。
# ==========================================================================================
print("开始进行去重后网络指标排序位次的重尾特性分析（幂律拟合）...")

sorted_post_metrics = aggregated_counts.most_common()
post_metrics = [item[0] for item in sorted_post_metrics]
post_freqs = [int(item[1]) for item in sorted_post_metrics]

if len(post_metrics) == 0:
    print("⚠ 去重后未统计到任何指标，跳过网络指标频次幂律拟合图生成。")
    power_law_plot_path = "无有效输出"
else:
    n_metrics_post = len(post_metrics)
    ranks = np.arange(1, n_metrics_post + 1, dtype=float)
    counts = np.array(post_freqs, dtype=float)

    top_k_fit = min(200, n_metrics_post)
    ranks_fit = ranks[:top_k_fit]
    counts_fit = counts[:top_k_fit]

    mask_fit = counts_fit > 0
    ranks_fit = ranks_fit[mask_fit]
    counts_fit = counts_fit[mask_fit]

    if len(ranks_fit) < 2:
        print("⚠ 用于幂律拟合的有效数据点不足，跳过重尾特性分析。")
        power_law_plot_path = "无有效输出"
    else:
        # 幂律拟合（log-log 线性化）
        log_r_fit = np.log10(ranks_fit)
        log_f_fit = np.log10(counts_fit)

        slope, intercept = np.polyfit(log_r_fit, log_f_fit, 1)
        log_f_pred_fit = slope * log_r_fit + intercept

        ss_res = np.sum((log_f_fit - log_f_pred_fit) ** 2)
        ss_tot = np.sum((log_f_fit - np.mean(log_f_fit)) ** 2)
        r2 = 1 - ss_res / ss_tot if ss_tot > 0 else np.nan

        print(f"幂律拟合结果（基于去重后前 {top_k_fit} 个高频指标）：")
        print(f"  log [f(r)] = {slope:.4f} * log (r) + {intercept:.4f}")
        print(f"  对应幂律形式：f(r) ∝ r^{slope:.4f}")
        print(f"  拟合优度 R² = {r2:.4f}，有效拟合点数 = {len(ranks_fit)}")

        # 转回原尺度：f(r) = C * r^slope，C = 10^intercept
        C = 10 ** intercept

        mask_all = counts > 0
        ranks_all = ranks[mask_all]
        counts_all = counts[mask_all]
        f_pred_all = C * (ranks_all ** slope)

        fig_pw, ax_pw = plt.subplots(figsize=(7, 6))

        # 与示例保持一致的展示风格：散点+拟合线；仅y轴log（semi-log）
        scatter_color = "#1f77b4"  # 默认蓝
        fitline_color = "#dc143c"  # 默认红

        ax_pw.scatter(
            ranks_all,
            counts_all,
            s=30,
            alpha=0.8,
            edgecolor="none",
            linewidth=0,
            color=scatter_color
        )
        ax_pw.plot(
            ranks_all,
            f_pred_all,
            color=fitline_color,
            linestyle="--",
            linewidth=2
        )

        ax_pw.set_yscale("log")  # 半对数：仅y轴取log
        ax_pw.set_xlabel("Metric Ranking:  r", fontproperties=get_tnr_font(14))
        ax_pw.set_ylabel("Metric Frequency:  f(r)", fontproperties=get_tnr_font(14))

        for tick in ax_pw.get_xticklabels():
            tick.set_fontproperties(get_tnr_font(12))
        for tick in ax_pw.get_yticklabels():
            tick.set_fontproperties(get_tnr_font(12))

        slope_str = f"{slope:.3f}"
        intercept_str = f"{intercept:.3f}"
        r2_str = f"{r2:.3f}" if not np.isnan(r2) else "nan"
        equation_label = f"log [f(r)] = {slope_str} * log (r) + {intercept_str}; R² = {r2_str}"

        # 图例句柄（与示例一致）
        legend_scatter_handle = Line2D(
            [], [], linestyle="none",
            marker="o", markersize=6,
            markerfacecolor=scatter_color,
            markeredgecolor="black",
            markeredgewidth=0.6
        )
        legend_line_handle = Line2D(
            [], [], color=fitline_color,
            linewidth=2,
            linestyle="--"
        )
        legend_placeholder_handle = Line2D(
            [], [], linestyle="none",
            marker="o", markersize=6,
            markerfacecolor="none",
            markeredgecolor="none"
        )

        legend_handles = [
            legend_scatter_handle,
            legend_line_handle,
            legend_placeholder_handle
        ]
        legend_labels = [
            ": Empirical data",
            ": Fitted curve",
            equation_label
        ]

        legend = ax_pw.legend(
            legend_handles,
            legend_labels,
            loc="upper right",
            frameon=True,
            framealpha=0.9,
            borderpad=0.8,
            handlelength=1.6,
            handletextpad=0.6,
            labelspacing=0.5
        )
        for text in legend.get_texts():
            text.set_fontproperties(get_tnr_font(11))
            text.set_ha("left")
        try:
            legend._legend_box.align = "left"
        except Exception:
            pass

        ax_pw.grid(True, which="both", linestyle="--", linewidth=0.4, alpha=0.4)

        plt.tight_layout()
        power_law_plot_path = os.path.join(PDF_OUTPUT_DIR, "网络指标频次幂律拟合图.pdf")
        plt.savefig(
            power_law_plot_path,
            format="pdf",
            bbox_inches="tight",
            dpi=330,
            facecolor="white"
        )
        plt.close(fig_pw)
        print("网络指标频次幂律拟合图保存：", power_law_plot_path)
# ==========================================================================================

print("\n完成。输出目录：", PDF_OUTPUT_DIR)
print("生成文件列表：", stats_txt_path, dedup_rules_path, stats_pkl_path)
print("已按要求跳过生成文件：相关系数热力图.pdf，网络场景统计图.pdf")
# ✅幂律拟合图已在上方单独打印保存路径（避免改变既有“生成文件列表”的输出结构）。