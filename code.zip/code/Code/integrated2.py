# -*- coding: utf-8 -*-
"""
export_metric_stats_from_pkl.py

用途：
  读取 integrated.py 运行后生成的 “场景_指标统计中间数据.pkl”，
  对指标进行去重汇总、按频次降序排序，并导出便于人工检查的 .txt 报告。

特点：
  1. 优先使用中间 pkl 中已经去重后的 aggregated_counts_post；
  2. 若缺少去重后计数字段，则使用 metric_counter_pre + alias_to_canonical 重新汇总；
  3. 原始变体优先从 alias_to_canonical / dedup_rules / metric_counter_pre 中恢复；
  4. 单位和解释示例如果中间 pkl 未保存，会尝试回扫 pkl_input_dir 下的原始 *_metrics_relations.pkl 文件补齐；
  5. 对字段名做了多组候选判断，兼容字段名称不完全一致的情况。

运行示例：
  python export_metric_stats_from_pkl.py \
      --input "E:/Research_Group/TON_2025/code/12.1/output/Detail/场景_指标统计中间数据.pkl" \
      --output "E:/Research_Group/TON_2025/code/12.1/output/Detail/指标统计整理结果_按频次排序.txt"

也可以只写：
  python export_metric_stats_from_pkl.py --input "场景_指标统计中间数据.pkl"
"""

from __future__ import annotations

import argparse
import json
import pickle
import re
from collections import Counter, defaultdict
from pathlib import Path
from typing import Any, Iterable, Mapping


# =========================
# 可按需修改的默认配置
# =========================
DEFAULT_INPUT_PKL = "E:/Research_Group/TON_2025/code/12.1/output/Detail/场景_指标统计中间数据.pkl"
DEFAULT_OUTPUT_TXT = "E:/Research_Group/TON_2025/code/12.1/output/Detail/Metrics list.txt"

# None 表示不截断；如果报告太长，可改成整数，例如 50 / 20 / 3。
MAX_VARIANTS_TO_SHOW: int | None = None
MAX_UNITS_TO_SHOW: int | None = None
MAX_EXAMPLES_TO_SHOW: int | None = 3

# 常见字段名候选：字段结构略有变化时，脚本会按顺序寻找。
POST_COUNT_FIELDS = (
    "aggregated_counts_post",
    "metric_counter_post",
    "metric_counts_post",
    "canonical_metric_counter",
    "canonical_counts",
    "aggregated_counts",
    "final_metric_counts",
    "metric_counts",
)

PRE_COUNT_FIELDS = (
    "metric_counter_pre",
    "metric_counter",
    "metric_counts_pre",
    "alias_metric_counter",
    "raw_metric_counter",
)

SCENE_POST_COUNT_FIELDS = (
    "scene_aggregated_counts_post",
    "scene_metric_counts_post",
    "scene_canonical_counts",
)

ALIAS_MAP_FIELDS = (
    "alias_to_canonical",
    "alias_to_canon",
    "alias_map",
    "dedup_map",
    "metric_mapping",
    "canonical_map",
)

ORIGINAL_VARIANT_FIELDS = (
    "aggregated_originals",
    "metric_originals_accumulator",
    "metric_originals",
    "originals_by_metric",
    "original_variants",
)

UNIT_FIELDS = (
    "aggregated_units",
    "metric_units_accumulator",
    "metric_units",
    "units_by_metric",
    "metric_units_post",
    "units",
)

EXPLANATION_FIELDS = (
    "aggregated_explanations",
    "metric_explanations_accumulator",
    "metric_explanations",
    "explanations_by_metric",
    "metric_explanations_post",
    "explanations",
)

COUNT_KEYS = ("count", "counts", "freq", "frequency", "total_count", "出现频次", "频次", "value")
NAME_KEYS = ("metric", "metric_name", "name", "canonical", "indicator", "指标", "指标名称")
UNIT_KEYS = ("unit", "units", "单位", "measurement_unit")
EXPLANATION_KEYS = ("explanation", "explanations", "解释", "解释示例", "example_explanation", "description")


# =========================
# 基础工具函数
# =========================
def normalize_name(name: Any) -> str:
    """与 integrated.py 保持一致的指标名规范化方式：小写、去首尾空格、空格/连字符转下划线。"""
    if name is None:
        return ""
    text = str(name).strip()
    text = text.lower().replace(" ", "_").replace("-", "_")
    text = re.sub(r"_+", "_", text)
    return text.strip("_")


def load_pickle(path: Path) -> Any:
    with path.open("rb") as f:
        return pickle.load(f)


def load_json(path: Path) -> Any:
    with path.open("r", encoding="utf-8") as f:
        return json.load(f)


def first_existing(mapping: Mapping[str, Any], field_names: Iterable[str]) -> tuple[str | None, Any | None]:
    """返回第一个存在且非空的字段。"""
    for key in field_names:
        if key in mapping and mapping[key] not in (None, {}, [], set(), tuple()):
            return key, mapping[key]
    return None, None


def parse_count(value: Any) -> int:
    """尽量把不同类型的计数字段转为 int；无法解析时返回 0。"""
    if value is None or isinstance(value, bool):
        return 0
    if isinstance(value, (int, float)):
        try:
            return int(value)
        except Exception:
            return 0
    if isinstance(value, str):
        s = value.strip()
        if not s:
            return 0
        try:
            return int(float(s))
        except Exception:
            return 0
    if isinstance(value, Mapping):
        for key in COUNT_KEYS:
            if key in value:
                return parse_count(value[key])
    return 0


def flatten_texts(value: Any, *, split_units: bool = False) -> list[str]:
    """
    把字符串 / list / set / dict 等字段整理为字符串列表。
    split_units=True 时，会把 'ms, s；秒' 这类单位字符串拆开。
    """
    if value is None:
        return []

    if isinstance(value, str):
        text = value.strip()
        if not text:
            return []
        if split_units:
            parts = re.split(r"[,，;；/、]+", text)
            return [p.strip() for p in parts if p.strip()]
        return [text]

    if isinstance(value, Mapping):
        # 如果是 {'unit': 'ms'} / {'explanation': '...'} 这类结构，优先取值。
        results: list[str] = []
        for v in value.values():
            results.extend(flatten_texts(v, split_units=split_units))
        return results

    if isinstance(value, (list, tuple, set)):
        results: list[str] = []
        for item in value:
            results.extend(flatten_texts(item, split_units=split_units))
        return results

    text = str(value).strip()
    return [text] if text else []


def counter_like_to_counter(obj: Any) -> Counter:
    """
    将 Counter / dict / list[tuple] / list[dict] 等结构尽量转成 Counter。
    输出 key 会先 normalize_name，便于后续 alias -> canonical 汇总。
    """
    counter = Counter()

    if obj is None:
        return counter

    if isinstance(obj, Mapping):
        for key, value in obj.items():
            name = normalize_name(key)
            if not name:
                continue
            cnt = parse_count(value)
            if cnt > 0:
                counter[name] += cnt
        return counter

    if isinstance(obj, (list, tuple, set)):
        for item in obj:
            if isinstance(item, Mapping):
                name = ""
                for nk in NAME_KEYS:
                    if nk in item:
                        name = normalize_name(item[nk])
                        break
                if not name:
                    continue
                cnt = 0
                for ck in COUNT_KEYS:
                    if ck in item:
                        cnt = parse_count(item[ck])
                        break
                if cnt > 0:
                    counter[name] += cnt
            elif isinstance(item, (list, tuple)) and len(item) >= 2:
                name = normalize_name(item[0])
                cnt = parse_count(item[1])
                if name and cnt > 0:
                    counter[name] += cnt
        return counter

    return counter


def normalize_alias_map(raw_map: Any) -> dict[str, str]:
    """把 alias -> canonical 映射规范化为下划线风格。"""
    alias_map: dict[str, str] = {}
    if not isinstance(raw_map, Mapping):
        return alias_map
    for alias, canonical in raw_map.items():
        a = normalize_name(alias)
        c = normalize_name(canonical)
        if a and c:
            alias_map[a] = c
    return alias_map


def canonical_of(name: Any, alias_map: Mapping[str, str]) -> str:
    """返回指标的 canonical 名称；支持 alias 链式映射，并避免循环。"""
    current = normalize_name(name)
    if not current:
        return ""
    seen: set[str] = set()
    while current in alias_map and alias_map[current] != current:
        if current in seen:
            break
        seen.add(current)
        nxt = normalize_name(alias_map[current])
        if not nxt:
            break
        current = nxt
    return current


def update_counter_map(target: dict[str, Counter], metric: Any, values: Any, alias_map: Mapping[str, str], *, split_units: bool = False) -> None:
    """把 metric -> values 字段合并到 target[canonical] 的 Counter 中。"""
    can = canonical_of(metric, alias_map)
    if not can:
        return
    for text in flatten_texts(values, split_units=split_units):
        if text:
            target[can][text] += 1


def format_counter_items(counter: Counter, *, empty: str, max_items: int | None = None, with_counts: bool = False) -> str:
    """把 Counter 格式化为清晰的一行文本。"""
    if not counter:
        return empty

    items = counter.most_common()
    if max_items is not None:
        shown = items[:max_items]
        omitted = len(items) - len(shown)
    else:
        shown = items
        omitted = 0

    if with_counts:
        text = "；".join(f"{name}({cnt})" for name, cnt in shown)
    else:
        text = "；".join(name for name, _ in shown)

    if omitted > 0:
        text += f"；……另有 {omitted} 项"
    return text or empty


def format_examples(counter: Counter, *, max_items: int | None = 3) -> list[str]:
    """解释示例一般较长，按列表输出。"""
    if not counter:
        return ["无解释记录"]
    items = counter.most_common(max_items)
    return [text for text, _ in items]


# =========================
# dedup_rules 与字段抽取
# =========================
def load_dedup_rules_from_payload(payload: Mapping[str, Any], input_pkl_path: Path) -> dict[str, Any]:
    """优先读取 payload 内的 dedup_rules；若没有，再尝试读取 dedup_rules_path。"""
    if isinstance(payload.get("dedup_rules"), Mapping):
        return dict(payload["dedup_rules"])

    path_str = payload.get("dedup_rules_path")
    if not path_str:
        return {}

    candidate_paths = [Path(str(path_str))]
    if not Path(str(path_str)).is_absolute():
        candidate_paths.append(input_pkl_path.parent / str(path_str))

    for p in candidate_paths:
        try:
            if p.exists() and p.is_file():
                data = load_json(p)
                return data if isinstance(data, dict) else {}
        except Exception as exc:
            print(f"提示：读取 dedup_rules 失败：{p}，原因：{exc}")
    return {}


def collect_alias_map(payload: Mapping[str, Any], dedup_rules: Mapping[str, Any]) -> dict[str, str]:
    """从 payload 与 dedup_rules 中合并 alias_to_canonical。"""
    alias_map: dict[str, str] = {}

    for field in ALIAS_MAP_FIELDS:
        if isinstance(payload.get(field), Mapping):
            alias_map.update(normalize_alias_map(payload[field]))

    if isinstance(dedup_rules, Mapping):
        if isinstance(dedup_rules.get("alias_to_canonical"), Mapping):
            alias_map.update(normalize_alias_map(dedup_rules["alias_to_canonical"]))

        # 兼容 groups: [{canonical, aliases, member_counts, total_count}, ...]
        groups = dedup_rules.get("groups", [])
        if isinstance(groups, list):
            for g in groups:
                if not isinstance(g, Mapping):
                    continue
                can = normalize_name(g.get("canonical"))
                if not can:
                    continue
                for alias in flatten_texts(g.get("aliases")):
                    a = normalize_name(alias)
                    if a:
                        alias_map[a] = can
                member_counts = g.get("member_counts")
                if isinstance(member_counts, Mapping):
                    for alias in member_counts.keys():
                        a = normalize_name(alias)
                        if a:
                            alias_map[a] = can

    # 确保 canonical 自身也能映射到自身。
    for _, can in list(alias_map.items()):
        if can:
            alias_map.setdefault(can, can)

    return alias_map


def collect_map_fields(payload: Mapping[str, Any], fields: Iterable[str], alias_map: Mapping[str, str], *, split_units: bool = False) -> dict[str, Counter]:
    """抽取类似 aggregated_units / aggregated_explanations 这类 metric -> values 的字段。"""
    target: dict[str, Counter] = defaultdict(Counter)
    for field in fields:
        obj = payload.get(field)
        if not isinstance(obj, Mapping):
            continue
        for metric, values in obj.items():
            update_counter_map(target, metric, values, alias_map, split_units=split_units)
    return target


def merge_counter_maps(base: dict[str, Counter], extra: Mapping[str, Counter]) -> None:
    for key, counter in extra.items():
        if counter:
            base[key].update(counter)


def extract_units_from_metric_value(value: Any) -> list[str]:
    """
    原始 *_metrics_relations.pkl 中 data['metrics'] 常见结构是：
      {'throughput': 'Mbps'}
    也兼容：
      {'throughput': {'unit': 'Mbps', 'explanation': '...'}}
    """
    if value is None:
        return []
    if isinstance(value, str):
        return flatten_texts(value, split_units=True)
    if isinstance(value, Mapping):
        results: list[str] = []
        for key in UNIT_KEYS:
            if key in value:
                results.extend(flatten_texts(value[key], split_units=True))
        return results
    return []


def extract_explanations_from_metric_value(value: Any) -> list[str]:
    if not isinstance(value, Mapping):
        return []
    results: list[str] = []
    for key in EXPLANATION_KEYS:
        if key in value:
            results.extend(flatten_texts(value[key], split_units=False))
    return results


# =========================
# 核心整理逻辑
# =========================
def build_final_counts(payload: Mapping[str, Any], alias_map: Mapping[str, str]) -> tuple[Counter, Counter, str]:
    """
    返回：
      final_counts: canonical -> 去重后频次
      pre_counter: alias/raw -> 去重前频次
      count_source: 本次采用的计数字段说明
    """
    pre_field, pre_obj = first_existing(payload, PRE_COUNT_FIELDS)
    pre_counter = counter_like_to_counter(pre_obj)

    post_field, post_obj = first_existing(payload, POST_COUNT_FIELDS)
    post_counter = counter_like_to_counter(post_obj)

    final_counts = Counter()
    count_source = ""

    if post_counter:
        # integrated.py 中的 aggregated_counts_post 已经是去重后 canonical 计数；
        # 这里仍再过一遍 alias_map，避免字段结构变化时混入 alias。
        for metric, cnt in post_counter.items():
            can = canonical_of(metric, alias_map)
            if can and cnt > 0:
                final_counts[can] += int(cnt)
        count_source = f"{post_field}（优先使用去重后计数字段，并二次按 alias_to_canonical 合并）"
        return final_counts, pre_counter, count_source

    if pre_counter:
        for alias, cnt in pre_counter.items():
            can = canonical_of(alias, alias_map)
            if can and cnt > 0:
                final_counts[can] += int(cnt)
        count_source = f"{pre_field} + alias_to_canonical（中间 pkl 未找到去重后计数字段，重新汇总）"
        return final_counts, pre_counter, count_source

    # 兜底：如果全量计数缺失，尝试从分场景去重后计数加总。
    scene_field, scene_obj = first_existing(payload, SCENE_POST_COUNT_FIELDS)
    if isinstance(scene_obj, Mapping):
        for _scene, scene_counter_obj in scene_obj.items():
            scene_counter = counter_like_to_counter(scene_counter_obj)
            for metric, cnt in scene_counter.items():
                can = canonical_of(metric, alias_map)
                if can and cnt > 0:
                    final_counts[can] += int(cnt)
        if final_counts:
            count_source = f"{scene_field}（全量字段缺失，改由分场景计数加总）"
            return final_counts, pre_counter, count_source

    count_source = "未找到可解析的计数字段"
    return final_counts, pre_counter, count_source


def collect_variants(payload: Mapping[str, Any], dedup_rules: Mapping[str, Any], alias_map: Mapping[str, str], pre_counter: Counter) -> dict[str, Counter]:
    """整理 canonical -> 原始变体/alias 列表，并尽量带上 alias 原始频次。"""
    variants: dict[str, Counter] = defaultdict(Counter)

    # 1) 由去重前计数恢复：alias -> canonical。
    for alias, cnt in pre_counter.items():
        can = canonical_of(alias, alias_map)
        if can:
            variants[can][alias] += int(cnt)

    # 2) 由 alias_to_canonical 补充可能未出现在 pre_counter 中的 alias。
    for alias, can_raw in alias_map.items():
        can = canonical_of(can_raw, alias_map)
        if can and alias:
            variants[can][alias] += int(pre_counter.get(alias, 0))

    # 3) 由 dedup_rules.groups 补充 alias。
    groups = dedup_rules.get("groups", []) if isinstance(dedup_rules, Mapping) else []
    if isinstance(groups, list):
        for g in groups:
            if not isinstance(g, Mapping):
                continue
            can = canonical_of(g.get("canonical"), alias_map)
            if not can:
                continue
            for alias in flatten_texts(g.get("aliases")):
                a = normalize_name(alias)
                if a:
                    variants[can][a] += int(pre_counter.get(a, 0))
            member_counts = g.get("member_counts")
            if isinstance(member_counts, Mapping):
                for alias, cnt in member_counts.items():
                    a = normalize_name(alias)
                    if a:
                        variants[can][a] += parse_count(cnt)

    # 4) 如果中间 pkl 未来新增了 aggregated_originals 等字段，则优先兼容。
    extra_originals = collect_map_fields(payload, ORIGINAL_VARIANT_FIELDS, alias_map, split_units=False)
    merge_counter_maps(variants, extra_originals)

    return variants


def scan_source_metric_pkls(
    source_dir: Path,
    input_pkl_path: Path,
    alias_map: Mapping[str, str],
    variants: dict[str, Counter],
    units: dict[str, Counter],
    explanations: dict[str, Counter],
) -> tuple[int, int]:
    """
    回扫原始 *_metrics_relations.pkl 文件，补充原始写法、单位、解释。
    返回：(成功扫描文件数, 读取失败文件数)
    """
    if not source_dir.exists() or not source_dir.is_dir():
        return 0, 0

    files = sorted(source_dir.glob("*_metrics_relations.pkl"))

    # 如果没有严格匹配的文件，兜底扫描目录下其它 .pkl，但排除当前中间 pkl。
    if not files:
        files = [p for p in sorted(source_dir.glob("*.pkl")) if p.resolve() != input_pkl_path.resolve()]

    scanned = 0
    failed = 0

    for pkl_file in files:
        try:
            data = load_pickle(pkl_file)
        except Exception as exc:
            failed += 1
            print(f"提示：无法读取原始 pkl：{pkl_file}，原因：{exc}")
            continue

        if not isinstance(data, Mapping):
            continue

        scanned += 1

        # 常见结构：data['metrics'] = {raw_metric: unit}
        metrics_obj = data.get("metrics") or data.get("metric_units") or data.get("units")

        if isinstance(metrics_obj, Mapping):
            for raw_metric, meta in metrics_obj.items():
                can = canonical_of(raw_metric, alias_map)
                if not can:
                    continue
                raw_text = str(raw_metric).strip()
                if raw_text:
                    # 对原始变体保留“原始写法”，比 normalize 后的形式更便于人工检查。
                    variants[can][raw_text] += 1

                for unit in extract_units_from_metric_value(meta):
                    units[can][unit] += 1

                for expl in extract_explanations_from_metric_value(meta):
                    explanations[can][expl] += 1

        elif isinstance(metrics_obj, (list, tuple, set)):
            # 兼容 metrics = [{'metric': 'throughput', 'unit': 'Mbps', 'explanation': '...'}, ...]
            for item in metrics_obj:
                if not isinstance(item, Mapping):
                    continue
                raw_metric = ""
                for nk in NAME_KEYS:
                    if nk in item:
                        raw_metric = str(item[nk]).strip()
                        break
                if not raw_metric:
                    continue
                can = canonical_of(raw_metric, alias_map)
                if not can:
                    continue
                variants[can][raw_metric] += 1
                for uk in UNIT_KEYS:
                    if uk in item:
                        for unit in flatten_texts(item[uk], split_units=True):
                            units[can][unit] += 1
                for ek in EXPLANATION_KEYS:
                    if ek in item:
                        for expl in flatten_texts(item[ek], split_units=False):
                            explanations[can][expl] += 1

        # 常见结构：data['metric_explanations'] = {raw_metric: explanation}
        for exp_field in ("metric_explanations", "explanations", "metric_explanation"):
            exp_obj = data.get(exp_field)
            if isinstance(exp_obj, Mapping):
                for raw_metric, expl in exp_obj.items():
                    can = canonical_of(raw_metric, alias_map)
                    if not can:
                        continue
                    for text in flatten_texts(expl, split_units=False):
                        explanations[can][text] += 1

    return scanned, failed


def build_report_records(
    final_counts: Counter,
    variants: Mapping[str, Counter],
    units: Mapping[str, Counter],
    explanations: Mapping[str, Counter],
) -> list[dict[str, Any]]:
    records: list[dict[str, Any]] = []
    for metric, freq in sorted(final_counts.items(), key=lambda x: (-int(x[1]), x[0])):
        records.append(
            {
                "metric": metric,
                "frequency": int(freq),
                "variants": variants.get(metric, Counter()),
                "units": units.get(metric, Counter()),
                "explanations": explanations.get(metric, Counter()),
            }
        )
    return records


def write_report(
    output_txt: Path,
    input_pkl: Path,
    records: list[dict[str, Any]],
    payload: Mapping[str, Any],
    count_source: str,
    source_scan_info: str,
) -> None:
    actual_file_count = payload.get("actual_file_count", "未知")
    timestamp = payload.get("timestamp", "未知")

    output_txt.parent.mkdir(parents=True, exist_ok=True)
    with output_txt.open("w", encoding="utf-8") as wf:
        wf.write("=" * 100 + "\n")
        wf.write("指标统计整理结果（去重后按出现频次降序）\n")
        wf.write("=" * 100 + "\n")
        wf.write(f"输入文件: {input_pkl}\n")
        wf.write(f"中间数据生成时间: {timestamp}\n")
        wf.write(f"原始论文/文件数量 actual_file_count: {actual_file_count}\n")
        wf.write(f"去重后指标总数: {len(records)}\n")
        wf.write(f"计数字段来源: {count_source}\n")
        wf.write(f"单位/解释补齐来源: {source_scan_info}\n")
        wf.write("说明: 原始变体、单位和解释示例均按收集到的出现次数优先展示；若某字段缺失，会显示“无记录/无单位记录/无解释记录”。\n")
        wf.write("=" * 100 + "\n\n")

        if not records:
            wf.write("未解析到任何指标。请检查 pkl 字段是否包含 aggregated_counts_post、metric_counter_pre 或 scene_aggregated_counts_post。\n")
            return

        for idx, rec in enumerate(records, 1):
            metric = rec["metric"]
            freq = rec["frequency"]
            variants_text = format_counter_items(
                rec["variants"],
                empty="无记录",
                max_items=MAX_VARIANTS_TO_SHOW,
                with_counts=False,
            )
            units_text = format_counter_items(
                rec["units"],
                empty="无单位记录",
                max_items=MAX_UNITS_TO_SHOW,
                with_counts=False,
            )
            example_lines = format_examples(rec["explanations"], max_items=MAX_EXAMPLES_TO_SHOW)

            wf.write(f"{idx:04d}. 指标名称: {metric}\n")
            wf.write(f"      出现频次: {freq}\n")
            wf.write(f"      原始变体: {variants_text}\n")
            wf.write(f"      单位: {units_text}\n")
            wf.write("      解释示例:\n")
            for ex_idx, ex in enumerate(example_lines, 1):
                # 避免解释中有换行破坏报告结构。
                ex_clean = " ".join(str(ex).split())
                wf.write(f"        ({ex_idx}) {ex_clean}\n")
            wf.write("\n")


def export_metric_stats(input_pkl: Path, output_txt: Path | None = None, source_dir: Path | None = None, no_source_scan: bool = False) -> Path:
    input_pkl = input_pkl.expanduser().resolve()
    if not input_pkl.exists():
        raise FileNotFoundError(f"找不到输入文件: {input_pkl}")

    if output_txt is None:
        output_txt = input_pkl.parent / DEFAULT_OUTPUT_TXT
    else:
        output_txt = output_txt.expanduser().resolve()

    payload = load_pickle(input_pkl)
    if not isinstance(payload, Mapping):
        raise TypeError(f"输入 pkl 顶层结构不是 dict/Mapping，而是: {type(payload)!r}")

    dedup_rules = load_dedup_rules_from_payload(payload, input_pkl)
    alias_map = collect_alias_map(payload, dedup_rules)

    final_counts, pre_counter, count_source = build_final_counts(payload, alias_map)

    # 若 alias_map 为空，为所有已知指标补充 self-map，保证 canonical_of 正常工作。
    for metric in list(final_counts.keys()) + list(pre_counter.keys()):
        alias_map.setdefault(metric, metric)

    variants = collect_variants(payload, dedup_rules, alias_map, pre_counter)
    units = collect_map_fields(payload, UNIT_FIELDS, alias_map, split_units=True)
    explanations = collect_map_fields(payload, EXPLANATION_FIELDS, alias_map, split_units=False)

    # 如果中间 pkl 未保存单位/解释，则尝试回扫原始 *_metrics_relations.pkl。
    scanned = failed = 0
    source_scan_info = "未回扫原始 pkl"
    if not no_source_scan:
        if source_dir is None:
            source_dir_value = payload.get("pkl_input_dir") or payload.get("input_dir") or payload.get("source_dir")
            source_dir = Path(str(source_dir_value)) if source_dir_value else None

        if source_dir is not None:
            scanned, failed = scan_source_metric_pkls(
                source_dir.expanduser(),
                input_pkl,
                alias_map,
                variants,
                units,
                explanations,
            )
            if scanned > 0:
                source_scan_info = f"已回扫 {scanned} 个原始 pkl 文件，失败 {failed} 个"
            else:
                source_scan_info = f"未找到可回扫的原始 pkl 目录或文件：{source_dir}"
        else:
            source_scan_info = "中间 pkl 未提供 pkl_input_dir，且未通过 --source-dir 指定原始 pkl 目录"

    # 确保每个最终指标至少有一个自身变体，避免报告为空。
    for metric in final_counts.keys():
        if not variants.get(metric):
            variants[metric][metric] += int(final_counts[metric])

    records = build_report_records(final_counts, variants, units, explanations)
    write_report(output_txt, input_pkl, records, payload, count_source, source_scan_info)
    return output_txt


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="整理并导出 场景_指标统计中间数据.pkl 中的指标统计结果。")
    parser.add_argument("--input", "-i", default=DEFAULT_INPUT_PKL, help="输入 pkl 文件路径，默认为 场景_指标统计中间数据.pkl")
    parser.add_argument("--output", "-o", default=None, help="输出 txt 文件路径；不填则输出到输入 pkl 同目录。")
    parser.add_argument("--source-dir", default=None, help="原始 *_metrics_relations.pkl 所在目录；不填则优先使用 pkl 中的 pkl_input_dir。")
    parser.add_argument("--no-source-scan", action="store_true", help="不回扫原始 pkl，仅使用中间 pkl 内已有字段。")
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    input_pkl = Path(args.input)
    output_txt = Path(args.output) if args.output else None
    source_dir = Path(args.source_dir) if args.source_dir else None

    out_path = export_metric_stats(
        input_pkl=input_pkl,
        output_txt=output_txt,
        source_dir=source_dir,
        no_source_scan=args.no_source_scan,
    )
    print(f"整理完成，结果已保存至: {out_path}")


if __name__ == "__main__":
    main()
