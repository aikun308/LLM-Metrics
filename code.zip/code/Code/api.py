import os
import pickle
import re
import json
import itertools
import time
import hashlib
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from collections import defaultdict, Counter
from langchain_community.document_loaders import PyPDFLoader
from langchain_core.prompts import ChatPromptTemplate
from langchain_core.output_parsers import StrOutputParser
from langchain_openai import ChatOpenAI
import ast
from matplotlib import rcParams
from matplotlib.font_manager import FontProperties, FontManager


# ===================== 全局图像与字体配置（参考示例热力图风格） =====================

plt.rcParams['axes.unicode_minus'] = False
rcParams['figure.dpi'] = 330
rcParams['savefig.dpi'] = 330
plt.rcParams['font.sans-serif'] = ['SimSun', 'Microsoft YaHei', 'SimHei', 'STSong', 'DejaVu Sans']
plt.rcParams['axes.unicode_minus'] = False


def get_tnr_font(size=12):
    """获取 Times New Roman 字体（用于英文/数字）"""
    try:
        return FontProperties(family='Times New Roman', size=size)
    except Exception:
        return FontProperties(family='DejaVu Sans', size=size)


def get_chinese_font(size=12):
    """
    获取中文字体（用于中文文本）：
    尝试在多平台常见中文字体中选择一个可用的。
    """
    chinese_fonts = [
        'SimSun', 'Microsoft YaHei', 'SimHei', 'STSong', 'FangSong', 'KaiTi',
        'Microsoft JhengHei', 'DengXian',
        'Heiti TC', 'Songti SC', 'STHeiti', 'Arial Unicode MS',
        'WenQuanYi Zen Hei', 'WenQuanYi Micro Hei', 'Noto Sans CJK SC',
        'DejaVu Sans'
    ]

    available_fonts = set(f.name for f in FontManager().ttflist)

    for font in chinese_fonts:
        if font in available_fonts:
            try:
                return FontProperties(family=font, size=size)
            except Exception:
                continue

    print("警告：未找到可用中文字体，使用默认字体（可能无法正常显示中文）")
    return FontProperties(size=size)


chinese_font = get_chinese_font()
tnr_font = get_tnr_font()
print(f"当前使用的中文字体：{chinese_font.get_family()}")
print(f"当前使用的英文字体：{tnr_font.get_family()}")


def get_api_key_from_env():
    """从环境变量中读取 DeepSeek API Key。"""
    api_key = os.getenv("DEEPSEEK_API_KEY")
    if not api_key:
        raise EnvironmentError("未检测到环境变量 DEEPSEEK_API_KEY，请先配置后再运行。")
    return api_key


DEEPSEEK_BASE_URL = "https://api.deepseek.com/v1"
LLM_CONFIG = {
    "model": "deepseek-chat",
    "temperature": 0.1,
    "top_p": 0.8,
    "max_tokens": 4096,
    "streaming": False,
}


# ===================== 无关内容过滤工具函数 =====================
def filter_irrelevant_content(text):
    """
    过滤PDF文本中的无关内容：参考文献、图表、公式、页眉页脚、版权声明等
    :param text: 原始PDF文本
    :return: 过滤后的核心文本
    """
    ref_patterns = [
        r"^References$", r"^Bibliography$", r"^Literature Review$",
        r"^References and Notes$", r"^Bibliographic References$",
        r"^参考文[献|章]$", r"^文献综述$", r"^引用文献$"
    ]
    ref_regex = re.compile(r"(" + "|".join(ref_patterns) + r")", re.IGNORECASE | re.MULTILINE)
    ref_match = ref_regex.search(text)
    if ref_match:
        text = text[:ref_match.start()].strip()

    fig_table_patterns = [
        r"Fig(?:ure)?\s*[\dIVX]+\s*[:.-]?\s*.+?(?=\n\n|\n[^a-z]|$)",
        r"Tab(?:le)?\s*[\dIVX]+\s*[:.-]?\s*.+?(?=\n\n|\n[^a-z]|$)",
        r"图\s*[\d一二三四五六七八九十]+\s*[:：.-]?\s*.+?(?=\n\n|\n[^a-z]|$)",
        r"表\s*[\d一二三四五六七八九十]+\s*[:：.-]?\s*.+?(?=\n\n|\n[^a-z]|$)",
        r"See\s+Fig(?:ure)?\s*[\dIVX]+", r"参见图\s*[\d]+",
        r"See\s+Tab(?:le)?\s*[\dIVX]+", r"参见表\s*[\d]+"
    ]
    for pattern in fig_table_patterns:
        text = re.sub(pattern, "", text, flags=re.IGNORECASE | re.DOTALL)

    greek_letters = r"αβγδεζηθικλμνξοπρστυφχψωΑΒΓΔΕΖΗΘΙΚΛΜΝΞΟΠΡΣΤΥΦΧΨΩ"
    text = re.sub(r"^\s*\\begin\{equation\}.*?\\end\{equation\}\s*$", "", text, flags=re.DOTALL | re.MULTILINE)
    text = re.sub(r"^\s*\$[^$\n]{2,}\$\s*$", "", text, flags=re.MULTILINE)
    text = re.sub(
        rf"(?m)^[^{chr(0)}]*[{greek_letters}]{1,}.*?$",
        lambda m: "" if len(m.group(0)) < 60 else m.group(0),
        text
    )

    text = re.sub(r"^\s*\d+\s*$", "", text, flags=re.MULTILINE)
    text = re.sub(r"^\s*[\dIVX]+\s*$", "", text, flags=re.MULTILINE)
    lines = text.split("\n")
    unique_lines = []
    line_count = {}
    for line in lines:
        clean_line = line.strip()
        if len(clean_line) < 5 or len(clean_line) > 50:
            unique_lines.append(line)
            continue
        line_count[clean_line] = line_count.get(clean_line, 0) + 1
        if line_count[clean_line] <= 1:
            unique_lines.append(line)
    text = "\n".join(unique_lines)

    copyright_patterns = [
        r"Copyright\s*©.*?(?=\n\n|$)", r"©\s*\d{4}.*?(?=\n\n|$)",
        r"Published\s*by.*?(?=\n\n|$)", r"Accepted\s*on.*?(?=\n\n|$)",
        r"Submitted\s*on.*?(?=\n\n|$)", r"DOI:\s*10\..*?(?=\s|$)",
        r"会议名称.*?", r"期刊名称.*?", r"ISSN:\s*.*?(?=\s|$)"
    ]
    for pattern in copyright_patterns:
        text = re.sub(pattern, "", text, flags=re.IGNORECASE | re.DOTALL)

    text = re.sub(r"\n+", "\n", text)
    text = re.sub(r"\s+", " ", text)
    return text.strip()


def split_text_by_tokens(text, max_tokens=2500, overlap_ratio=0.05):
    """
    轻量级 token-like 分块：不额外依赖 tokenizer，按非空白片段近似 token。
    """
    token_units = re.findall(r"\S+\s*", text or "")
    if not token_units:
        return []

    overlap = max(1, int(max_tokens * overlap_ratio))
    step = max(1, max_tokens - overlap)

    segments = []
    for start in range(0, len(token_units), step):
        piece = "".join(token_units[start:start + max_tokens]).strip()
        if piece:
            segments.append(piece)
        if start + max_tokens >= len(token_units):
            break
    return segments


def majority_label(labels, default="未分类"):
    clean = [x.strip() for x in labels if isinstance(x, str) and x.strip()]
    if not clean:
        return default
    non_default = [x for x in clean if x != default]
    vote_pool = non_default if non_default else clean
    return Counter(vote_pool).most_common(1)[0][0]


# ===================== 缓存相关配置与工具函数 =====================
def get_cache_key(request_type, input_data, model_params):
    """
    生成唯一缓存Key：请求类型 + 模型参数 + 输入数据哈希
    :param request_type: 请求类型（如"network_type"、"metrics_extract"、"relations_extract"）
    :param input_data: 输入文本
    :param model_params: 模型参数字典
    :return: 唯一缓存Key字符串
    """
    input_hash = hashlib.md5(input_data.encode("utf-8")).hexdigest()
    params_str = json.dumps(model_params, sort_keys=True)
    params_hash = hashlib.md5(params_str.encode("utf-8")).hexdigest()
    return f"{request_type}_{params_hash}_{input_hash}"


def init_cache_dir(output_dir):
    """初始化缓存目录"""
    cache_dir = os.path.join(output_dir, ".api_cache")
    os.makedirs(cache_dir, exist_ok=True)
    return cache_dir


def load_cache(cache_dir):
    """加载缓存文件（若不存在则返回空字典）"""
    cache_path = os.path.join(cache_dir, "api_cache.pkl")
    if os.path.exists(cache_path):
        try:
            with open(cache_path, "rb") as f:
                return pickle.load(f)
        except Exception as e:
            print(f"加载缓存失败，将创建新缓存：{e}")
    return {}


def save_cache(cache_dir, cache_dict):
    """保存缓存字典到文件"""
    cache_path = os.path.join(cache_dir, "api_cache.pkl")
    try:
        with open(cache_path, "wb") as f:
            pickle.dump(cache_dict, f)
        return True
    except Exception as e:
        print(f"保存缓存失败：{e}")
        return False


def clear_cache(cache_dir):
    """清空缓存（可选调用）"""
    cache_path = os.path.join(cache_dir, "api_cache.pkl")
    if os.path.exists(cache_path):
        os.remove(cache_path)
        print("缓存已清空")
    else:
        print("无缓存可清空")


# ===================== JSON 提取与解析（增强鲁棒性） =====================
def find_json_candidates(text):
    """
    在文本中寻找可能的 JSON 子串（匹配平衡的 {} 或 []）。
    返回候选子串列表（按出现顺序）。
    """
    candidates = []
    for open_ch, close_ch in [("{", "}"), ("[", "]")]:
        stack = []
        start = None
        for i, ch in enumerate(text):
            if ch == open_ch:
                if not stack:
                    start = i
                stack.append(ch)
            elif ch == close_ch and stack:
                stack.pop()
                if not stack and start is not None:
                    candidates.append(text[start:i + 1])
                    start = None
    return candidates


def clean_json_like(s):
    """
    对常见的“接近 JSON”的字符串做一些常见修复，返回修复后的字符串。
    """
    if not isinstance(s, str):
        return s
    s2 = s
    s2 = s2.replace("“", '"').replace("”", '"').replace("‘", "'").replace("’", "'")
    s2 = re.sub(r"//.*?$", "", s2, flags=re.MULTILINE)
    s2 = re.sub(r"/\*.*?\*/", "", s2, flags=re.DOTALL)
    s2 = re.sub(r",\s*([\]\}])", r"\1", s2)
    s2 = re.sub(r"\bNone\b", "null", s2)
    s2 = re.sub(r"\bTrue\b", "true", s2)
    s2 = re.sub(r"\bFalse\b", "false", s2)
    s2 = re.sub(r"(?P<prefix>[\{\s,])'(?P<key>[^']+)'\s*:", r'\g<prefix>"\g<key>":', s2)
    s2 = re.sub(r":\s*'([^']*)'", r': "\1"', s2)
    return s2


def parse_json_from_response(text):
    """
    从 LLM 返回的文本中尽可能鲁棒地提取并解析 JSON（dict 或 list）。
    返回 (parsed_object, raw_json_substring) 或 (None, None)。
    """
    if not text or not isinstance(text, str):
        return None, None

    text_stripped = re.sub(r"```(?:json)?\s*", "", text)
    text_stripped = re.sub(r"```", "", text_stripped)
    text_stripped = text_stripped.replace("`", "").strip()

    try:
        parsed = json.loads(text_stripped)
        return parsed, text_stripped
    except Exception:
        pass

    candidates = find_json_candidates(text_stripped)
    unique_candidates = []
    seen = set()
    for c in sorted(candidates, key=len, reverse=True):
        if c not in seen:
            unique_candidates.append(c)
            seen.add(c)

    for cand in unique_candidates:
        try:
            parsed = json.loads(cand)
            return parsed, cand
        except Exception:
            try:
                cand_clean = clean_json_like(cand)
                parsed = json.loads(cand_clean)
                return parsed, cand_clean
            except Exception:
                continue

    for cand in unique_candidates:
        try:
            parsed_py = ast.literal_eval(cand)
            parsed_json_compatible = json.loads(json.dumps(parsed_py))
            return parsed_json_compatible, cand
        except Exception:
            try:
                cand_clean = clean_json_like(cand)
                parsed_py = ast.literal_eval(cand_clean)
                parsed_json_compatible = json.loads(json.dumps(parsed_py))
                return parsed_json_compatible, cand_clean
            except Exception:
                continue

    try:
        text_cleaned = clean_json_like(text_stripped)
        parsed = json.loads(text_cleaned)
        return parsed, text_cleaned
    except Exception:
        pass

    print("警告：无法从 LLM 响应中提取有效 JSON。原始响应前1000字符：")
    print(text[:1000])
    return None, None


# ===================== 核心函数 =====================
def normalize_metric_name(name):
    """
    标准化指标名称：
    1. 转换为小写
    2. 替换特殊字符（将连字符"-"替换为下划线"_"）
    3. 统一命名格式
    """
    name = name.lower().replace(" ", "_").replace("-", "_")

    replacements = {
        "cpu_usage": "cpu_utilization",
        "cpu_occupancy": "cpu_utilization",
        "sdn_controller_cpu_utilization": "cpu_utilization",
        "mem_usage": "memory_consumption",
        "ram_usage": "memory_consumption",
        "memory_usage": "memory_consumption",
        "memory_footprint": "memory_consumption",
        "memory_occupation": "memory_consumption",
        "ram_occupation": "memory_consumption",
        "thr": "throughput",
        "communication_rate": "throughput",
        "link_rate": "throughput",
        "bit_rate": "bitrate",
        "sending_rate": "transmission_rate",
        "transmit_rate": "transmission_rate",
        "tcp_throughput": "throughput",
        "udp_throughput": "throughput",
        "payload_throughput": "throughput",
        "network_throughput": "throughput",
        "tx_throughput": "throughput",
        "rx_throughput": "throughput",
        "throughput_rate": "throughput",
        "flow_throughput": "throughput",
        "packet_error_rate": "packet_error_rate",
        "per": "packet_error_rate",
        "packet_loss": "packet_loss_rate",
        "plr": "packet_loss_rate",
        "packet_loss_percentage": "packet_loss_rate",
        "packet_drop_rate": "packet_loss_rate",
        "frame_error_rate": "frame_error_rate",
        "fer": "frame_error_rate",
        "frame_loss_rate": "frame_error_rate",
        "pdr": "packet_delivery_ratio",
        "packet_delivery_rate": "packet_delivery_ratio",
        "delivery_ratio": "packet_delivery_ratio",
        "frame_delivery_ratio": "frame_delivery_ratio",
        "tcp_rtt": "round_trip_time",
        "rtt_delay": "round_trip_time",
        "base_rtt": "round_trip_time",
        "rtt": "round_trip_time",
        "e2e_delay": "end_to_end_delay",
        "e2e_latency": "end_to_end_delay",
        "end_to_end_latency": "end_to_end_delay",
        "overall_end_to_end_delay": "end_to_end_delay",
        "overall_delay": "end_to_end_delay",
        "overall_latency": "end_to_end_delay",
        "total_delay": "end_to_end_delay",
        "total_latency": "end_to_end_delay",
        "delay": "end_to_end_delay",
        "latency": "end_to_end_delay",
        "one_way_delay": "owd",
        "owd_latency": "owd",
        "computational_delay": "processing_delay",
        "computing_delay": "processing_delay",
        "computational_time": "processing_delay",
        "computing_time": "processing_delay",
        "node_delay": "processing_delay",
        "processing_time": "processing_delay",
        "processing_latency": "processing_delay",
        "edge_processing_delay": "processing_delay",
        "edge_computing_latency": "processing_delay",
        "fog_computing_delay": "processing_delay",
        "queueing_delay": "queuing_delay",
        "queue_delay": "queuing_delay",
        "queue_time": "queuing_delay",
        "queueing_time": "queuing_delay",
        "waiting_delay": "queuing_delay",
        "waiting_time": "queuing_delay",
        "average_waiting_time": "queuing_delay",
        "transmission_latency": "transmission_delay",
        "transmission_time": "transmission_delay",
        "transmit_time": "transmission_delay",
        "transmit_delay": "transmission_delay",
        "transmission_duration": "transmission_delay",
        "propagation_latency": "propagation_delay",
        "propagation_time": "propagation_delay",
        "signal_propagation_time": "propagation_delay",
        "signal_propagation_delay": "propagation_delay",
        "packet_latency": "packet_delay",
        "frame_delay": "packet_delay",
        "packet_delivery_delay": "packet_delay",
        "packet_delivery_latency": "packet_delay",
        "handover_latency": "handover_delay",
        "handover_time": "handover_delay",
        "terrestrial_satellite_handover_delay": "handover_delay",
        "interrupt_latency": "interrupt_delay",
        "interrupt_time": "interrupt_delay",
        "session_establishment_time": "session_setup_time",
        "connection_establishment_time": "connection_setup_time",
        "connection_setup_delay": "connection_setup_time",
        "connection_setup_latency": "connection_setup_time",
        "setup_delay": "connection_setup_time",
        "bearer_establishment_time": "bearer_setup_time",
        "flow_rule_installation_time": "rule_installation_delay",
        "flow_rule_installation_delay": "rule_installation_delay",
        "attack_detection_delay": "attack_detection_delay",
        "failure_recovery_time": "fault_recovery_delay",
        "system_recovery_time": "fault_recovery_delay",
        "recovery_time": "fault_recovery_delay",
        "recovery_delay": "fault_recovery_delay",
        "fault_recovery_time": "fault_recovery_delay",
        "packet_delay_variation": "jitter",
        "pdv": "jitter",
        "latency_jitter": "jitter",
        "delay_jitter": "jitter",
        "jitter_value": "jitter",
        "bw": "bandwidth",
        "system_bandwidth": "bandwidth",
        "link_bandwidth": "bandwidth",
        "network_bandwidth": "bandwidth",
        "channel_bandwidth": "bandwidth",
        "available_bandwidth": "bandwidth",
        "bw_utilization": "bandwidth_utilization",
        "link_utilization": "bandwidth_utilization",
        "signal_to_noise_ratio": "snr",
        "snr_value": "snr",
        "signal_to_interference_plus_noise_ratio": "sinr",
        "signal_to_interference_noise_ratio": "sinr",
        "signal_to_interference_and_noise_ratio": "sinr",
        "interference_level": "interference",
        "interference_power": "interference",
        "co_channel_interference": "interference",
        "adjacent_channel_interference": "interference",
        "noise_level": "noise_power",
        "noise": "noise_power",
        "background_noise": "noise_power",
        "signal_strength": "rssi",
        "rss": "rssi",
        "received_signal_strength": "rssi",
        "received_signal_strength_indicator": "rssi",
        "signal_quality": "snr",
        "aoa": "angle_of_arrival",
        "aod": "angle_of_departure",
        "spectral_efficiency": "spectral_efficiency",
        "spectrum_efficiency": "spectral_efficiency",
        "modulation_efficiency": "spectral_efficiency",
        "channel_efficiency": "spectral_efficiency",
        "resource_utility": "resource_utilization",
        "edge_resource_utilization": "resource_utilization",
        "fog_resource_utilization": "resource_utilization",
        "message_queue_length": "queuing_length",
        "queue_backlog": "queuing_length",
        "queue_size": "queuing_length",
        "queuing_size": "queuing_length",
        "queue_depth": "queuing_length",
        "queuing_depth": "queuing_length",
        "queue_length": "queuing_length",
        "queue_occupancy": "queuing_length",
        "queue_buildup": "queuing_length",
        "power_usage": "power_consumption",
        "energy_usage": "energy_consumption",
        "power_drain": "power_consumption",
        "energy_efficiency": "energy_efficiency",
        "power_efficiency": "energy_efficiency",
        "device_battery_lifetime": "battery_lifetime",
        "battery_duration": "battery_lifetime",
        "transmission_power": "transmit_power",
        "transmit_power_level": "transmit_power",
        "tx_power": "transmit_power",
        "network_traffic": "traffic_volume",
        "traffic_load": "traffic_volume",
        "data_volume": "traffic_volume",
        "traffic_flow": "traffic_volume",
        "signaling_load": "signaling_overhead",
        "communication_cost": "communication_overhead",
        "signaling_overhead_cost": "signaling_overhead",
        "transmission_overhead": "communication_overhead",
        "protocol_overhead": "communication_overhead",
        "diameter": "network_diameter",
        "path_length": "hop_count",
        "hop_distance": "hop_count",
        "number_of_hops": "hop_count",
        "degree": "node_degree",
        "completion_time": "flow_completion_time",
        "fct": "flow_completion_time",
        "flow_duration": "flow_completion_time",
        "flow_table_hit_ratio": "flow_table_hit_rate",
        "flow_table_miss_ratio": "flow_table_miss_rate",
        "flow_throughput": "throughput",
        "tail_fct": "tail_flow_completion_time",
        "intrusion_detection_accuracy": "attack_detection_rate",
        "system_reliability": "reliability",
        "availability": "service_availability_rate",
        "service_availability": "service_availability_rate",
        "availability_rate": "service_availability_rate",
        "mtbf": "mean_time_between_failures",
        "mttr": "mean_time_to_repair",
        "data_transmission_security": "transmission_security",
        "slice_isolation": "slice_isolation_degree",
        "isolation_degree": "slice_isolation_degree",
        "patching_rate": "vulnerability_remediation_rate",
        "aoi": "age_of_information",
        "age_of_information_(aoi)": "age_of_information",
        "device_connectivity": "device_connection_rate",
        "connection_rate": "device_connection_rate",
        "qos": "quality_of_service",
        "qoe": "quality_of_experience",
        "sla": "service_level_agreement",
        "vnf_deployment_time": "vnf_deployment_delay",
        "vnf_instantiation_delay": "vnf_deployment_delay",
        "network_slice_creation_time": "slice_creation_delay",
        "slice_provisioning_delay": "slice_creation_delay",
        "space_air_ground_integration_efficiency": "sagi_efficiency",
        "satellite_link_availability": "satellite_link_availability",
        "quantum_key_distribution_rate": "qkd_rate",
        "distributed_ledger_latency": "blockchain_latency",
        "blockchain_throughput": "throughput",
        "failure_recovery_time": "fault_recovery_delay",
        "cache_hit_ratio": "cache_hit_rate",
        "hit_rate": "cache_hit_rate",
        "hit_ratio": "cache_hit_rate",
        "window_size": "congestion_window",
        "congestion_window_size": "congestion_window",
        "cwnd": "congestion_window",
        "surviving_time": "network_lifetime",
        "average_age_of_information": "age_of_information",
        "peak_age_of_information": "age_of_information",
    }

    for pattern, replacement in replacements.items():
        if pattern in name:
            name = replacement
            break

    return name


# ===================== 相关系数热力图绘制（已按示例风格优化） =====================
def generate_heatmap(metrics, relations, output_path, base_filename):
    """
    生成相关系数热力图并保存（参考示例热力图整体风格：字体、配色、清晰度等）
    """
    sorted_metrics = sorted(metrics.keys())
    metric_index = {metric: idx for idx, metric in enumerate(sorted_metrics)}
    n = len(sorted_metrics)
    correlation_matrix = np.zeros((n, n))
    np.fill_diagonal(correlation_matrix, 1)

    for pair, corr in relations.items():
        try:
            metric1, metric2 = pair.split("-")
            if metric1 in metric_index and metric2 in metric_index:
                i = metric_index[metric1]
                j = metric_index[metric2]
                correlation_matrix[i, j] = corr
                correlation_matrix[j, i] = corr
        except Exception:
            continue

    fig, ax = plt.subplots(figsize=(18, 16))

    sns.heatmap(
        correlation_matrix,
        annot=True,
        fmt=".2f",
        cmap="vlag",
        center=0,
        vmin=-1,
        vmax=1,
        xticklabels=sorted_metrics,
        yticklabels=sorted_metrics,
        ax=ax,
        linewidths=0.5,
        annot_kws={
            "size": 16,
            "family": "Times New Roman"
        },
    )

    plt.xticks(rotation=45, ha="right", fontproperties=get_tnr_font(16))
    plt.yticks(rotation=0, fontproperties=get_tnr_font(16))

    cbar = ax.collections[0].colorbar
    cbar.ax.tick_params(labelsize=16)
    for label in cbar.ax.get_yticklabels():
        label.set_fontproperties(get_tnr_font(16))

    ax.grid(True, linestyle='--', linewidth=0.5, color='gray', alpha=0.3)

    plt.tight_layout()

    heatmap_filename = base_filename + "_heatmap.pdf"
    heatmap_path = os.path.join(output_path, heatmap_filename)
    plt.savefig(heatmap_path, format="pdf", bbox_inches="tight", dpi=330)
    plt.close()

    return heatmap_path


def save_to_text_file(result, txt_path):
    """将结果保存为文本文件"""
    with open(txt_path, 'w', encoding='utf-8') as f:
        f.write("=== 网络场景类型 ===\n")
        f.write(f"● 研究的网络场景: {result['network_type']}\n\n")

        f.write("=== 网络指标及解释 ===\n")
        for metric, unit in result["metrics"].items():
            explanation = result["metric_explanations"].get(metric, "论文中未找到明确定义")
            f.write(f"● {metric} ({unit}): {explanation}\n")

        f.write("\n=== 指标间关系 ===\n")
        relations = result["relations"]
        for pair, correlation in relations.items():
            metric1, metric2 = pair.split("-")
            if correlation < -0.7:
                relation_type = "强负相关"
            elif correlation < -0.3:
                relation_type = "中等负相关"
            elif correlation < 0.3:
                relation_type = "弱相关或无相关"
            elif correlation < 0.7:
                relation_type = "中等正相关"
            else:
                relation_type = "强正相关"
            f.write(f"- {metric1} ↔ {metric2}: {correlation:.2f} ({relation_type})\n")

        f.write("\n● 关系强度说明:\n")
        f.write("  [-1.0 到 -0.7]: 强负相关 (一个指标增加会导致另一个显著减少)\n")
        f.write("  [-0.7 到 -0.3]: 中等负相关\n")
        f.write("  [-0.3 到 0.3]: 弱相关或无相关\n")
        f.write("  [0.3 到 0.7]: 中等正相关\n")
        f.write("  [0.7 到 1.0]: 强正相关 (一个指标增加会导致另一个显著增加)\n")

        if "heatmap_path" in result and result["heatmap_path"]:
            f.write(f"\n● 热力图已保存至: {result['heatmap_path']}\n")


# ===================== 核心处理函数 =====================
def extract_core_network_metrics_and_relations(pdf_path, output_dir):
    """
    提取PDF中网络相关指标、单位、指标解释及指标间关系（API缓存+无关内容过滤）
    合并策略：对于同一指标对，在多个段落出现的相关系数采用简单平均
    """
    if not os.path.isfile(pdf_path):
        return f"错误：PDF文件不存在 - {pdf_path}", ""

    os.makedirs(output_dir, exist_ok=True)

    cache_dir = init_cache_dir(output_dir)
    cache_dict = load_cache(cache_dir)

    try:
        loader = PyPDFLoader(pdf_path)
        pages = loader.load_and_split()
        filtered_pages = []
        for page in pages:
            filtered_text = filter_irrelevant_content(page.page_content)
            if filtered_text:
                filtered_pages.append(filtered_text)
        full_text = "\n".join(filtered_pages)
        print(f"PDF文本过滤完成，原始页数：{len(pages)}，有效过滤后页数：{len(filtered_pages)}")
    except Exception as e:
        return f"PDF加载或过滤错误: {str(e)}", ""

    llm_params = {**LLM_CONFIG, "base_url": DEEPSEEK_BASE_URL}
    llm = ChatOpenAI(
        model=LLM_CONFIG["model"],
        api_key=get_api_key_from_env(),
        base_url=DEEPSEEK_BASE_URL,
        temperature=LLM_CONFIG["temperature"],
        max_tokens=LLM_CONFIG["max_tokens"],
        streaming=LLM_CONFIG["streaming"],
        model_kwargs={"top_p": LLM_CONFIG["top_p"]},
    )

    text_segments = split_text_by_tokens(full_text, max_tokens=2500, overlap_ratio=0.05)
    print(f"过滤后文本长度约 {len(full_text)} 字符，共 {len(text_segments)} 个带重叠 chunk。")

    network_type = "未分类"
    try:
        network_type_prompt = ChatPromptTemplate.from_messages([
            ("system",
             "你是通信网络与计算机网络领域的资深专家，精通各类网络技术及其应用场景。请根据论文完整内容精准判断其研究的核心网络场景类型。"
             "网络场景分类体系（按层级与主导设计约束划分，优先选择能最好描述论文核心实验环境的单一场景名称；输出必须包含编号，例如：“5.1 数据中心网络”）："
             ""
             "- 1.1 互联网与IP网络（研究基于IP协议族的网络基础架构，包括新型体系结构、路由协议、传输优化及跨域互联等）"
             "- 1.2 软件定义网络（核心创新围绕控制转发分离与集中可编程，研究控制器、南/北向接口、流表编排等使能技术）"
             "- 1.3 NFV/虚拟化网络（核心创新围绕网络功能的软硬解耦，研究VNF的部署、编排、弹性伸缩等使能技术）"
             "- 1.4 确定性网络（为核心分组网络提供有界时延/抖动保障的使能技术集，如TSN、DetNet协议与调度）"
             "- 1.5 可重构网络试验设施（支撑网络创新的使能环境，研究试验床架构、资源虚拟化与试验即服务）"
             ""
             "- 2.1 网络切片与多租户管理（核心研究端到端网络切片的创建、隔离、资源编排、管理与优化算法）"
             "- 2.2 多模态/集成网络架构（核心研究在统一设施上承载异构逻辑网络的架构、以及这些逻辑网络间的共存、协调、演化和生成机制）"
             ""
             "- 3.1 蜂窝移动通信网络（含B5G/6G等，研究以蜂窝架构为核心的无线接入、资源管理及移动性管理）"
             "- 3.2 移动自组织网络（研究无固定设施、节点移动、多跳自组织的通用组网问题）"
             "- 3.3 车联网（以车辆为核心节点，研究V2X通信、协同感知与控制）"
             "- 3.4 无人机网络（以无人机为核心节点，研究空中组网、轨迹-通信联合优化）"
             "- 3.5 空天地一体化网络（明确研究天基卫星、空基、地基网络的跨域协同与联合调度）"
             "- 3.6 水下通信网络（研究以水声、激光等为载体的水下专用通信与组网技术）"
             ""
             "- 4.1 无线传感器网络（以环境感知与数据采集为核心，侧重受限节点、多跳传输与网络寿命）"
             "- 4.2 物联网平台与应用（面向智慧家居、智慧城市等消费级场景，侧重异构设备接入、平台与服务）"
             "- 4.3 工业物联网/工业控制网络（面向工业场景，具有严格实时性、可靠性与安全要求的通信与控制）"
             "- 4.4 信息物理系统（网络深度嵌入控制闭环，强调整合感知、计算、通信与控制的系统理论与安全）"
             ""
             "- 5.1 数据中心网络（研究数据中心内部拓扑、流量工程、拥塞控制与性能优化，可能注重AI模型训练和推理服务）"
             "- 5.2 云计算网络（研究跨数据中心互联、云接入网、虚拟网络编排与租户隔离）"
             "- 5.3 边缘计算/雾计算网络（研究计算能力下沉至网络边缘，如基站、网关、含计算能力的无人机、车载单元等，以提供低时延处理）"
             "- 5.4 算力网络（核心研究计算、存储、网络资源在云-边-端的一体化感知、协同调度与服务化，侧重多类资源的全局协同调度与交易机制，而非仅侧重计算下沉的位置与低时延处理）"
             ""
             "- 6.1 卫星通信网络（研究以卫星为核心节点的星间/星地组网、星座管理与资源优化）"
             "- 6.2 内容分发与点对点网络（研究内容缓存、分发策略与覆盖网络优化）"
             "- 6.3 区块链分布式网络（研究共识机制、智能合约等区块链核心功能所依托的P2P网络特性）"
             "- 6.4 绿色与能源感知网络（将能耗或能效作为网络设计的首要核心优化目标与约束）"
             "- 6.5 容迟容断网络（专为长延迟、间歇连接环境设计，研究存储-转发等容忍断连的协议）"
             "- 6.6 光传输与承载网络（研究以光传输、全光交换为核心的大带宽、低时延骨干网技术）"
             "输出要求：只能输出一个分类条目；若无法归类，则输出“未分类”。"),
            ("human", "论文内容：\n{text}\n\n该论文研究的网络场景是：")
        ])

        network_type_chain = network_type_prompt | llm | StrOutputParser()
        scenario_votes = []

        for idx_seg, seg in enumerate(text_segments, 1):
            cache_key = get_cache_key(
                request_type=f"network_type_chunk_{idx_seg}",
                input_data=seg,
                model_params=llm_params
            )
            if cache_key in cache_dict:
                pred = cache_dict[cache_key]
            else:
                pred = network_type_chain.invoke({"text": seg}).strip()
                cache_dict[cache_key] = pred
                save_cache(cache_dir, cache_dict)
                time.sleep(1)
            scenario_votes.append(pred)

        network_type = majority_label(scenario_votes, default="未分类")
    except Exception as e:
        print(f"网络场景类型分析出错: {str(e)}")

    metrics_system_prompt = "你是网络通信领域专家(覆盖有线网络、无线网络、数据中心网络、SDN/NFV、边缘计算、物联网、车联网等全场景)，请从学术论文文本中提取网络(Network)性能指标及其单位和一句话中文解释。" \
                            "此外，重点提取论文文本中以下类别的指标：" \
                            "(1). 通用性能指标(时延(端到端时延/单向时延/往返时延)、吞吐量、带宽、丢包率、时延抖动等)" \
                            "(2). 网络资源指标(带宽利用率、频谱效率等)" \
                            "(3). 传输层指标(拥塞窗口大小、流完成时间等)" \
                            "(4). 网络层指标(跳数、分组交付率、路由开销等)" \
                            "(5). 数据链路层指标(链路利用率、信号强度、信噪比等)" \
                            "(6). 应用层指标(请求成功率、数据处理时延等)" \
                            "(7). 可靠性与安全性指标(故障恢复时间、攻击检测率、数据传输安全性等)" \
                            "指标解释应是论文中对该指标的定义或描述，保持原意。" \
                            "返回格式示例：{{\"end_to_end_delay\": {{\"unit\": \"ms\", \"explanation\": \"数据包从发送端发出到被接收端完整接收所需的总时间\"}}}}"
    metrics_prompt = ChatPromptTemplate.from_messages([
        ("system", metrics_system_prompt),
        ("human", "论文内容：\n{text}\n\n请提取网络指标、单位和解释：")
    ])
    metrics_chain = metrics_prompt | llm | StrOutputParser()

    relations_system_prompt = "你是网络通信领域专家，请分析以下论文文本中网络(Network)指标间的相关性。" \
                              "相关性范围：-1（强负相关）到1（强正相关）。" \
                              "返回JSON格式：{{\"指标对1\": 相关系数, \"指标对2\": 相关系数}}，如{{\"end_to_end_delay-throughput\": -0.8}}"
    relations_prompt = ChatPromptTemplate.from_messages([
        ("system", relations_system_prompt),
        ("human", "网络(Network)指标: {metrics}\n\n论文内容：\n{text}\n\n请分析指标间关系：")
    ])
    relations_chain = relations_prompt | llm | StrOutputParser()

    all_metrics = {}
    all_explanations = {}
    all_relations_sums = defaultdict(float)
    all_relations_counts = defaultdict(int)

    for i, segment in enumerate(text_segments):
        try:
            if not segment.strip():
                print(f"第{i + 1}段文本为空，跳过处理")
                continue

            metrics_cache_key = get_cache_key(
                request_type="metrics_extract",
                input_data=f"{metrics_system_prompt}_{segment}",
                model_params=llm_params
            )
            if metrics_cache_key in cache_dict:
                print(f"命中缓存：指标提取-第{i + 1}段（Key: {metrics_cache_key[:20]}...）")
                metrics_response = cache_dict[metrics_cache_key]
            else:
                print(f"未命中缓存，调用DeepSeek API：指标提取-第{i + 1}段")
                metrics_response = metrics_chain.invoke({"text": segment})
                cache_dict[metrics_cache_key] = metrics_response
                save_cache(cache_dir, cache_dict)
                time.sleep(1)

            parsed_metrics, _ = parse_json_from_response(metrics_response)
            if parsed_metrics:
                try:
                    normalized_metrics = {}
                    segment_explanations = {}

                    for raw_metric, info in parsed_metrics.items():
                        if not isinstance(info, dict):
                            continue
                        unit = info.get("unit", "")
                        explanation = info.get("explanation", "")
                        normalized_name = normalize_metric_name(raw_metric)

                        if unit and isinstance(unit, str):
                            if unit.lower() in ["%", "percent", "percentage"]:
                                unit = "%"
                            elif "bps" in unit.lower():
                                unit = "bps"
                            elif "second" in unit.lower() or "sec" in unit.lower():
                                unit = "s"

                        normalized_metrics[normalized_name] = unit
                        if explanation:
                            segment_explanations[normalized_name] = explanation

                    for metric, unit in normalized_metrics.items():
                        if metric not in all_metrics:
                            all_metrics[metric] = unit
                    for metric, explanation in segment_explanations.items():
                        if metric not in all_explanations and explanation:
                            all_explanations[metric] = explanation

                    if len(normalized_metrics) > 1:
                        metrics_list = list(normalized_metrics.keys())
                        metrics_str = ", ".join(metrics_list)
                        relations_cache_key = get_cache_key(
                            request_type="relations_extract",
                            input_data=f"{relations_system_prompt}_{metrics_str}_{segment}",
                            model_params=llm_params
                        )
                        if relations_cache_key in cache_dict:
                            print(f"命中缓存：关系提取-第{i + 1}段（Key: {relations_cache_key[:20]}...）")
                            relations_response = cache_dict[relations_cache_key]
                        else:
                            print(f"未命中缓存，调用DeepSeek API：关系提取-第{i + 1}段")
                            relations_response = relations_chain.invoke({
                                "metrics": metrics_str,
                                "text": segment
                            })
                            cache_dict[relations_cache_key] = relations_response
                            save_cache(cache_dir, cache_dict)
                            time.sleep(1)

                        parsed_relations, _ = parse_json_from_response(relations_response)
                        if parsed_relations and isinstance(parsed_relations, dict):
                            for pair, correlation in parsed_relations.items():
                                metrics_pair = pair.split("-")
                                if len(metrics_pair) == 2:
                                    norm_metric1 = normalize_metric_name(metrics_pair[0])
                                    norm_metric2 = normalize_metric_name(metrics_pair[1])
                                    sorted_pair = sorted([norm_metric1, norm_metric2])
                                    new_key = f"{sorted_pair[0]}-{sorted_pair[1]}"
                                    try:
                                        correlation = max(min(float(correlation), 1.0), -1.0)
                                    except Exception:
                                        correlation = 0.0
                                    all_relations_sums[new_key] += correlation
                                    all_relations_counts[new_key] += 1
                        else:
                            print(f"第{i + 1}段关系提取：无法解析 LLM 返回的 JSON（段长度 {len(segment)}）")
                except Exception as e:
                    print(f"第 {i + 1} 段解析指标时出错: {str(e)}")
            else:
                print(f"第{i + 1}段指标提取：无法解析 LLM 返回的 JSON（段长度 {len(segment)}）")

        except Exception as e:
            print(f"第 {i + 1} 段处理出错: {str(e)}")

    all_relations = {}
    for pair_key, s in all_relations_sums.items():
        c = all_relations_counts.get(pair_key, 0)
        all_relations[pair_key] = s / c if c > 0 else 0.0

    if all_metrics:
        metrics_keys = list(all_metrics.keys())
        for metric1, metric2 in itertools.combinations(metrics_keys, 2):
            sorted_pair = sorted([metric1, metric2])
            pair_key = f"{sorted_pair[0]}-{sorted_pair[1]}"
            if pair_key not in all_relations:
                all_relations[pair_key] = 0.0

    result = {
        "network_type": network_type,
        "metrics": all_metrics,
        "metric_explanations": all_explanations,
        "relations": all_relations
    }

    base_name = os.path.basename(pdf_path)
    file_base = os.path.splitext(base_name)[0]
    if all_metrics and all_relations:
        try:
            heatmap_path = generate_heatmap(all_metrics, all_relations, output_dir, file_base)
            result["heatmap_path"] = heatmap_path
            print(f"已生成热力图: {heatmap_path}")
        except Exception as e:
            print(f"生成热力图时出错: {str(e)}")
            result["heatmap_path"] = ""
    else:
        result["heatmap_path"] = ""

    pkl_filename = file_base + "_metrics_relations.pkl"
    pkl_path = os.path.join(output_dir, pkl_filename)
    try:
        with open(pkl_path, 'wb') as f:
            pickle.dump(result, f)
        with open(pkl_path, 'rb') as f:
            loaded_data = pickle.load(f)
            if not isinstance(loaded_data, dict) or "metrics" not in loaded_data:
                return "错误：保存的文件格式无效", pkl_path

        txt_filename = file_base + "_results.txt"
        txt_path = os.path.join(output_dir, txt_filename)
        save_to_text_file(result, txt_path)
        print(f"已生成文本文件: {txt_path}")
        return "成功：指标、解释、关系（平均合并）、热力图和文本文件已保存（缓存已启用+无关内容过滤）", pkl_path
    except Exception as e:
        return f"文件保存错误: {str(e)}", ""


def process_directory(input_dir, output_dir):
    """处理目录中的所有PDF文件"""
    os.makedirs(output_dir, exist_ok=True)
    pdf_files = [f for f in os.listdir(input_dir) if f.lower().endswith('.pdf')]

    if not pdf_files:
        print(f"在目录 {input_dir} 中未找到PDF文件")
        return

    print(f"找到 {len(pdf_files)} 个PDF文件，开始处理...（已启用API缓存+无关内容过滤）")
    for i, pdf_file in enumerate(pdf_files):
        pdf_path = os.path.join(input_dir, pdf_file)
        print(f"\n处理文件 [{i + 1}/{len(pdf_files)}]: {pdf_file}")
        status, output_path = extract_core_network_metrics_and_relations(pdf_path, output_dir)
        print(f"状态: {status}")
        if output_path:
            print(f"输出文件: {output_path}")
    print("\n所有文件处理完成！")


# ===================== 主函数 =====================
if __name__ == "__main__":
    print("请选择处理方式:")
    print("1. 处理单个PDF文件")
    print("2. 处理整个目录")
    print("3. 清空API缓存（节省空间时使用）")
    choice = input("请输入选项 (1/2/3): ").strip()

    OUTPUT_DIR = "/12.1/output/output_pkl/all"

    if choice == "1":
        pdf_path = input("请输入PDF文件路径: ").strip()
        status, output_path = extract_core_network_metrics_and_relations(pdf_path, OUTPUT_DIR)
        print("\n执行状态:", status)
        if output_path:
            print("输出文件:", output_path)
    elif choice == "2":
        input_dir = input("请输入包含PDF文件的目录路径: ").strip()
        process_directory(input_dir, OUTPUT_DIR)
    elif choice == "3":
        cache_dir = init_cache_dir(OUTPUT_DIR)
        clear_cache(cache_dir)
    else:
        print("无效选项，请重新运行程序并输入1、2或3")

        # E:\Research_Group\TON_2025\paper_ton\ton_2022\1\2022_paper1.pdf