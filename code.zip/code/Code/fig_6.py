# -*- coding: utf-8 -*-
import os
import re
import math
import multiprocessing
import pickle
import random
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from collections import Counter, defaultdict
from matplotlib import rcParams
from matplotlib.font_manager import FontProperties, FontManager
from matplotlib.lines import Line2D
from matplotlib import patheffects
from sklearn.manifold import TSNE
from sklearn.cluster import KMeans

# ✅用于“内嵌簇图例（可控锚点 + 彩色圆点标题）”
from matplotlib.offsetbox import AnnotationBbox, TextArea, DrawingArea, HPacker, VPacker
from matplotlib.patches import Circle

# ============================================================
# ✅【IEEE/LaTeX 友好】确保 PDF 字体以 TrueType(Type42) 嵌入，避免 Type3
# ============================================================
from matplotlib import font_manager as fm

def _try_register_windows_tnr():
    """Windows 下显式注册 Times New Roman 的 ttf/ttc，降低字体回退概率。"""
    win_font_candidates = [
        r"C:\Windows\Fonts\times.ttf",
        r"C:\Windows\Fonts\timesbd.ttf",
        r"C:\Windows\Fonts\timesi.ttf",
        r"C:\Windows\Fonts\timesbi.ttf",
        r"C:\Windows\Fonts\Times New Roman.ttf",
        r"C:\Windows\Fonts\Times New Roman Bold.ttf",
        r"C:\Windows\Fonts\Times New Roman Italic.ttf",
        r"C:\Windows\Fonts\Times New Roman Bold Italic.ttf",
        r"C:\Windows\Fonts\times.ttc",
        r"C:\Windows\Fonts\Times.ttc",
    ]
    added = 0
    for fp in win_font_candidates:
        if os.path.exists(fp):
            try:
                fm.fontManager.addfont(fp)
                added += 1
            except Exception:
                pass
    return added

_ = _try_register_windows_tnr()

# ============================================================
# 线程/并行设置
# ============================================================
os.environ.setdefault("OMP_NUM_THREADS", "1")
os.environ.setdefault("OPENBLAS_NUM_THREADS", "1")
os.environ.setdefault("MKL_NUM_THREADS", "1")
os.environ.setdefault("NUMEXPR_NUM_THREADS", "1")

try:
    cpu_count = multiprocessing.cpu_count()
except Exception:
    cpu_count = 1
os.environ.setdefault("LOKY_MAX_CPU_COUNT", str(cpu_count))

# -------------------- 可调配置区 --------------------
PKL_INPUT_DIR = "E:/Research_Group/TON_2025/code/12.1/output/output_pkl/all"  # 输入 pkl 目录
PDF_OUTPUT_DIR = "E:/Research_Group/TON_2025/code/12.1/output/fig_6"  # 输出目录

# 高频指标阈值将在加载文件后动态计算：max(1, ceil(actual_file_count * 0.05))

EXCLUDE_METRICS = [
    'bit_error_rate', 'frame_error_rate', 'fault_recovery_delay', 'slice_isolation_degree',
    'transmission_delay', 'processing_delay', 'accuracy', 'false_positive_rate'
]
METRIC_MAPPING = {}

CUSTOM_CORRELATIONS = {
    "end_to_end_delay-end_to_end_delay": 1,
    "packet_error_rate-packet_error_rate": 1,
    "symbol_error_rate-symbol_error_rate": 1,
}

# ============================================================
# ✅绘图前统一生效的“指标显示名映射表”（仅影响显示文本，不改变数据处理/聚类结果）
# ============================================================
DISPLAY_RENAME_MAP = {
    "end_to_end_delay": "End-to-end delay",
    "snr": "Signal-to-noise ratio",
    "round_trip_time": "Round-trip time",
    "age_of_information": "Age of information",
    "rssi": "RSSI",
    "request_success_rate": "Request success rate",
    "congestion_window": "Congestion window",
    "attack_detection_rate": "Attack detection rate",
    "transmission_security": "Transmission security",
    "throughput": "Throughput",
    "bandwidth": "Bandwidth",
    "packet_delivery_ratio": "Packet delivery ratio",
    "spectral_efficiency": "Spectral efficiency",
    "transmission_rate": "Transmission rate",
    "link_capacity": "Link capacity",
    "bandwidth_utilization": "Bandwidth utilization",
    "memory_consumption": "Memory consumption",
    "energy_consumption": "Energy consumption",
    "transmit_power": "Transmit power",
    "traffic_volume": "Traffic volume",
    "node_degree": "Node degree",
    "cpu_utilization": "CPU utilization",
    "resource_utilization": "Resource utilization",
    "routing_overhead": "Routing overhead",
    "communication_overhead": "Communication overhead",
    "time_complexity": "Time complexity",
    "convergence_time": "Convergence time",
    "packet_loss_rate": "Packet loss rate",
    "hop_count": "Hop count",
    "flow_completion_time": "Flow completion time",
    "packet_error_rate": "Packet error rate",
    "queuing_length": "Queuing length",
    "jitter": "Jitter",
    "noise_power": "Noise power",
}

def _normalize_display_text(s: str) -> str:
    """下划线->空格 + 空白折叠为单空格 + 去首尾空白（仅用于显示）。"""
    if s is None:
        return ""
    s = str(s).replace("_", " ")
    s = re.sub(r"\s+", " ", s).strip()
    return s

def metric_display_name(metric_id: str) -> str:
    """内部指标名 -> 绘图显示名（先可选映射，再做下划线替换/空白折叠）。"""
    if metric_id in DISPLAY_RENAME_MAP:
        return _normalize_display_text(DISPLAY_RENAME_MAP[metric_id])
    return _normalize_display_text(metric_id)

# （3）同簇尽可能紧凑：缩小该值（0~1，越小越紧凑）
CLUSTER_COMPACT_FACTOR = 0.30
CLUSTER_REPULSE_ITERS = 160
CLUSTER_REPULSE_MARGIN_SCALE = 0.95
CLUSTER_REPULSE_DAMPING = 0.80
CLUSTER_GLOBAL_SPREAD = 0.90

# ✅全局回收（仅作用于可视化坐标，不改变数据/聚类结果/风格）
GLOBAL_CENTER_SHRINK = 0.90

# 控制簇内主/次方向方差比，避免过于“扁平”的长条形（> 该比值才进行矫正）
MAX_CLUSTER_ASPECT_RATIO = 1.5  # 建议范围 [1.5, 3.0]

# （3）坐标轴刻度更清晰：黑色刻度/边框
AXIS_TICK_COLOR = "black"
AXIS_SPINE_COLOR = "black"
AXIS_SPINE_WIDTH = 1.2
TICK_WIDTH = 1.0
GRID_COLOR = "black"
GRID_ALPHA = 0.15
GRID_LW = 0.6

RANDOM_SEED = 42
np.random.seed(RANDOM_SEED)
random.seed(RANDOM_SEED)

# 尝试应用 seaborn 风格，若不可用退回默认
try:
    sns.set_style('whitegrid')
except Exception:
    plt.style.use('default')

# ============================================================
# ✅【关键】全局 PDF 字体嵌入/字体族设置（必须在绘图前设置）
# ============================================================
plt.rcParams['axes.unicode_minus'] = False

rcParams['pdf.fonttype'] = 42          # ✅ TrueType(Type42) 嵌入，避免 Type3
rcParams['ps.fonttype'] = 42           # ✅ 同步 PS
rcParams['pdf.use14corefonts'] = False # ✅ 不强制使用 14 core fonts
rcParams['font.family'] = 'serif'
rcParams['font.serif'] = [
    'Times New Roman', 'Times',
    'Nimbus Roman No9 L', 'DejaVu Serif'
]
rcParams['font.sans-serif'] = ['DejaVu Sans']
rcParams['mathtext.fontset'] = 'dejavuserif'

rcParams['figure.dpi'] = 330
rcParams['savefig.dpi'] = 330

# -------------------- 字体函数（跨平台） --------------------
def get_tnr_font(size=10):
    try:
        return FontProperties(family='Times New Roman', size=size)
    except Exception:
        return FontProperties(family='DejaVu Serif', size=size)

def get_chinese_font(size=10):
    chinese_fonts = [
        'SimSun', 'Microsoft YaHei', 'SimHei', 'STSong', 'FangSong', 'KaiTi',
        'Microsoft JhengHei', 'DengXian', 'Heiti TC', 'Songti SC', 'STHeiti',
        'Arial Unicode MS', 'WenQuanYi Zen Hei', 'WenQuanYi Micro Hei', 'Noto Sans CJK SC',
        'DejaVu Sans'
    ]
    font_manager = FontManager()
    available = set(f.name for f in font_manager.ttflist)
    for f in chinese_fonts:
        if f in available:
            try:
                return FontProperties(family=f, size=size)
            except Exception:
                continue
    print("警告：未找到可用中文字体，使用系统默认（可能无法正确显示中文）")
    return FontProperties(size=size)

chinese_font = get_chinese_font()
tnr_font = get_tnr_font()
print(f"当前使用的中文字体：{chinese_font.get_family()}")
print(f"当前使用的英文字体：{tnr_font.get_family()}")

os.makedirs(PDF_OUTPUT_DIR, exist_ok=True)
print(f"开始加载 {PKL_INPUT_DIR} 目录下的 pkl 文件...")

# -------------------- 统计容器（仅保留聚类所需） --------------------
metric_counter = Counter()
relation_accumulator = defaultdict(list)  # pair_key -> list of non-zero correlations

# -------------------- 读取 pkl 并汇总（仅保留聚类所需信息） --------------------
pkl_files = [f for f in os.listdir(PKL_INPUT_DIR) if f.endswith("_metrics_relations.pkl")]
actual_file_count = len(pkl_files)
print(f"成功找到 {actual_file_count} 个符合条件的 pkl 文件（后缀：_metrics_relations.pkl）")

for idx, pkl_file in enumerate(sorted(pkl_files), 1):
    pkl_path = os.path.join(PKL_INPUT_DIR, pkl_file)
    try:
        with open(pkl_path, 'rb') as f:
            data = pickle.load(f)
    except Exception as e:
        print(f"加载文件 {pkl_file} 失败：{e}，跳过")
        continue

    # 指标处理：标准化 -> 映射 -> 剔除 -> 统计（仅统计每篇论文去重后的指标集合）
    file_metrics = data.get("metrics", {})
    processed_metrics = set()
    for raw_metric in file_metrics.keys():
        normalized_metric = raw_metric.lower().replace(" ", "_").replace("-", "_")
        mapped_metric = METRIC_MAPPING.get(normalized_metric, normalized_metric)
        if mapped_metric in EXCLUDE_METRICS:
            continue
        processed_metrics.add(mapped_metric)

    metric_counter.update(processed_metrics)

    # 关系处理：拆 pair、映射、剔除、仅收集非零且在[-1,1]内的值
    file_relations = data.get("relations", {})
    for pair_key, corr in file_relations.items():
        if "-" not in pair_key:
            continue
        m1_raw, m2_raw = pair_key.split("-", 1)

        m1 = METRIC_MAPPING.get(
            m1_raw.lower().replace(" ", "_").replace("-", "_"),
            m1_raw.lower().replace(" ", "_").replace("-", "_")
        )
        m2 = METRIC_MAPPING.get(
            m2_raw.lower().replace(" ", "_").replace("-", "_"),
            m2_raw.lower().replace(" ", "_").replace("-", "_")
        )

        if m1 in EXCLUDE_METRICS or m2 in EXCLUDE_METRICS:
            continue

        sorted_pair = sorted([m1, m2])
        mapped_pair_key = f"{sorted_pair[0]}-{sorted_pair[1]}"

        try:
            if isinstance(corr, (int, float)) and -1 <= corr <= 1 and corr != 0:
                relation_accumulator[mapped_pair_key].append(float(corr))
        except Exception:
            continue

    if idx % 50 == 0:
        print(f"已加载 {idx}/{actual_file_count} 个文件...")

print("数据加载与统计完成！")
print(f"共统计到 {len(metric_counter)} 个不同指标")

# -------------------- 高频指标筛选 --------------------
# 高频阈值：至少为 1，同时按实际语料文件数的 5% 向上取整
corpus_freq_threshold = max(1, math.ceil(actual_file_count * 0.05))
high_freq_metrics = [
    metric for metric, freq in metric_counter.most_common()
    if freq >= corpus_freq_threshold
]
if not high_freq_metrics:
    raise ValueError(
        f"无满足条件的高频指标（需出现≥{corpus_freq_threshold}次；"
        f"实际文件数={actual_file_count}，阈值=max(1, ceil(actual_file_count * 0.05))）"
    )
print(
    f"当前语料文件数：{actual_file_count}，"
    f"高频阈值：{corpus_freq_threshold}（max(1, ceil(actual_file_count * 0.05))）"
)
print(f"筛选出 {len(high_freq_metrics)} 个高频指标：{high_freq_metrics}")

# -------------------- 构建平均相关系数矩阵 --------------------
n = len(high_freq_metrics)
avg_corr_matrix = np.eye(n)
metric_index = {metric: i for i, metric in enumerate(high_freq_metrics)}

for pair_key, corr_list in relation_accumulator.items():
    try:
        metric1, metric2 = pair_key.split("-", 1)
    except Exception:
        continue
    if metric1 in metric_index and metric2 in metric_index and len(corr_list) > 0:
        i = metric_index[metric1]
        j = metric_index[metric2]
        avg_corr = float(np.mean(corr_list))
        avg_corr_matrix[i, j] = avg_corr_matrix[j, i] = avg_corr

# 应用自定义覆盖（normalize keys）
norm_custom = {}
for k_, v in CUSTOM_CORRELATIONS.items():
    if "-" in k_:
        a, b = k_.split("-", 1)
        a_n = a.lower().replace(" ", "_").replace("-", "_")
        b_n = b.lower().replace(" ", "_").replace("-", "_")
        norm_key = f"{a_n}-{b_n}"
        norm_custom[norm_key] = float(v)

print("\n应用手动修改的相关系数：")
for custom_pair, custom_corr in norm_custom.items():
    try:
        m1, m2 = custom_pair.split("-", 1)
        if m1 in metric_index and m2 in metric_index:
            i = metric_index[m1]
            j = metric_index[m2]
            avg_corr_matrix[i, j] = avg_corr_matrix[j, i] = custom_corr
            print(f"✅ {custom_pair}: {custom_corr}（已更新）")
        else:
            print(f"❌ {custom_pair}: 指标不在高频列表中，跳过")
    except Exception as e:
        print(f"❌ 处理 {custom_pair} 失败：{e}")

# -------------------- 指标聚类图（KMeans in 原空间 + t-SNE 可视化 + 紧凑化/形状矫正 + 簇间排斥） --------------------
print("开始生成指标聚类图（KMeans in 原空间 + t-SNE 可视化）...")

corr_sub = np.clip(avg_corr_matrix.copy(), -1.0, 1.0)
dist_matrix = (1.0 - corr_sub) / 2.0

if n < 2:
    raise ValueError("指标数量不足以进行聚类（需要至少2个）")

perplexity_candidate = max(5, n // 4)
perplexity = min(30, perplexity_candidate, n - 1)
if perplexity < 1:
    perplexity = 1

# ===== 聚类在“原空间”进行（以距离向量为特征），t-SNE仅用于可视化坐标 =====
X_kmeans = dist_matrix  # shape: (n, n)

k_guess = int(round(np.sqrt(max(2, n))))
k = max(2, min(10, k_guess))
kmeans = KMeans(n_clusters=k, random_state=RANDOM_SEED, n_init=10)
clusters = kmeans.fit_predict(X_kmeans)

# ✅簇索引（用于热力图与散点图）
cluster_indices = {cluster_id: [i for i, c in enumerate(clusters) if c == cluster_id] for cluster_id in range(k)}

# t-SNE：仅用于二维可视化（使用预计算距离矩阵）
tsne = TSNE(
    n_components=2,
    metric='precomputed',
    perplexity=perplexity,
    random_state=RANDOM_SEED,
    init='random'
)
tsne_results = tsne.fit_transform(dist_matrix)

# -------- 簇内点紧凑化（仅作用于可视化坐标） --------
compact_tsne = tsne_results.copy()
for cluster_id in range(k):
    idxs = np.where(clusters == cluster_id)[0]
    if len(idxs) == 0:
        continue
    raw_pts = tsne_results[idxs]
    centroid = raw_pts.mean(axis=0)
    compact_tsne[idxs] = centroid + CLUSTER_COMPACT_FACTOR * (raw_pts - centroid)

# -------- 簇内形状矫正（仅作用于可视化坐标） --------
layout_tsne = compact_tsne.copy()
for cluster_id in range(k):
    idxs = np.where(clusters == cluster_id)[0]
    if len(idxs) < 3:
        continue

    pts = layout_tsne[idxs]
    centroid = pts.mean(axis=0)
    centered = pts - centroid

    try:
        cov = np.cov(centered, rowvar=False)
        if cov.shape != (2, 2):
            continue
        eigvals, eigvecs = np.linalg.eigh(cov)
    except Exception:
        continue

    order = np.argsort(eigvals)[::-1]
    eigvals = eigvals[order]
    eigvecs = eigvecs[:, order]

    if eigvals[1] <= 1e-12:
        continue

    aspect_ratio = np.sqrt(eigvals[0] / eigvals[1])
    if aspect_ratio <= MAX_CLUSTER_ASPECT_RATIO:
        continue

    scale_major = MAX_CLUSTER_ASPECT_RATIO / aspect_ratio
    V = eigvecs
    coords_pca = centered @ V
    coords_pca[:, 0] *= scale_major
    centered_new = coords_pca @ V.T
    layout_tsne[idxs] = centroid + centered_new

# -------- 簇间“排斥”优化（让不同簇更远） --------
def repel_clusters_2d(points_2d, labels, iters=200, margin_scale=1.15, damping=0.92, seed=42):
    rng = np.random.RandomState(seed)
    pts = points_2d.copy()
    uniq = sorted(list(set(labels.tolist() if isinstance(labels, np.ndarray) else list(labels))))
    if len(uniq) <= 1:
        return pts

    for _ in range(iters):
        centroids = {}
        radii = {}
        for c in uniq:
            idxs = np.where(labels == c)[0]
            if len(idxs) == 0:
                centroids[c] = np.zeros(2)
                radii[c] = 0.0
                continue
            c_pts = pts[idxs]
            cen = c_pts.mean(axis=0)
            centroids[c] = cen
            if len(idxs) == 1:
                radii[c] = 0.3
            else:
                radii[c] = float(np.max(np.linalg.norm(c_pts - cen, axis=1)) + 0.15)

        base_margin = np.median(list(radii.values())) * margin_scale + 1e-6

        shifts = {c: np.zeros(2) for c in uniq}
        for i in range(len(uniq)):
            for j in range(i + 1, len(uniq)):
                ci, cj = uniq[i], uniq[j]
                vi = centroids[ci]
                vj = centroids[cj]
                diff = vj - vi
                dist = float(np.linalg.norm(diff))
                if dist < 1e-10:
                    diff = rng.randn(2)
                    dist = float(np.linalg.norm(diff)) + 1e-9
                unit = diff / dist

                min_dist = radii[ci] + radii[cj] + base_margin
                overlap = min_dist - dist
                if overlap > 0:
                    push = 0.5 * overlap * unit
                    shifts[ci] -= push
                    shifts[cj] += push

        mean_shift = np.mean(np.vstack(list(shifts.values())), axis=0)
        for c in uniq:
            shifts[c] = (shifts[c] - mean_shift) * damping

        moved = False
        for c in uniq:
            idxs = np.where(labels == c)[0]
            if len(idxs) == 0:
                continue
            if np.linalg.norm(shifts[c]) > 1e-12:
                pts[idxs] = pts[idxs] + shifts[c]
                moved = True

        if not moved:
            break

    return pts

layout_tsne = repel_clusters_2d(
    layout_tsne, clusters,
    iters=CLUSTER_REPULSE_ITERS,
    margin_scale=CLUSTER_REPULSE_MARGIN_SCALE,
    damping=CLUSTER_REPULSE_DAMPING,
    seed=RANDOM_SEED
)

layout_tsne = layout_tsne * CLUSTER_GLOBAL_SPREAD

# ✅全局回收（仅作用于可视化坐标）
if 0 < GLOBAL_CENTER_SHRINK < 1.0:
    global_center_tmp = layout_tsne.mean(axis=0)
    layout_tsne = global_center_tmp + GLOBAL_CENTER_SHRINK * (layout_tsne - global_center_tmp)

# ============================================================
# ✅簇字母命名规则：按“簇中心在平面上的极角”排序映射为 A/B/C...
# ============================================================
global_center = layout_tsne.mean(axis=0)

cluster_angles = {}
cluster_centroids = {}
for cid in range(k):
    idxs = np.where(clusters == cid)[0]
    if len(idxs) == 0:
        cluster_centroids[cid] = global_center.copy()
        cluster_angles[cid] = 1e18
        continue
    cen = layout_tsne[idxs].mean(axis=0)
    cluster_centroids[cid] = cen
    v = cen - global_center
    ang = float(np.arctan2(v[1], v[0]))
    ang = float((ang + 2.0 * np.pi) % (2.0 * np.pi))
    cluster_angles[cid] = ang

cluster_ranked_ids = sorted(range(k), key=lambda cid: (cluster_angles.get(cid, 1e18), cid))
cluster_rank = {cid: rank for rank, cid in enumerate(cluster_ranked_ids)}
cluster_letter_map = {cid: chr(ord('A') + rank) for cid, rank in cluster_rank.items()}

def cluster_letter(cid: int) -> str:
    return cluster_letter_map.get(int(cid), "?")

print("\n[簇字母命名规则] 已启用：按簇中心极角（相对全局中心）升序映射为 A/B/C...（不改变 KMeans labels 本身）")
for cid in cluster_ranked_ids:
    ang_deg = cluster_angles[cid] * 180.0 / np.pi
    cen = cluster_centroids[cid]
    print(f"  Cluster {cluster_letter(cid)} <= kmeans_id={cid}  angle={ang_deg:.1f}°  centroid=({cen[0]:.3f}, {cen[1]:.3f})")

# ====================================================
# 聚类相关系数热力图（带簇分隔线）：fig_6(b).pdf
# ====================================================
cluster_corr_matrix = np.zeros((k, k))
for i_c in range(k):
    for j_c in range(k):
        if len(cluster_indices[i_c]) == 0 or len(cluster_indices[j_c]) == 0:
            cluster_corr_matrix[i_c, j_c] = 0
            continue
        corr_vals = []
        for idx_i in cluster_indices[i_c]:
            for idx_j in cluster_indices[j_c]:
                corr_vals.append(avg_corr_matrix[idx_i, idx_j])
        cluster_corr_matrix[i_c, j_c] = np.mean(corr_vals)

def sort_clusters_by_similarity(cluster_corr):
    k_clusters = cluster_corr.shape[0]
    if k_clusters <= 1:
        return list(range(k_clusters))
    sorted_clusters = [0]
    remaining = set(range(1, k_clusters))
    while remaining:
        last_cluster = sorted_clusters[-1]
        max_corr = -np.inf
        next_cluster = None
        for c in remaining:
            current_corr = cluster_corr[last_cluster, c]
            if current_corr > max_corr:
                max_corr = current_corr
                next_cluster = c
        sorted_clusters.append(next_cluster)
        remaining.remove(next_cluster)
    return sorted_clusters

sorted_cluster_ids = sort_clusters_by_similarity(cluster_corr_matrix)
print(f"\n优化后的簇排序：{sorted_cluster_ids}（基于簇间相关系数，仅用于热力图矩阵重排）")

order_by_cluster = []
for cluster_id in sorted_cluster_ids:
    idxs = cluster_indices[cluster_id]
    idxs_sorted = sorted(
        idxs,
        key=lambda i: (-metric_counter[high_freq_metrics[i]], high_freq_metrics[i])
    )
    order_by_cluster.extend(idxs_sorted)

all_ordered = list(dict.fromkeys(order_by_cluster))
missing = [i for i in range(n) if i not in all_ordered]
if missing:
    all_ordered.extend(missing)

sorted_corr_matrix = avg_corr_matrix[np.ix_(all_ordered, all_ordered)]
sorted_axis_labels = [
    f"{metric_display_name(high_freq_metrics[i])}({metric_counter[high_freq_metrics[i]]})"
    for i in all_ordered
]

cluster_bounds = []
current_pos = 0
for cluster_id in sorted_cluster_ids:
    cluster_size = len(cluster_indices[cluster_id])
    if cluster_size == 0:
        continue
    start = current_pos
    end = current_pos + cluster_size - 1
    cluster_bounds.append((cluster_id, start, end))
    current_pos = end + 1

print("生成带簇分隔线的聚类相关系数热力图（fig_6(b).pdf）...")

# ====================================================
# 聚类相关系数热力图（带簇分隔线）：fig_6(b).pdf
# ====================================================

# ✅ 34×34 热力图字体与布局优化参数
HEATMAP_FIGSIZE = (16, 16)        # 原 16×16，适当放大，避免 34×34 注释重叠
HEATMAP_DPI = 420                 # 提高清晰度
HEATMAP_ANNOT_SIZE = 13           # 单元格内部数值字号；34×34 下不宜过大
HEATMAP_TICK_SIZE = 20            # 横纵轴标签字号
HEATMAP_CBAR_TICK_SIZE = 16       # 色条刻度字号
HEATMAP_CLUSTER_LABEL_SIZE = 16   # 顶部 Cluster 标签字号
HEATMAP_CELL_LINEWIDTH = 0.35     # 单元格线条略细，减少视觉拥挤
HEATMAP_BOUNDARY_LW = 2.2         # 簇分隔线略加粗
HEATMAP_GRID_LW = 0.35

fig = plt.figure(figsize=HEATMAP_FIGSIZE, dpi=HEATMAP_DPI)

# ✅ 给主图更多空间，色条略宽，间距适中
gs = fig.add_gridspec(
    nrows=1,
    ncols=2,
    width_ratios=[36, 1.2],
    wspace=0.06
)

ax = fig.add_subplot(gs[0, 0])
cax = fig.add_subplot(gs[0, 1])

sns.heatmap(
    sorted_corr_matrix,
    annot=True,
    fmt=".2f",
    cmap="vlag",
    center=0,
    vmin=-1,
    vmax=1,
    xticklabels=sorted_axis_labels,
    yticklabels=sorted_axis_labels,
    ax=ax,
    cbar=True,
    cbar_ax=cax,
    linewidths=HEATMAP_CELL_LINEWIDTH,
    linecolor="white",
    square=True,
    annot_kws={
        "size": HEATMAP_ANNOT_SIZE,
        "fontproperties": get_tnr_font(HEATMAP_ANNOT_SIZE),
        "ha": "center",
        "va": "center"
    },
    cbar_kws={
        "ticks": np.linspace(-1, 1, 9)
    }
)

# ✅ 簇分隔线
for (_, _, end) in cluster_bounds[:-1]:
    ax.axvline(x=end + 1, color='black', linewidth=HEATMAP_BOUNDARY_LW, linestyle='-')
    ax.axhline(y=end + 1, color='black', linewidth=HEATMAP_BOUNDARY_LW, linestyle='-')

# ✅ 顶部 Cluster 标签
for (cid, start, end) in cluster_bounds:
    mid = (start + end) / 2.0 + 0.5
    label = f"Cluster {cluster_letter(cid)}"
    ax.text(
        mid, 1.012, label,
        transform=ax.get_xaxis_transform(),
        ha="center",
        va="bottom",
        fontproperties=get_tnr_font(HEATMAP_CLUSTER_LABEL_SIZE),
        fontsize=HEATMAP_CLUSTER_LABEL_SIZE,
        fontweight="bold",
        color="black",
        clip_on=False
    )

# ✅ 横纵轴标签：增大字号，同时优化旋转角度和对齐方式
plt.setp(
    ax.get_xticklabels(),
    rotation=45,
    ha="right",
    rotation_mode="anchor",
    fontproperties=get_tnr_font(HEATMAP_TICK_SIZE),
    fontsize=HEATMAP_TICK_SIZE
)

plt.setp(
    ax.get_yticklabels(),
    rotation=0,
    ha="right",
    fontproperties=get_tnr_font(HEATMAP_TICK_SIZE),
    fontsize=HEATMAP_TICK_SIZE
)

# ✅ 坐标轴刻度样式
ax.tick_params(
    axis="x",
    which="major",
    labelsize=HEATMAP_TICK_SIZE,
    pad=8,
    length=3,
    width=0.8,
    colors="black"
)

ax.tick_params(
    axis="y",
    which="major",
    labelsize=HEATMAP_TICK_SIZE,
    pad=6,
    length=3,
    width=0.8,
    colors="black"
)

# ✅ 色条刻度字号与字体
cax.tick_params(
    labelsize=HEATMAP_CBAR_TICK_SIZE,
    width=0.8,
    length=3,
    colors="black"
)

for label in cax.get_yticklabels():
    label.set_fontproperties(get_tnr_font(HEATMAP_CBAR_TICK_SIZE))
    label.set_fontsize(HEATMAP_CBAR_TICK_SIZE)

# ✅ 色条边框更清晰
for spine in cax.spines.values():
    spine.set_visible(True)
    spine.set_linewidth(0.8)
    spine.set_color("black")

# ✅ 轻微网格线，避免压过单元格数字
ax.grid(
    True,
    linestyle='--',
    linewidth=HEATMAP_GRID_LW,
    color='gray',
    alpha=0.22
)

# ✅ 外边框增强
for spine in ax.spines.values():
    spine.set_visible(True)
    spine.set_linewidth(1.0)
    spine.set_color("black")

# ✅ 给长标签和顶部 Cluster 标签留空间
fig.tight_layout(rect=[0.02, 0.04, 0.98, 0.965])

cluster_heatmap2_path = os.path.join(PDF_OUTPUT_DIR, "fig_6(b).pdf")
plt.savefig(
    cluster_heatmap2_path,
    format="pdf",
    bbox_inches="tight",
    dpi=HEATMAP_DPI,
    pad_inches=0.18
)
plt.close()

print(f"带簇分隔线的聚类相关系数热力图已保存：{cluster_heatmap2_path}")
print(f"带簇分隔线的聚类相关系数热力图已保存：{cluster_heatmap2_path}")

# =========================
# 指标聚类散点图：✅按簇“可控锚点”的图内嵌图例（列出簇内全部指标）
# =========================
cmap = plt.get_cmap('tab10')
cluster_colors = [cmap(i % 10) for i in range(k)]

fig, ax = plt.subplots(figsize=(6, 6))
scatter_sizes = 100
POINT_LABEL_FONTSIZE = 8
POINT_LABEL_STROKE_LW = 1.5

# ==========================================================
# ✅【新增】指标聚类图：图例字号整体增大（你本次需求）
#   - 右上角 Clusters 小图例
#   - 各簇 panel 图例（标题+正文）
# ==========================================================
CLUSTERS_LEGEND_FONTSIZE = 11
CLUSTERS_LEGEND_TITLE_SIZE = 12
CLUSTERS_LEGEND_MARKERSIZE = 9

CLUSTER_PANEL_FONTSIZE = 10
CLUSTER_PANEL_TITLE_SIZE = 11
CLUSTER_PANEL_DOT_RADIUS = 3.6
CLUSTER_PANEL_LINE_SEP = 5
CLUSTER_PANEL_COL_SEP = 14

# ✅把数字转为 Unicode 下角标（多位数也支持，例如 12 -> ₁₂）
_SUBSCRIPT_MAP = str.maketrans({
    "0": "₀", "1": "₁", "2": "₂", "3": "₃", "4": "₄",
    "5": "₅", "6": "₆", "7": "₇", "8": "₈", "9": "₉"
})
def to_subscript(num: int) -> str:
    return str(num).translate(_SUBSCRIPT_MAP)

# ========= 给“同一簇”内的指标编号（A₁, A₂, ...），并用于点内标号 =========
num_in_cluster = {}
tag_in_cluster = {}
cluster_sorted_member_indices = {}
for cluster_id in range(k):
    idxs = cluster_indices.get(cluster_id, [])
    idxs_sorted_for_number = sorted(
        idxs,
        key=lambda i: (-metric_counter[high_freq_metrics[i]], high_freq_metrics[i])
    )
    cluster_sorted_member_indices[cluster_id] = idxs_sorted_for_number

    prefix = cluster_letter(cluster_id)
    for rank_i, i_idx in enumerate(idxs_sorted_for_number, start=1):
        num_in_cluster[i_idx] = rank_i
        tag_in_cluster[i_idx] = f"{prefix}{to_subscript(rank_i)}"

# --------- 绘制散点 ---------
for cluster_id in cluster_ranked_ids:
    idxs = np.where(clusters == cluster_id)[0]
    if len(idxs) == 0:
        continue
    pts = layout_tsne[idxs]
    base_color = cluster_colors[cluster_id]
    ax.scatter(
        pts[:, 0], pts[:, 1],
        s=scatter_sizes,
        color=base_color,
        edgecolors='k',
        linewidths=0.4,
        zorder=3
    )

# --------- 点内标号：A₁ / B₂ / ... ---------
for i_idx, _metric in enumerate(high_freq_metrics):
    x_coord, y_coord = layout_tsne[i_idx]
    tag = tag_in_cluster.get(i_idx, None)
    if tag is None:
        continue
    t = ax.text(
        x_coord, y_coord,
        f"{tag}",
        ha="center", va="center",
        fontsize=POINT_LABEL_FONTSIZE,
        fontproperties=get_tnr_font(POINT_LABEL_FONTSIZE),
        color="white",
        zorder=4
    )
    t.set_path_effects([patheffects.withStroke(linewidth=POINT_LABEL_STROKE_LW, foreground="black")])

# ===========================
# 绘图区为严格正方形 + 等比例坐标显示
# ===========================
ax.set_aspect('equal', adjustable='box')
if hasattr(ax, "set_box_aspect"):
    ax.set_box_aspect(1)

ax.tick_params(axis='both', which='both', colors=AXIS_TICK_COLOR, width=TICK_WIDTH, labelsize=11)
for tick_label in ax.get_xticklabels() + ax.get_yticklabels():
    tick_label.set_fontproperties(get_tnr_font(11))
    tick_label.set_color(AXIS_TICK_COLOR)

for spine in ax.spines.values():
    spine.set_color(AXIS_SPINE_COLOR)
    spine.set_linewidth(AXIS_SPINE_WIDTH)

ax.grid(True, linestyle='--', linewidth=GRID_LW, color=GRID_COLOR, alpha=GRID_ALPHA)

# ==========================================================
# ✅Clusters 图例（右上角，小图例仅表示簇颜色）——字号增大
# ==========================================================
cluster_handles = []
cluster_labels = []
for cluster_id in cluster_ranked_ids:
    cluster_handles.append(
        Line2D(
            [0], [0],
            marker='o',
            linestyle='',
            markersize=CLUSTERS_LEGEND_MARKERSIZE,
            markerfacecolor=cluster_colors[cluster_id],
            markeredgecolor='k',
            markeredgewidth=0.4
        )
    )
    cluster_labels.append(f"Cluster {cluster_letter(cluster_id)}")

cluster_legend = ax.legend(
    handles=cluster_handles,
    labels=cluster_labels,
    loc="upper right",
    bbox_to_anchor=(0.99, 0.99),
    borderaxespad=0.0,
    frameon=True,
    fontsize=CLUSTERS_LEGEND_FONTSIZE,
    title="Clusters"
)
cluster_legend.get_title().set_fontproperties(get_tnr_font(CLUSTERS_LEGEND_TITLE_SIZE))
cluster_legend.get_title().set_fontsize(CLUSTERS_LEGEND_TITLE_SIZE)
cluster_legend.get_title().set_weight("bold")
for txt in cluster_legend.get_texts():
    txt.set_fontproperties(get_tnr_font(CLUSTERS_LEGEND_FONTSIZE))
    txt.set_fontsize(CLUSTERS_LEGEND_FONTSIZE)
ax.add_artist(cluster_legend)

# ==========================================================
# ✅按簇“可控锚点”的内嵌图例：每簇一个 panel，列出该簇内全部指标（字号增大）
# ==========================================================

# -------------------- 你只需改这里：每个簇的图例锚点（axes fraction） --------------------
CLUSTER_LEGEND_ANCHORS = {
    "A": (0.75, 0.90),
    "B": (0.21, 0.94),
    "C": (0.02, 0.67),
    "D": (0.08, 0.17),
    "E": (0.39, 0.035),
    "F": (0.98, 0.16),
}

# panel 样式
CLUSTER_PANEL_ALPHA = 0.96
CLUSTER_PANEL_EDGE_LW = 0.8

# 为避免“超长列表”占满高度：超过该行数自动分两列（仍是同一 panel）
MAX_LINES_PER_COLUMN = 22

# 避让策略：最小幅度“微调”锚点
ANCHOR_NUDGE_STEP = 0.018
ANCHOR_NUDGE_LEVELS = 9   # ✅字号增大后，适当提高搜索层数以更稳
PANEL_POINT_PAD_PX = 12   # ✅略增，降低大 panel 遮挡点概率
PANEL_PANEL_PAD_PX = 8    # ✅略增，降低 panel 互相重叠

def _auto_fallback_anchor(letter: str, cid: int):
    cen = cluster_centroids.get(cid, global_center)
    cen_axes = ax.transAxes.inverted().transform(ax.transData.transform(np.array(cen)))
    x, y = float(cen_axes[0]), float(cen_axes[1])
    ax_x = 0.97 if x < 0.5 else 0.03
    ax_y = 0.03 if y > 0.5 else 0.97
    return (ax_x, ax_y)

def _panel_alignment_from_anchor(xy):
    x, y = xy
    ha = "right" if x > 0.5 else "left"
    va = "bottom" if y < 0.5 else "top"
    box_alignment = (1.0 if ha == "right" else 0.0, 0.0 if va == "bottom" else 1.0)
    return ha, va, box_alignment

def _make_cluster_panel(letter: str, cid: int, color_rgba, idxs_sorted):
    """生成一个可放入 AnnotationBbox 的 offsetbox（标题+列表），字号增大版。"""
    # header：彩色圆点 + 标题
    dot_da = DrawingArea(10, 10, 0, 0)
    dot = Circle((5, 5), radius=CLUSTER_PANEL_DOT_RADIUS, facecolor=color_rgba, edgecolor="black", linewidth=0.4)
    dot_da.add_artist(dot)

    header_text = TextArea(
        f"Cluster {letter}",
        textprops=dict(
            fontproperties=get_tnr_font(CLUSTER_PANEL_TITLE_SIZE),
            fontsize=CLUSTER_PANEL_TITLE_SIZE,
            color="black",
            weight="bold"
        )
    )
    header = HPacker(children=[dot_da, header_text], align="center", pad=0, sep=4)

    # lines：列出该簇内全部指标
    lines = []
    for i_idx in idxs_sorted:
        tag = tag_in_cluster.get(i_idx, "")
        name = metric_display_name(high_freq_metrics[i_idx])
        lines.append(f"{tag}: {name}")

    if not lines:
        lines = ["(empty)"]

    # 单列
    if len(lines) <= MAX_LINES_PER_COLUMN:
        body = TextArea(
            "\n".join(lines),
            textprops=dict(
                fontproperties=get_tnr_font(CLUSTER_PANEL_FONTSIZE),
                fontsize=CLUSTER_PANEL_FONTSIZE,
                color="black"
            )
        )
        vbox = VPacker(children=[header, body], align="left", pad=0, sep=CLUSTER_PANEL_LINE_SEP)
        return vbox

    # 多列（最多 3 列兜底）
    ncol = int(np.ceil(len(lines) / MAX_LINES_PER_COLUMN))
    ncol = max(2, min(3, ncol))
    cols = []
    chunk = int(np.ceil(len(lines) / ncol))
    for c in range(ncol):
        part = lines[c*chunk:(c+1)*chunk]
        if not part:
            continue
        cols.append(
            TextArea(
                "\n".join(part),
                textprops=dict(
                    fontproperties=get_tnr_font(CLUSTER_PANEL_FONTSIZE),
                    fontsize=CLUSTER_PANEL_FONTSIZE,
                    color="black"
                )
            )
        )
    body = HPacker(children=cols, align="top", pad=0, sep=CLUSTER_PANEL_COL_SEP)
    vbox = VPacker(children=[header, body], align="left", pad=0, sep=CLUSTER_PANEL_LINE_SEP)
    return vbox

def _bbox_overlaps_points(bbox_disp, points_disp, pad_px=0):
    if bbox_disp is None:
        return False
    x0, y0, x1, y1 = bbox_disp.x0 - pad_px, bbox_disp.y0 - pad_px, bbox_disp.x1 + pad_px, bbox_disp.y1 + pad_px
    xs = points_disp[:, 0]
    ys = points_disp[:, 1]
    inside = (xs >= x0) & (xs <= x1) & (ys >= y0) & (ys <= y1)
    return bool(np.any(inside))

def _bbox_overlaps_bbox(b1, b2, pad_px=0):
    if b1 is None or b2 is None:
        return False
    x0 = max(b1.x0 - pad_px, b2.x0 - pad_px)
    y0 = max(b1.y0 - pad_px, b2.y0 - pad_px)
    x1 = min(b1.x1 + pad_px, b2.x1 + pad_px)
    y1 = min(b1.y1 + pad_px, b2.y1 + pad_px)
    return (x1 > x0) and (y1 > y0)

def _spiral_offsets(step, levels):
    offsets = [(0.0, 0.0)]
    for lv in range(1, levels + 1):
        d = step * lv
        candidates = [
            ( d, 0), (-d, 0), (0,  d), (0, -d),
            ( d,  d), ( d, -d), (-d,  d), (-d, -d),
            (2*d, 0), (-2*d, 0), (0, 2*d), (0, -2*d),
        ]
        offsets.extend(candidates)
    return offsets

# 预计算点的 display 坐标（用于 panel 遮挡检测）
points_disp = ax.transData.transform(layout_tsne)

# 近似点的像素“外接半径”（仅用于遮挡检测 padding）
approx_r_pt = float(np.sqrt(max(1.0, scatter_sizes))) * 0.60
approx_r_px = approx_r_pt * float(fig.dpi) / 72.0
point_pad_px = int(PANEL_POINT_PAD_PX + approx_r_px)

# 创建并放置每个簇的 panel
cluster_panels = []  # (letter, cid, ab)
for cid in cluster_ranked_ids:
    letter = cluster_letter(cid)
    color = cluster_colors[cid]
    idxs_sorted = cluster_sorted_member_indices.get(cid, [])

    anchor = CLUSTER_LEGEND_ANCHORS.get(letter, None)
    if anchor is None:
        anchor = _auto_fallback_anchor(letter, cid)

    _, _, box_alignment = _panel_alignment_from_anchor(anchor)
    panel_box = _make_cluster_panel(letter, cid, color, idxs_sorted)

    ab = AnnotationBbox(
        panel_box,
        xy=anchor,
        xycoords="axes fraction",
        box_alignment=box_alignment,
        frameon=True,
        bboxprops=dict(
            boxstyle="round,pad=0.30",   # ✅大字体：略增内边距
            facecolor="white",
            edgecolor="black",
            linewidth=CLUSTER_PANEL_EDGE_LW,
            alpha=CLUSTER_PANEL_ALPHA
        ),
        zorder=7,
        pad=0.25                       # ✅略增
    )
    ax.add_artist(ab)
    cluster_panels.append((letter, cid, ab))

# --------- 微调：尽量避免 panel 遮挡散点或 panel 之间重叠 ---------
fig.canvas.draw()
renderer = fig.canvas.get_renderer()
offsets = _spiral_offsets(ANCHOR_NUDGE_STEP, ANCHOR_NUDGE_LEVELS)

cluster_panels_sorted = sorted(cluster_panels, key=lambda x: x[0])
placed_bboxes = []

for letter, cid, ab in cluster_panels_sorted:
    base_anchor = ab.xy
    best_anchor = base_anchor
    best_bbox = None

    for dx, dy in offsets:
        cand = (float(base_anchor[0] + dx), float(base_anchor[1] + dy))
        cand = (min(max(cand[0], 0.02), 0.98), min(max(cand[1], 0.02), 0.98))

        ab.xy = cand
        fig.canvas.draw()
        bbox = ab.get_window_extent(renderer=renderer)

        if _bbox_overlaps_points(bbox, points_disp, pad_px=point_pad_px):
            continue

        conflict = False
        for pb in placed_bboxes:
            if _bbox_overlaps_bbox(bbox, pb, pad_px=PANEL_PANEL_PAD_PX):
                conflict = True
                break
        if conflict:
            continue

        best_anchor = cand
        best_bbox = bbox
        break

    ab.xy = best_anchor
    fig.canvas.draw()
    final_bbox = best_bbox if best_bbox is not None else ab.get_window_extent(renderer=renderer)
    placed_bboxes.append(final_bbox)

plt.tight_layout()

cluster_plot_path = os.path.join(PDF_OUTPUT_DIR, "fig_6(a).pdf")
plt.savefig(cluster_plot_path, format="pdf", bbox_inches="tight", dpi=330)
plt.close()
print(f"指标聚类图已保存：{cluster_plot_path}")

print("\n生成完成！输出目录：", PDF_OUTPUT_DIR)
print("生成文件清单：")
print(f"1. fig_6(a).pdf -> {cluster_plot_path}")
print(f"2. fig_6(b).pdf -> {cluster_heatmap2_path}")