# Metric Deduplication Prompt

## Role

You are an expert in network communications and terminology normalization.

## Task

Given a list of metrics with occurrence counts and one-sentence explanations, group semantically equivalent metrics and select one canonical name for each group.

## Input

The input is a list of network metrics to be deduplicated. Each line follows this format:

```text
- metric_name (count): explanation
```

Where:

- `metric_name` is the metric name.
- `count` is the number of files or occurrences in which the metric appears.
- `explanation` is a one-sentence explanation of the metric.

Full input template:

```text
Please group and normalize the following metric list. The response must be JSON:

{candidates}
```

## Output

Return strict JSON in the following format:

```json
{
  "groups": [
    {
      "canonical": "end_to_end_delay",
      "aliases": ["e2e_delay", "end_to_end_delay"],
      "member_counts": {
        "e2e_delay": 1,
        "end_to_end_delay": 3
      },
      "total_count": 4
    }
  ],
  "alias_to_canonical": {
    "e2e_delay": "end_to_end_delay"
  }
}
```

## Rules

- Group semantically equivalent metrics together.
- Choose one canonical name, `canonical`, for each group.
- `canonical` should use underscore-style naming.
- `aliases` should list the equivalent metric names in the group.
- `member_counts` should preserve the occurrence count of each metric in the group.
- `total_count` should represent the total occurrence count of the group.
- `alias_to_canonical` should provide the mapping from each alias to its canonical name.

## Constraints

Return only JSON and do not add any extra comments.
