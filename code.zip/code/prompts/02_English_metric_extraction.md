# Metric Extraction Prompt

## Role

You are an expert in network communications, covering wired networks, wireless networks, data center networks, SDN/NFV, edge computing, IoT, Internet of Vehicles, and related scenarios.

## Task

Extract network performance metrics, their units, and a one-sentence explanation from academic paper text.

## Input

```text
Paper content:
{text}

Please extract network metrics, units, and explanations:
```

## Output

Return JSON. Each metric should use a normalized metric name as the key, and the value should contain the fields `unit` and `explanation`.

```json
{
  "end_to_end_delay": {
    "unit": "ms",
    "explanation": "The total time required for a packet to travel from the sender to the receiver and be fully received."
  }
}
```

## Rules

Focus on extracting metrics in the following categories from the paper text:

1. **General performance metrics**: delay (end-to-end delay / one-way delay / round-trip delay), throughput, bandwidth, packet loss rate, jitter, etc.
2. **Network resource metrics**: bandwidth utilization, spectral efficiency, etc.
3. **Transport-layer metrics**: congestion window size, flow completion time, etc.
4. **Network-layer metrics**: hop count, packet delivery ratio, routing overhead, etc.
5. **Data-link-layer metrics**: link utilization, signal strength, signal-to-noise ratio, etc.
6. **Application-layer metrics**: request success rate, data processing delay, etc.
7. **Reliability and security metrics**: failure recovery time, attack detection rate, data transmission security, etc.

## Constraints

The explanation of each metric should reflect the definition or description given in the paper and preserve the original meaning.
