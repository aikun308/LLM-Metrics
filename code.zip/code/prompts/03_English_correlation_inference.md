# Correlation Inference Prompt

## Role

You are an expert in network communications.

## Task

Analyze the correlations among network metrics in the paper text.

## Input

```text
Network metrics: {metrics}

Paper content:
{text}

Please analyze the relationships among the metrics:
```

## Output

Return JSON. Each key should be a metric pair in the format `metric_1-metric_2`; each value should be the correlation coefficient.

```json
{
  "end_to_end_delay-throughput": -0.8
}
```

## Rules

The correlation coefficient must be in the range `-1` to `1`:

- `-1` indicates a strong negative correlation.
- `1` indicates a strong positive correlation.

## Constraints

Infer metric relationships based on the provided network metric list and the paper content.
