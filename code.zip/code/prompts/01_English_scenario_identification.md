# Scenario Identification Prompt

## Role

You are a senior expert in communication networks and computer networks, with deep knowledge of network technologies and their application scenarios.

## Task

Given the full content of an academic paper, accurately identify the core network scenario studied in the paper.

## Input

```text
Paper content:
{text}

The network scenario studied in this paper is:
```

## Output

Output only one classification item. The output must include the category number, for example: `5.1 Data Center Networks`.

If the paper cannot be classified, output: `Unclassified`.

## Rules

The network scenario taxonomy is organized by hierarchy and dominant design constraints. Choose the single scenario name that best describes the paper's core experimental environment.

## Scenario Taxonomy

- **1.1 Internet and IP Networks**: Network infrastructure based on the IP protocol suite, including novel architectures, routing protocols, transport optimization, and inter-domain interconnection.
- **1.2 Software-Defined Networking**: Core innovation focuses on control/forwarding separation and centralized programmability, including controllers, northbound/southbound interfaces, and flow-table orchestration.
- **1.3 NFV / Virtualized Networks**: Core innovation focuses on decoupling network functions from hardware, including VNF deployment, orchestration, and elastic scaling.
- **1.4 Deterministic Networks**: Enabling technologies that provide bounded delay and jitter guarantees for core packet networks, such as TSN, DetNet protocols, and scheduling.
- **1.5 Reconfigurable Network Testbeds**: Enabling environments for network innovation, including testbed architecture, resource virtualization, and experiment-as-a-service.

- **2.1 Network Slicing and Multi-Tenant Management**: Creation, isolation, resource orchestration, management, and optimization algorithms for end-to-end network slices.
- **2.2 Multimodal / Integrated Network Architecture**: Architectures that carry heterogeneous logical networks on unified infrastructure, including coexistence, coordination, evolution, and generation mechanisms among those logical networks.

- **3.1 Cellular Mobile Communication Networks**: Including B5G/6G; wireless access, resource management, and mobility management centered on cellular architecture.
- **3.2 Mobile Ad Hoc Networks**: General networking problems involving infrastructure-free, mobile-node, multi-hop self-organizing networks.
- **3.3 Internet of Vehicles**: Vehicle-centered nodes, including V2X communication, cooperative perception, and control.
- **3.4 UAV Networks**: UAV-centered nodes, including aerial networking and joint trajectory-communication optimization.
- **3.5 Space-Air-Ground Integrated Networks**: Cross-domain coordination and joint scheduling across satellite-based, aerial, and terrestrial networks.
- **3.6 Underwater Communication Networks**: Underwater communication and networking technologies using carriers such as acoustic signals or lasers.

- **4.1 Wireless Sensor Networks**: Environmental sensing and data collection, emphasizing constrained nodes, multi-hop transmission, and network lifetime.
- **4.2 IoT Platforms and Applications**: Consumer-facing scenarios such as smart homes and smart cities, emphasizing heterogeneous device access, platforms, and services.
- **4.3 Industrial IoT / Industrial Control Networks**: Industrial scenarios with strict real-time, reliability, and security requirements for communication and control.
- **4.4 Cyber-Physical Systems**: Networks deeply embedded in closed-loop control, emphasizing system theory and security for integrated sensing, computing, communication, and control.

- **5.1 Data Center Networks**: Internal data-center topology, traffic engineering, congestion control, and performance optimization, possibly with emphasis on AI model training and inference services.
- **5.2 Cloud Computing Networks**: Inter-data-center interconnection, cloud access networks, virtual network orchestration, and tenant isolation.
- **5.3 Edge / Fog Computing Networks**: Computing capabilities pushed down to the network edge, such as base stations, gateways, compute-capable UAVs, and onboard units, to provide low-latency processing.
- **5.4 Computing Power Networks**: Integrated perception, collaborative scheduling, and service provisioning of computing, storage, and network resources across cloud-edge-terminal environments; emphasizes global coordination and transaction mechanisms for multiple resource types, rather than only the location of computing offloading or low-latency processing.

- **6.1 Satellite Communication Networks**: Satellite-centered nodes, including inter-satellite/space-ground networking, constellation management, and resource optimization.
- **6.2 Content Distribution and Peer-to-Peer Networks**: Content caching, distribution strategies, and overlay-network optimization.
- **6.3 Blockchain Distributed Networks**: P2P network characteristics supporting core blockchain functions such as consensus mechanisms and smart contracts.
- **6.4 Green and Energy-Aware Networks**: Network design where energy consumption or energy efficiency is the primary optimization objective and constraint.
- **6.5 Delay/Disruption-Tolerant Networks**: Protocols designed for long-delay and intermittently connected environments, including store-and-forward mechanisms that tolerate disconnection.
- **6.6 Optical Transport and Bearer Networks**: High-bandwidth, low-latency backbone technologies centered on optical transmission and all-optical switching.
